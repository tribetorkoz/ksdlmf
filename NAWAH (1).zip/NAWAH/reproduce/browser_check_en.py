"""Render checks for the English manuscript: layout, offline safety, print length."""
from playwright.sync_api import sync_playwright
from pathlib import Path
import json

R = Path(__file__).resolve().parent.parent      # repository root
PAPER = R / 'paper'
AUDIT = R / 'audit'; AUDIT.mkdir(exist_ok=True)
TARGET = PAPER / 'NAWAH_Research_Paper_EN.html'
requests = []

with sync_playwright() as p:
    b = p.chromium.launch(headless=True, args=['--no-sandbox'])
    page = b.new_page(viewport={'width': 1280, 'height': 1500}, device_scale_factor=1)
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.on('request', lambda r: requests.append(r.url))
    page.goto(TARGET.as_uri(), wait_until='load')
    page.screenshot(path=str(AUDIT / 'en_cover.png'))
    for n in [1, 5, 8]:
        page.locator('#fig' + str(n)).screenshot(path=str(AUDIT / f'en_figure{n}.png'))
    dims = page.evaluate('({viewport:innerWidth, body:document.body.scrollWidth, '
                         'figures:document.querySelectorAll("figure").length, '
                         'tables:document.querySelectorAll("table").length})')
    page.pdf(path=str(AUDIT / 'en_print_check.pdf'), format='A4', print_background=False,
             display_header_footer=True, header_template='<span></span>',
             footer_template='<div style="width:100%;font-family:Georgia;font-size:8px;text-align:center;color:#000">'
                             '<span class="pageNumber"></span> / <span class="totalPages"></span></div>')
    page.set_viewport_size({'width': 390, 'height': 844})
    page.screenshot(path=str(AUDIT / 'en_mobile.png'))
    mobile = page.evaluate('({viewport:innerWidth, body:document.body.scrollWidth})')
    external = [u for u in requests if not u.startswith('file:')]
    b.close()

import pymupdf
doc = pymupdf.open(AUDIT / 'en_print_check.pdf')
pages = doc.page_count
blank = [i + 1 for i, pg in enumerate(doc) if len(pg.get_text().strip()) < 20]
report = {'file': TARGET.name, 'javascript_errors': errors, 'desktop': dims, 'mobile': mobile,
          'external_requests': external, 'pdf_pages': pages, 'near_blank_pages': blank}
(AUDIT / 'browser_check_en.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report))
assert dims['body'] <= dims['viewport'] and mobile['body'] <= mobile['viewport']
assert not errors and not external and pages > 10
