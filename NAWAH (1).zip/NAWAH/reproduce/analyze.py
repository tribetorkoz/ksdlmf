"""Deterministic analysis of recorded NAWAH results. No simulated observations.
Run in the supplied original workspace, or edit BASE for an unpacked artifact set.
"""
from pathlib import Path
import json,math,csv,hashlib,collections,os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=Path(__file__).resolve().parent.parent      # repository root
PAPER=ROOT/'paper'
BASE=Path(os.environ.get('NAWAH_ARTIFACT_ROOT',str(ROOT/'data')))
ASSETS=PAPER/'assets';ASSETS.mkdir(exist_ok=True)
load=lambda p:json.loads(p.read_text())
pilot=load(BASE/'public_bench/results.json')['tasks']
v5=load(BASE/'nawah_v5/results.json')
v6=load(BASE/'nawah_v6/demo_results.json')
test=[r for r in v5 if r['phase']=='test'];dev=[r for r in v5 if r['phase']=='dev']
arms=['bare','retry','nawah']; labels=['Bare','Retry','NAWAH'];hatches=['','////','....'];markers=['o','s','^']
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'text.color':'black','axes.edgecolor':'black','axes.labelcolor':'black','xtick.color':'black','ytick.color':'black','axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white','svg.fonttype':'none','svg.hashsalt':'nawah-paper-2026-10-22','hatch.color':'black'})

def wilson(k,n,z=1.959963984540054):
    p=k/n; d=1+z*z/n;c=(p+z*z/(2*n))/d
    half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [max(0,c-half),min(1,c+half)]

def pair(rows,a,b,key='passed'):
    both=sum(r['arms'][a][key] and r['arms'][b][key] for r in rows)
    neither=sum(not r['arms'][a][key] and not r['arms'][b][key] for r in rows)
    wins=sum(not r['arms'][a][key] and r['arms'][b][key] for r in rows)
    losses=sum(r['arms'][a][key] and not r['arms'][b][key] for r in rows)
    m=wins+losses
    p=min(1,2*sum(math.comb(m,i) for i in range(min(wins,losses)+1))/2**m) if m else None
    return dict(both=both,neither=neither,wins=wins,losses=losses,delta=(wins-losses)/len(rows),exact_p=p)

def summarize(rows,keys,key='passed',public=None):
    out={}
    for a in keys:
        k=sum(r['arms'][a][key] for r in rows); n=len(rows);calls=sum(r['arms'][a]['calls'] for r in rows)
        out[a]=dict(k=k,n=n,rate=k/n,wilson95=wilson(k,n),calls=calls,mean_calls=calls/n,solved_per_call=k/calls)
    return out

stats={'pilot':summarize(pilot,['bare','retry','nawah_adapter']),
       'v5_dev':summarize(dev,arms),'v5_test':summarize(test,arms),
       'v6':summarize(v6,arms,'heldout_passed'),
       'paired':{'v5_nawah_vs_bare':pair(test,'bare','nawah'),'v5_nawah_vs_retry':pair(test,'retry','nawah'),'pilot_retry_vs_bare':pair(pilot,'bare','retry'),'v6_nawah_vs_bare':pair(v6,'bare','nawah','heldout_passed')}}
assert [stats['pilot'][a]['k'] for a in ['bare','retry','nawah_adapter']]==[16,18,16]
assert [stats['v5_test'][a]['k'] for a in arms]==[10,10,11]
assert [stats['v6'][a]['calls'] for a in arms]==[4,6,6]
(PAPER/'analysis.json').write_text(json.dumps(stats,indent=2))
flat=[]
for study,rows in [('pilot',pilot),('v5_dev',dev),('v5_test',test),('v6',v6)]:
    for r in rows:
        for a,x in r['arms'].items():
            flat.append({'study':study,'task':r.get('task',r.get('id')),'arm':a,'heldout_pass':int(x.get('passed',x.get('heldout_passed',False))),'calls':x['calls']})
with (PAPER/'observations.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
figs={}
def save(name,fig,source):
    fig.tight_layout(pad=1.5)
    fig.savefig(ASSETS/(name+'.svg'),format='svg',metadata={'Date':None})
    plt.close(fig);figs[name]=source

def style(ax,xlab='',ylab='',ylim=None):
    ax.set_xlabel(xlab);ax.set_ylabel(ylab)
    if ylim:ax.set_ylim(*ylim)

def grouped(name,groups,values,denoms,series,source,ylim=100):
    fig,ax=plt.subplots(figsize=(7.5,3.7));x=np.arange(len(groups));w=.22
    for j,ss in enumerate(series):
        vals=[100*values[i][j]/denoms[i] for i in range(len(groups))]
        bars=ax.bar(x+(j-1)*w,vals,w,label=ss,color='white',edgecolor='black',hatch=hatches[j],linewidth=1.2)
        for b,k,n in zip(bars,[v[j] for v in values],denoms):ax.text(b.get_x()+w/2,b.get_height()+2,f'{k}/{n}',ha='center',fontsize=9)
    ax.set_xticks(x,groups);ax.set_ylim(0,ylim);ax.set_yticks([0,25,50,75,100]);ax.set_ylabel('Held-out task success (%)')
    ax.legend(frameon=False,ncol=3,loc='upper center',bbox_to_anchor=(.5,1.18));save(name,fig,source)

grouped('f03_pilot',['HumanEval','MBPP','Combined'],[[sum(r['arms'][a]['passed'] for r in pilot if r['suite']==suite) for a in ['bare','retry','nawah_adapter']] for suite in ['HumanEval','MBPP']]+[[16,18,16]],[12,12,24],['Bare','Retry','Repair adapter'],'public_bench/results.json; task-level hidden outcomes')
grouped('f04_v5',['Development','Test'],[[5,5,5],[10,10,11]],[8,16],labels,'nawah_v5/results.json; phases analyzed separately')
# Wilson forest, no repeated-run variance is invented.
fig,ax=plt.subplots(figsize=(7.5,4.5))
forest=[('v5 test / Bare',10,16),('v5 test / Retry',10,16),('v5 test / NAWAH',11,16),('v6 / Bare',3,4),('v6 / Retry',3,4),('v6 / NAWAH',3,4)]
for i,(label,k,n) in enumerate(forest):
    lo,hi=wilson(k,n);p=k/n
    ax.errorbar(p*100,5-i,xerr=[[100*(p-lo)],[100*(hi-p)]],fmt=markers[i%3],color='black',capsize=4,mfc='white',ms=7)
    ax.text(101,5-i,f'{100*p:.2f}% [{100*lo:.2f}, {100*hi:.2f}]',va='center',fontsize=9)
ax.set_yticks(range(6),[x[0] for x in reversed(forest)]);ax.set_xlim(0,100);ax.set_xlabel('Success (%) · nominal Wilson 95% interval');ax.set_ylim(-.7,5.7)
fig.subplots_adjust(right=.6);save('f05_intervals',fig,'analysis.json; Wilson z=1.959963984540054; binomial working model, not run-to-run variance')
# Task matrix
fig,ax=plt.subplots(figsize=(7.2,5.5))
for i,r in enumerate(test):
    for j,a in enumerate(arms):
        ok=r['arms'][a]['passed']
        ax.add_patch(plt.Rectangle((j-.45,i-.42),.9,.84,facecolor='black' if ok else 'white',edgecolor='black'))
        ax.text(j,i,'1' if ok else '0',ha='center',va='center',color='white' if ok else 'black')
ax.set_xlim(-.6,2.6);ax.set_ylim(15.6,-.7);ax.set_xticks(range(3),labels);ax.set_yticks(range(16),[r['task'] for r in test]);ax.tick_params(length=0);ax.spines[['left','bottom']].set_visible(False)
save('f06_task_matrix',fig,'nawah_v5/results.json; test only; original manifest ordering, not time')
# Paired contingency actual counts
fig,ax=plt.subplots(figsize=(6.4,3.6))
p=stats['paired']['v5_nawah_vs_bare'];cells=[[p['both'],p['losses']],[p['wins'],p['neither']]]
for i in range(2):
    for j in range(2):
        ax.add_patch(plt.Rectangle((j,i),1,1,facecolor='white',edgecolor='black',hatch='///' if i!=j else ''))
        ax.text(j+.5,i+.5,str(cells[i][j]),ha='center',va='center',fontsize=24,bbox={'facecolor':'white','edgecolor':'none','pad':4})
ax.set_xlim(0,2);ax.set_ylim(2,0);ax.set_xticks([.5,1.5],['NAWAH pass','NAWAH fail']);ax.set_yticks([.5,1.5],['Bare pass','Bare fail']);ax.tick_params(length=0);ax.spines[:].set_visible(False)
save('f07_paired',fig,'v5 test paired outcomes: both=10, bare-only=0, nawah-only=1, neither=5')
# Public/heldout classification
fig,ax=plt.subplots(figsize=(7.4,3.7));bottom=np.zeros(3)
cat=[(True,True,'Public pass / hidden pass'),(True,False,'Public pass / hidden fail'),(False,False,'Public fail / hidden fail')]
for j,(pub,hid,lab) in enumerate(cat):
    vals=[sum((r['arms'][a]['status']=='public_examples_passed')==pub and r['arms'][a]['passed']==hid for r in test) for a in arms]
    ax.bar(labels,vals,bottom=bottom,facecolor='white',edgecolor='black',hatch=hatches[j],label=lab)
    for i,v in enumerate(vals):ax.text(i,bottom[i]+v/2,str(v),ha='center',va='center',bbox={'facecolor':'white','edgecolor':'none','pad':1})
    bottom+=vals
ax.set_ylim(0,17);ax.set_ylabel('Tasks (v5 test, n=16)');ax.set_yticks([0,4,8,12,16]);ax.legend(frameon=False,fontsize=9,loc='upper left',bbox_to_anchor=(1,1))
save('f08_public_gap',fig,'nawah_v5/results.json; no hidden-pass/public-fail tasks observed')
# Success vs request effort (no dollars/timing)
fig,ax=plt.subplots(figsize=(7,3.7))
for j,a in enumerate(arms):
    x=stats['v5_test'][a]['mean_calls'];y=100*stats['v5_test'][a]['rate']
    ax.scatter([x],[y],marker=markers[j],s=85,facecolor='white',edgecolor='black',linewidth=1.5)
    ax.annotate(labels[j],(x,y),xytext=(7,7 if j!=1 else -15),textcoords='offset points')
ax.set_xlim(.9,1.65);ax.set_ylim(0,100);ax.set_yticks([0,25,50,75,100]);style(ax,'Mean interface requests per task','Held-out success (%)')
save('f09_effort',fig,'v5 test recorded calls; requests can be cache hits; not latency or token cost')
# histogram calls
fig,ax=plt.subplots(figsize=(7.5,3.7));x=np.arange(1,4);w=.22
for j,a in enumerate(arms):
    vals=[sum(r['arms'][a]['calls']==i for r in test) for i in x]
    ax.bar(x+(j-1)*w,vals,w,facecolor='white',edgecolor='black',hatch=hatches[j],label=labels[j])
    for i,v in enumerate(vals):ax.text(x[i]+(j-1)*w,v+.2,str(v),ha='center',fontsize=9)
ax.set_xticks(x);ax.set_ylim(0,18);ax.set_yticks([0,4,8,12,16]);style(ax,'Requests per task','Task count');ax.legend(frameon=False,ncol=3)
save('f10_calls',fig,'v5 test calls histogram; observed counts only')
# v6 task-level bars
fig,ax=plt.subplots(figsize=(7.5,3.5));x=np.arange(4);w=.22
for j,a in enumerate(arms):
    vals=[sum(t['ok'] for t in r['arms'][a]['heldout_results']) for r in v6]
    ax.bar(x+(j-1)*w,vals,w,facecolor='white',edgecolor='black',hatch=hatches[j],label=labels[j])
    for i,v in enumerate(vals):ax.text(x[i]+(j-1)*w,v+.1,f'{v}/{len(v6[i]["arms"][a]["heldout_results"])}',ha='center',fontsize=8)
ax.set_xticks(x,[r['task'] for r in v6]);ax.set_ylim(0,5.3);ax.set_yticks([0,1,2,3,4]);ax.set_ylabel('Individual held-out tests passed');ax.legend(frameon=False,ncol=3)
save('f11_v6_tests',fig,'nawah_v6/demo_results.json; tests nested within 4 authored tasks, not 15 independent tasks')
# v6 baseline-to-final public paired slope, design not inference
fig,ax=plt.subplots(figsize=(7.3,3.8))
for i,r in enumerate(v6):
    raw=load(ROOT/'evidence/nawah_v6/runs'/r['task']/'nawah/result.json')
    vals=[sum(t['ok'] for t in raw[k]) for k in ['initial_tests','final_public_tests']]
    # Small horizontal offset separates identical records without altering y values.
    off=(i-1.5)*.035
    ax.plot([off,1+off],vals,color='black',linestyle=['-','--',':','-.'][i],marker=['o','s','^','D'][i],mfc='white',label=r['task'])
ax.set_xticks([0,1],['Baseline','Final candidate']);ax.set_ylim(0,3.5);ax.set_yticks([0,1,2,3]);ax.set_ylabel('Passed public tests (of 3)');ax.legend(frameon=False,ncol=2)
save('f12_v6_slope',fig,'v6 NAWAH initial_tests and final_public_tests from saved per-task result.json; horizontal offsets for visibility only')
# Logged public progress MBPP388
fig,ax=plt.subplots(figsize=(7.2,3.5))
r=next(r for r in test if r['task']=='MBPP/388')
for j,a in enumerate(arms):
    hist=r['arms'][a]['history'];xx=list(range(1,len(hist)+1));yy=[h['passed'] for h in hist]
    ax.plot(xx,yy,color='black',linestyle=['-', '--',':'][j],marker=markers[j],mfc='white',label=labels[j],lw=1.5,ms=8-j)
ax.set_xticks([1,2,3]);ax.set_yticks([0,1]);ax.set_ylim(-.15,1.3);style(ax,'Logged candidate index','Public example passed (0/1)');ax.legend(frameon=False,ncol=3,loc='upper center')
save('f13_progress',fig,'v5 MBPP/388 actual history[].passed; no hidden evaluation of intermediate candidates; no extrapolation')
# pilot failure taxonomy stacked horizontal counts
fig,ax=plt.subplots(figsize=(7.5,3.7));left=np.zeros(3)
def classify(reason):
    if reason=='passed':return 'Pass'
    if reason=='syntax':return 'Syntax'
    if reason.startswith('AssertionError'):return 'Assertion'
    return 'Runtime'
for j,c in enumerate(['Pass','Assertion','Runtime','Syntax']):
    vals=[sum(classify(r['arms'][a]['reason'])==c for r in pilot) for a in ['bare','retry','nawah_adapter']]
    ax.barh(['Bare','Retry','Repair adapter'],vals,left=left,facecolor='white',edgecolor='black',hatch=['','///','...','xxx'][j],label=c)
    for i,v in enumerate(vals):
        if v:ax.text(left[i]+v/2,i,str(v),ha='center',va='center',bbox={'facecolor':'white','edgecolor':'none','pad':1})
    left+=vals
ax.set_xlim(0,24);ax.set_xticks([0,4,8,12,16,20,24]);ax.set_xlabel('Tasks (pilot, n=24)');ax.legend(frameon=False,ncol=4,loc='upper center',bbox_to_anchor=(.5,1.2))
save('f14_failures',fig,'public_bench/results.json reason taxonomy defined in analyze.py; runtime groups TypeError, IndexError')
(PAPER/'figure_sources.json').write_text(json.dumps(figs,indent=2))
print(json.dumps(stats,indent=2));print('Figures generated:',len(figs))
