"""Re-execute saved trusted candidates, not new model generations.
Not a hostile-code sandbox; only for the artifacts of this study.
"""
from pathlib import Path
import json,sys,hashlib,os
ROOT=Path(__file__).resolve().parent.parent      # repository root
PAPER=ROOT/'paper'
BASE=Path(os.environ.get('NAWAH_ARTIFACT_ROOT',str(ROOT/'data')))
sys.path.insert(0,str(BASE/'nawah_v4'))
sys.path.insert(0,str(BASE/'public_bench'))
from run_public import execute,load
sys.path.insert(0,str(BASE/'nawah_v6'))
from repo_agent import run_tests

def main():
    rows=[]
    pilot=json.loads((BASE/'public_bench/results.json').read_text())['tasks']
    tasks={t['id']:t for t in load()}
    for r in pilot:
        for arm,a in r['arms'].items():
            ok,why=execute(a['code'],tasks[r['id']]['hidden'])
            rows.append(dict(study='pilot',task=r['id'],arm=arm,recorded=a['passed'],rechecked=ok,match=ok==a['passed'],reason=why))
    mbpp={t['task_id']:t for t in json.loads((BASE/'public_bench/data/mbpp.json').read_text())}
    for r in json.loads((BASE/'nawah_v5/results.json').read_text()):
        t=mbpp[int(r['task'].split('/')[1])]
        tests='\n'.join(t.get('test_imports',[]))+'\n'+'\n'.join(t['test_list'][1:])
        for arm,a in r['arms'].items():
            ok,why=execute(a['selected']['code'],tests)
            rows.append(dict(study='v5_'+r['phase'],task=r['task'],arm=arm,recorded=a['passed'],rechecked=ok,match=ok==a['passed'],reason=why))
    base=ROOT/'evidence/nawah_v6'
    for r in json.loads((BASE/'nawah_v6/demo_results.json').read_text()):
        for arm,a in r['arms'].items():
            got=run_tests(base/'runs'/r['task']/arm/'candidate',base/'fixtures'/r['task']/'heldout')
            ok=all(x['ok'] for x in got)
            rows.append(dict(study='v6',task=r['task'],arm=arm,recorded=a['heldout_passed'],rechecked=ok,match=ok==a['heldout_passed'],tests=got))
    (ROOT/'audit/candidate_rechecks.json').write_text(json.dumps(rows,indent=2))
    print('Saved candidate arm-task checks:',len(rows),'matching:',sum(x['match'] for x in rows))
    assert all(x['match'] for x in rows)
if __name__=='__main__':main()
