"""Checks for the landing page: offline safety, layout, and that every link resolves.

Run from anywhere:  python3 reproduce/check_site.py
Writes audit/site_check.json and exits non-zero on any failure.
"""
from pathlib import Path
import json, sys
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent.parent
SITE = ROOT / "site" / "index.html"
AUDIT = ROOT / "audit"
AUDIT.mkdir(exist_ok=True)

fails = []
def check(name, cond, detail=""):
    if not cond:
        fails.append(f"{name}: {detail}")

html = SITE.read_text()
check("single file, no external src", "src=" not in html and "<link" not in html)
check("no css @import", "@import" not in html)
check("has title", "<title>" in html)

requests = []
with sync_playwright() as p:
    b = p.chromium.launch(headless=True, args=["--no-sandbox"])
    page = b.new_page(viewport={"width": 1280, "height": 1400})
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("request", lambda r: requests.append(r.url))
    page.goto(SITE.as_uri(), wait_until="load")
    desk = page.evaluate("({v:innerWidth, b:document.body.scrollWidth})")
    anchors = page.evaluate(
        "[...document.querySelectorAll('a[href^=\"#\"]')].map(a=>a.getAttribute('href').slice(1))")
    links = page.evaluate(
        "[...document.querySelectorAll('a[href]')].map(a=>a.getAttribute('href'))")
    svgs = page.evaluate("document.querySelectorAll('figure svg').length")
    page.pdf(path=str(AUDIT / "site_print.pdf"), format="A4", print_background=False)
    page.set_viewport_size({"width": 390, "height": 844})
    mob = page.evaluate("({v:innerWidth, b:document.body.scrollWidth})")
    b.close()

external = [u for u in requests if not u.startswith("file:")]
check("zero external requests", not external, str(external[:3]))
check("no javascript errors", not errors, str(errors[:3]))
check("desktop no horizontal overflow", desk["b"] <= desk["v"], str(desk))
check("mobile no horizontal overflow", mob["b"] <= mob["v"], str(mob))
check("inline svg present", svgs >= 1, str(svgs))

missing_anchor = [a for a in anchors if f'id="{a}"' not in html]
check("internal anchors resolve", not missing_anchor, str(missing_anchor))

missing_file = []
for href in links:
    if href.startswith("#") or href.startswith("http") or href.startswith("mailto"):
        continue
    target = (SITE.parent / href).resolve()
    if not target.exists():
        missing_file.append(href)
check("relative links resolve to real files", not missing_file, str(missing_file))

report = {"file": str(SITE.relative_to(ROOT)), "bytes": SITE.stat().st_size,
          "external_requests": external, "javascript_errors": errors,
          "desktop": desk, "mobile": mob, "svg_figures": svgs,
          "links_checked": len(links), "failures": fails}
(AUDIT / "site_check.json").write_text(json.dumps(report, indent=2))
print(json.dumps(report))
sys.exit(1 if fails else 0)
