"""Consistency tests; do not certify absence of all scientific errors."""
from pathlib import Path
import json,hashlib,math,re,csv,xml.etree.ElementTree as ET
from bs4 import BeautifulSoup
from scipy.stats import binomtest,norm
from scipy.optimize import brentq
ROOT=Path(__file__).resolve().parent.parent   # repository root
PAPER=ROOT/'paper'
BASE=ROOT/'data'
p=PAPER/'NAWAH_Research_Paper_AR.html'; soup=BeautifulSoup(p.read_text(),'html.parser')
e=json.loads(soup.find(id='embedded-evidence').string)
checks=[]
def check(name,condition):
    checks.append({'check':name,'passed':bool(condition)})
    if not condition:raise AssertionError(name)
for name,rows,key in [('pilot',e['pilot_results']['tasks'],'passed'),('v5_dev',[r for r in e['v5_results'] if r['phase']=='dev'],'passed'),('v5_test',[r for r in e['v5_results'] if r['phase']=='test'],'passed'),('v6',e['v6_results'],'heldout_passed')]:
    for arm,s in e['analysis'][name].items():
        check('raw observations agree with summary: '+name+'/'+arm,len(rows)==s['n'] and sum(bool(r['arms'][arm][key]) for r in rows)==s['k'] and sum(r['arms'][arm]['calls'] for r in rows)==s['calls'])
check('14 figures',len(soup.select('figure'))==14)
check('11 tables',len(soup.select('table'))==11)
ids=[t['id'] for t in soup.select('[id]')];check('unique HTML and SVG ids',len(ids)==len(set(ids)))
check('local anchors resolve',all(a['href'][1:] in ids for a in soup.select('a[href^="#"]')))
check('no remote rendering dependencies',not soup.select('script[src],img[src],link[rel="stylesheet"],iframe,object,embed'))
check('all SVGs parse',all(ET.fromstring(str(x)) is not None for x in soup.find_all('svg')))
check('all figures have descriptions',all(f.select_one('svg title') and f.select_one('svg desc') and f.find('figcaption') for f in soup.select('figure')))
check('no template placeholders','{{' not in p.read_text())
# Independent inversion of the score test for Wilson interval.
z=norm.ppf(.975)
for group in ['pilot','v5_dev','v5_test','v6']:
    for arm,s in e['analysis'][group].items():
        k,n=s['k'],s['n'];phat=k/n
        def f(q):return (phat-q)**2-z*z*q*(1-q)/n
        lo=brentq(f,0,phat) if k else 0
        hi=brentq(f,phat,1) if k<n else 1
        check(f'Wilson independently inverted: {group}/{arm}',max(abs(lo-s['wilson95'][0]),abs(hi-s['wilson95'][1]))<1e-10)
for name,x in e['analysis']['paired'].items():
    if x['wins']+x['losses']:
        pv=binomtest(x['wins'],x['wins']+x['losses'],p=.5).pvalue
        check('exact paired binomial independently checked: '+name,abs(pv-x['exact_p'])<1e-12)
check('156 saved candidate decisions matched',len(e['candidate_rechecks'])==156 and all(x['match'] for x in e['candidate_rechecks']))
check('76 restored v6 files match archived hashes',len(e['v6_restored_hash_checks'])==76 and all(x['matches_delivery_hash'] for x in e['v6_restored_hash_checks']))
check('original 79 file checksum entries pass',(ROOT/'audit/original_recheck.txt').read_text().count(': OK')==79)
check('v5 recheck has 10 unit tests and OK','Ran 10 tests' in (ROOT/'audit/v5_unit_recheck.txt').read_text() and '\nOK\n' in (ROOT/'audit/v5_unit_recheck.txt').read_text())
check('v6 recheck has 13 unit tests and OK','Ran 13 tests' in (ROOT/'audit/v6_unit_recheck.txt').read_text() and '\nOK\n' in (ROOT/'audit/v6_unit_recheck.txt').read_text())
check('all 156 observation rows are present',len(list(csv.DictReader((PAPER/'observations.csv').open())))==156)
old=set(e['manifests']['public_bench/manifest.json']['ids']);new=e['manifests']['nawah_v5/manifest.json']
check('v5 test excludes pilot ids',not old.intersection('MBPP/'+str(i) for i in new['test_ids']))
check('v5 dev and test disjoint',not set(new['dev_ids']).intersection(new['test_ids']))
# The SVG artwork itself only uses black, white, none or inherited currentColor.
colors=set()
for f in soup.find_all('svg'):
    colors.update(re.findall(r'#[0-9a-fA-F]{6}\b',str(f)))
check('SVG explicit six-digit colors are black/white only',colors<= {'#000000','#ffffff','#FFFFFF'})
check('no fabricated model timing columns',all(x not in e['analysis']['v5_test']['nawah'] for x in ['seconds','watts','tokens','dollars']))
for path,h in e['hashes'].items():
    check('input hash unchanged: '+path,hashlib.sha256((BASE/path).read_bytes()).hexdigest()==h)
(ROOT/'audit/validation.json').write_text(json.dumps(checks,indent=2))
print(len(checks),'consistency checks passed; this is not a guarantee of no errors.')
