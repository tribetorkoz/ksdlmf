from playwright.sync_api import sync_playwright
from pathlib import Path
import json
R=Path(__file__).resolve().parent.parent      # repository root
PAPER=R/'paper'
AUDIT=R/'audit';AUDIT.mkdir(exist_ok=True)
with sync_playwright() as p:
    b=p.chromium.launch(headless=True,args=['--no-sandbox'])
    page=b.new_page(viewport={'width':1280,'height':1500},device_scale_factor=1)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.goto((PAPER/'NAWAH_Research_Paper_AR.html').as_uri(),wait_until='load')
    page.screenshot(path=str(AUDIT/'cover.png'))
    for n in [1,5,8]:page.locator('#fig'+str(n)).screenshot(path=str(AUDIT/f'figure{n}.png'))
    dimensions=page.evaluate('({viewport:innerWidth,body:document.body.scrollWidth,figures:document.querySelectorAll("figure").length})')
    page.pdf(path=str(AUDIT/'print_check.pdf'),format='A4',print_background=True,display_header_footer=True,header_template='<span></span>',footer_template='<div style="width:100%;font-family:Arial;font-size:8px;text-align:center;color:black"><span class="pageNumber"></span> / <span class="totalPages"></span></div>')
    page.set_viewport_size({'width':390,'height':844});page.screenshot(path=str(AUDIT/'mobile.png'))
    mobile=page.evaluate('({viewport:innerWidth,body:document.body.scrollWidth})')
    (AUDIT/'browser_check.json').write_text(json.dumps({'javascript_errors':errors,'desktop':dimensions,'mobile':mobile},indent=2))
    print(dimensions,mobile,'JS errors',errors)
    assert dimensions['body']<=dimensions['viewport'] and mobile['body']<=mobile['viewport']
    assert not errors
    b.close()
