from pathlib import Path
import json,re,html,hashlib,os
ROOT=Path(__file__).resolve().parent.parent      # repository root
PAPER=ROOT/'paper'
BASE=Path(os.environ.get('NAWAH_ARTIFACT_ROOT',str(ROOT/'data')))
load=lambda p:json.loads(p.read_text())
stats=load(PAPER/'analysis.json');pilot=load(BASE/'public_bench/results.json')['tasks'];v5=load(BASE/'nawah_v5/results.json');v6=load(BASE/'nawah_v6/demo_results.json')
A=PAPER/'assets'

def text(x,y,s,size=16,anchor='middle',weight='normal'):
    return f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="Arial,sans-serif" font-size="{size}" font-weight="{weight}" fill="#000">{html.escape(s)}</text>'
def box(x,y,w,h,lines):
    z=f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#fff" stroke="#000" stroke-width="1.5"/>'
    for i,s in enumerate(lines):z+=text(x+w/2,y+27+i*23,s,15)
    return z

def diagram(name,title,content,height):
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 {height}" role="img" aria-label="{title}"><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#000"/></marker></defs><rect width="900" height="{height}" fill="#fff"/>{content}</svg>'
    (A/(name+'.svg')).write_text(svg)
def arrow(x1,y1,x2,y2,dash=False):
    return f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#000" stroke-width="1.5" marker-end="url(#arrow)"'+(' stroke-dasharray="6 4"' if dash else '')+'/>'

z=text(450,28,'v6: trusted inputs, bounded proposals, observed-test acceptance',20,weight='bold')
z+=box(20,65,175,92,['Issue + source','Editable paths','Trusted inputs'])+box(240,65,175,92,['Local fixed LLM','Full-file proposal','No weight updates'])+box(460,65,175,92,['Patch gate','Paths + syntax','Partial AST checks'])+box(680,65,195,92,['Temporary copy','Frozen public tests','Subprocess runner'])
for x1,x2 in [(195,240),(415,460),(635,680)]:z+=arrow(x1,110,x2,110)
z+=box(680,230,195,90,['Acceptance rule','Keep passing IDs','Strict count gain'])+arrow(777,157,777,230)
z+=box(240,230,395,90,['Final candidate + diff + JSON / SQLite','No auto-apply to source','Audit persistence, not skill retrieval'])+arrow(680,275,635,275)
z+=box(20,230,175,90,['External evaluator','Held-out tests','After solve only'])+arrow(240,275,195,275)
z+=f'<path d="M 680 300 L 655 300 L 655 355 L 220 355 L 220 190 L 330 190 L 330 157" fill="none" stroke="#000" stroke-width="1.5" stroke-dasharray="6 4" marker-end="url(#arrow)"/>'+text(490,348,'Next request, if budget remains',13)
z+=text(450,395,'Conceptual boundary diagram; worktree copies are NOT a security sandbox.',14)
diagram('f01_architecture','Conceptual v6 architecture, not measured performance',z,415)
z=text(450,27,'Three distinct cohorts; no pooled success rate',20,weight='bold')
z+=box(20,58,270,100,['A · pilot: 24 public tasks','HumanEval 12 + MBPP 12','384 tokens / request'])+box(315,58,270,100,['B · v5: MBPP split','Development 8 / test 16','512 tokens / request'])+box(610,58,270,100,['C · v6: 4 authored fixtures','Small trusted repositories','512 tokens / request'])
for x in [155,450,745]:z+=arrow(x,158,x,207)
z+=box(20,207,270,70,['72 saved arm-task outcomes','24 tasks × 3 arms'])+box(315,207,270,70,['72 saved arm-task outcomes','24 tasks × 3 arms'])+box(610,207,270,70,['12 saved arm-task outcomes','4 fixtures × 3 arms'])
for x in [155,450,745]:z+=f'<path d="M {x} 277 L {x} 310 L 450 310" fill="none" stroke="#000" stroke-width="1.5"/>'
z+=arrow(450,310,450,340)+box(180,340,540,73,['Current audit: re-run saved candidates on the SAME tests','156 / 156 binary outcomes matched; no new model inference'])
z+=text(450,448,'Conceptual protocol diagram. Rechecks do not add 156 independent tasks.',14)
diagram('f02_protocol','Conceptual study cohorts and execution audit',z,465)

captions={
1:('مخطط بنية v6','رسم تفسيري، لا بيانات أداء','حدود المصدر الموثوق، ومقترح النموذج، وبوابة التعديل، والاختبار، وحفظ المرشح. الخط المتقطع طلب تالٍ ضمن الميزانية، والتقييم المحجوب يحدث بعد انتهاء solve. نسخ الملفات ليس sandbox.','repo_agent.py; conceptual rendering'),
2:('مخطط البروتوكول ومصدر المقامات','رسم تفسيري','الدراسات ثلاث مجموعات منفصلة. تجمع إعادة الفحص 156 سجل مهمة × ذراع، لا 156 مهمة جديدة؛ كل تقييم يستعمل المرشح والاختبارات نفسيهما.','manifests; candidate_rechecks.json; conceptual rendering'),
3:('أعمدة نجاح التجربة الأولية','قياسات محفوظة','كل عمود عدد المهام الناجحة من مقام مجموعته. Repair adapter هو المحوّل الأولي، وليس v6 أو تقييم المشروع الأصلي بأكمله. لا تُقرأ المجموعة Combined كدراسة مستقلة جديدة.','public_bench/results.json'),
4:('أعمدة التطوير والاختبار في v5','قياسات محفوظة','لا يدمج التطوير مع الاختبار. لا مكسب على التطوير، ومكسب مهمة واحدة على الاختبار. أنماط التهشير تفصل الأذرع دون ألوان.','nawah_v5/results.json; phase'),
5:('مخطط نقاط وفواصل Wilson','حساب تحليلي من قياسات','نسب نجاح المهام وفواصل Wilson الاسمية 95% بصيغة (3). ليست انحرافات معيارية عبر تشغيلات، ولا ضمان تغطية لمجتمع مهام عام؛ شروط التفسير في §5.','analysis.json; k/n; Wilson closed-form calculation'),
6:('مصفوفة النجاح لكل مهمة اختبار v5','قياسات محفوظة','الخانة السوداء 1 = نجاح كل المحجوب، والخانة البيضاء 0 = فشل. الاختلاف الوحيد بين الأذرع هو MBPP/388. ترتيب الصفوف من manifest وليس الزمن.','nawah_v5/results.json; test split'),
7:('مصفوفة المقارنة المقترنة v5','حساب تعداد مباشر','الصفوف bare والأعمدة NAWAH: 10 نجاحات مشتركة، و5 إخفاقات مشتركة، ومهمة واحدة لـNAWAH وحده، وصفر للمقارن وحده. قيمة الاختبار الشرطي الاستكشافي p = 1.0.','v5 test paired outcomes; exact enumeration'),
8:('أعمدة مكدسة لفجوة الاختبار العلني','قياسات محفوظة','توجد حالتان في كل ذراع تجتازان المثال وتفشلان في المحجوب. لا توجد حالة نجاح محجوب مع فشل علني في هذه العينة. الأجزاء تجمع إلى 16 مهمة لكل ذراع.','v5 test status and passed fields'),
9:('انتشار: النجاح مقابل طلبات الواجهة','حساب تحليلي من قياسات','النقاط قيم ملخصة للأذرع الثلاثة في اختبار v5: متوسط الطلبات مقابل نسبة نجاح المهام. المحور الأفقي ليس ثواني أو رموزًا أو دولارات؛ قد تشمل الطلبات cache hits.','v5 test calls and passed fields'),
10:('توزيع عدد الطلبات','قياسات محفوظة','عدد المهام التي استعملت 1 أو 2 أو 3 طلبات. مجموع أعمدة كل ذراع 16. هذا histogram متقطع للطلبات الفعلية، لا تجربة ميزانية معاد تشغيلها.','v5 test calls field'),
11:('اختبارات v6 الفردية حسب الحالة','قياسات محفوظة','نجاحات الاختبارات المحجوبة داخل كل مهمة. المقامات 4 و4 و4 و3؛ هي اختبارات مترابطة داخل أربع حالات وليست 15 مهمة مستقلة. جميع الأذرع تفشل مهمة headers كاملة.','nawah_v6/demo_results.json; heldout_results'),
12:('مخطط ميل: البداية والمرشح النهائي في v6','قياسات محفوظة','يعرض NAWAH وحده على الاختبارات العلنية. أزيحت نهايات الخطوط أفقيًا قليلًا لتمييز الحالات المتطابقة دون تغيير أي قيمة عمودية. لا يستدل منه على أثر سببي مقارنة بالأذرع الأخرى.','v6 runs/*/nawah/result.json; initial_tests and final_public_tests'),
13:('خط زمني للمحاولات المسجلة في MBPP/388','قياسات محفوظة','المحور الأفقي فهرس المرشح لا الزمن. تعرض الخطوط نجاح المثال العلني لكل محاولة موجودة فعلًا؛ تنتهي عند آخر محاولة ولا تستكمل ببيانات مفترضة. لا تعرض نتائج محجوبة للمرشحين الوسيطين.','v5 test MBPP/388; history[].passed'),
14:('توزيع أسباب النتيجة النهائية في التجربة الأولية','تعداد مع تصنيف معلن','أعمدة أفقية مكدسة تجمع إلى 24 مهمة. Syntax رفض صياغة، Assertion فشل assertion، وRuntime يجمع TypeError وIndexError. التصنيف يصف سبب الخروج المسجل ولا يثبت سبب الخطأ الجذري.','public_bench/results.json; reason; taxonomy in analyze.py')}
names=['f01_architecture','f02_protocol','f03_pilot','f04_v5','f05_intervals','f06_task_matrix','f07_paired','f08_public_gap','f09_effort','f10_calls','f11_v6_tests','f12_v6_slope','f13_progress','f14_failures']

def svg_inline(p,prefix):
    s=p.read_text();s=s[s.find('<svg'):]
    s=re.sub(r'<metadata>.*?</metadata>','',s,flags=re.S)
    ids=re.findall(r'\bid="([^"]+)"',s)
    for ident in sorted(set(ids),key=len,reverse=True):
        s=s.replace('id="'+ident+'"','id="'+prefix+'_'+ident+'"').replace('url(#'+ident+')','url(#'+prefix+'_'+ident+')').replace('href="#'+ident+'"','href="#'+prefix+'_'+ident+'"')
    s=s.replace('<svg ','<svg role="img" aria-labelledby="'+prefix+'_title '+prefix+'_desc" ',1)
    # Remove any duplicated diagram-level attributes after adding a uniform title.
    s=s.replace('role="img" aria-label="Conceptual v6 architecture, not measured performance"','').replace('role="img" aria-label="Conceptual study cohorts and execution audit"','')
    start=s.find('>')+1
    num=int(prefix[1:]);title,typ,desc,source=captions[num]
    s=s[:start]+f'<title id="{prefix}_title">{html.escape(title)}</title><desc id="{prefix}_desc">{html.escape(desc)}</desc>'+s[start:]
    return s

def figure(i,name):
    title,typ,desc,src=captions[i]
    return f'<figure id="fig{i}">{svg_inline(A/(name+".svg"),"f"+str(i))}<figcaption><strong>شكل {i}. {title}.</strong><span class="figtype">{typ}</span> {desc}<span class="source">Source: {html.escape(src)}</span></figcaption></figure>'

def table(title,headers,rows):
    return '<div class="table-wrap"><table><caption>'+title+'</caption><thead><tr>'+''.join('<th scope="col">'+x+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def num(x):return '<span class="num" dir="ltr">'+str(x)+'</span>'
coh=[('التجربة الأولية','pilot',['bare','retry','nawah_adapter']),('v5: تطوير','v5_dev',['bare','retry','nawah']),('v5: اختبار','v5_test',['bare','retry','nawah']),('v6: تكامل','v6',['bare','retry','nawah'])]
summary=[];cirows=[]
for lab,key,arms in coh:
    for a in arms:
        s=stats[key][a];shown={'bare':'Bare','retry':'Retry','nawah':'NAWAH','nawah_adapter':'Repair adapter'}[a]
        summary.append([lab,shown,num(f'{s["k"]}/{s["n"]}'),num(f'{s["rate"]*100:.2f}%'),num(s['calls']),num(f'{s["mean_calls"]:.4f}')])
        cirows.append([lab,shown,num(f'{s["rate"]*100:.2f}'),num(f'[{s["wilson95"][0]*100:.4f}, {s["wilson95"][1]*100:.4f}]')])

def taskrows(rows,keys):
    return [[num(r.get('task',r.get('id')))]+[num(f'{int(r["arms"][a]["passed"])} · {r["arms"][a]["calls"]}') for a in keys] for r in rows]
heads=['المهمة','Bare: نجاح · طلبات','Retry: نجاح · طلبات','NAWAH: نجاح · طلبات']
test=[r for r in v5 if r['phase']=='test'];dev=[r for r in v5 if r['phase']=='dev']
replacements={
 'SUMMARY_TABLE':table('جدول 3. ملخص نتائج المهام وطلبات الواجهة؛ المقامات والدراسات لا تدمج.',['المجموعة','الذراع','نجاح / n','النسبة','الطلبات','متوسط الطلبات'],summary),
 'V5_TASK_TABLE':table('جدول أ1. كل مهام اختبار v5 (n=16).',heads,taskrows(test,['bare','retry','nawah'])),
 'PILOT_TASK_TABLE':table('جدول أ2. كل مهام التجربة الأولية؛ عمود NAWAH هنا يعني Repair adapter.',heads,taskrows(pilot,['bare','retry','nawah_adapter'])),
 'DEV_TASK_TABLE':table('جدول أ3. كل مهام تطوير v5 (n=8).',heads,taskrows(dev,['bare','retry','nawah'])),
 'CI_TABLE':table('جدول أ5. فواصل Wilson الاسمية 95%، بوحدة النسبة المئوية؛ افتراضاتها في §5.',['المجموعة','الذراع','النسبة','الفاصل الاسمي'],cirows),
}
v6rows=[]
for r in v6:
    for a in ['bare','retry','nawah']:
        x=r['arms'][a]
        v6rows.append([r['task'],a,num(int(x['public_passed'])),num(int(x['heldout_passed'])),num(f'{sum(t["ok"] for t in x["heldout_results"])}/{len(x["heldout_results"])}'),num(x['calls'])])
replacements['V6_TABLE']=table('جدول أ4. كل حالات v6 وأذرعها؛ نجاح الاختبار الفردي لا يساوي نجاح المهمة.',['الحالة','الذراع','نجاح العلني','نجاح المحجوب كاملًا','اختبارات محجوبة','طلبات'],v6rows)
pr=[]
for k,label in [('v5_nawah_vs_bare','v5: NAWAH مقابل Bare'),('v5_nawah_vs_retry','v5: NAWAH مقابل Retry'),('pilot_retry_vs_bare','الأولية: Retry مقابل Bare'),('v6_nawah_vs_bare','v6: NAWAH مقابل Bare')]:
    x=stats['paired'][k];pr.append([label,num(x['both']),num(x['neither']),num(x['wins']),num(x['losses']),num(f'{100*x["delta"]:.4f}'),num('N/A' if x['exact_p'] is None else f'{x["exact_p"]:.4f}')])
replacements['PAIR_TABLE']=table('جدول أ6. المقارنات المقترنة. الانفراد بالنجاح يقاس للذراع المذكور أولًا.',['المقارنة','نجاح مشترك','فشل مشترك','ربح','خسارة','فرق نقطة مئوية','p استكشافية'],pr)
paths=['public_bench/data/mbpp.json','public_bench/data/HumanEval.jsonl.gz','public_bench/results.json','public_bench/manifest.json','nawah_v5/results.json','nawah_v5/manifest.json','nawah_v6/demo_results.json','nawah_v6/demo_manifest.json','nawah_v6/repo_agent.py']
hashes={p:hashlib.sha256((BASE/p).read_bytes()).hexdigest() for p in paths}
replacements['HASH_TABLE']=table('جدول أ7. تعريف محتوى الملفات الأساسية محليًا.',['المسار','SHA-256'],[[f'<span class="small latin">{p}</span>',f'<div class="hash">{v}</div>'] for p,v in hashes.items()])
rawruns={str(p.relative_to(ROOT/'evidence/nawah_v6')):load(p) for p in (ROOT/'evidence/nawah_v6/runs').glob('*/*/result.json')}
evidence={'document':'NAWAH empirical audit; 2026-10-22; no new inference during paper preparation','analysis':stats,'pilot_results':load(BASE/'public_bench/results.json'),'v5_results':v5,'v6_results':v6,'v6_detailed_results':rawruns,'manifests':{p:load(BASE/p) for p in ['public_bench/manifest.json','nawah_v5/manifest.json','nawah_v6/demo_manifest.json']},'candidate_rechecks':load(ROOT/'audit/candidate_rechecks.json'),'hashes':hashes,'figure_sources':load(PAPER/'figure_sources.json'),'v6_restored_hash_checks':load(ROOT/'audit/restored_v6_hashes.json')}
replacements['EMBEDDED_JSON']=json.dumps(evidence,ensure_ascii=False).replace('<','\\u003c').replace('>','\\u003e').replace('&','\\u0026')
s=(PAPER/'manuscript.html.in').read_text()
for i,name in enumerate(names,1):s=s.replace('{{F'+str(i).zfill(2)+'}}',figure(i,name))
for k,v in replacements.items():s=s.replace('{{'+k+'}}',v)
assert '{{' not in s,'unresolved template marker'
(PAPER/'NAWAH_Research_Paper_AR.html').write_text(s)
(PAPER/'embedded_evidence.json').write_text(json.dumps(evidence,indent=2,ensure_ascii=False))
(ROOT/'audit/input_hashes.json').write_text(json.dumps(hashes,indent=2))
print('HTML bytes:',len(s.encode()),'figures:',len(names),'rows of paired observations:',len(load(ROOT/'audit/candidate_rechecks.json')))
