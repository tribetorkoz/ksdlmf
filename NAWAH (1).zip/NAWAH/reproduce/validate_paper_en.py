"""Consistency, statistics and offline-safety checks for the English manuscript."""
from pathlib import Path
import json, re, math, hashlib, os
from xml.etree import ElementTree
from bs4 import BeautifulSoup

ROOT = Path(__file__).resolve().parent.parent      # repository root
PAPER = ROOT / 'paper'
BASE = Path(os.environ.get('NAWAH_ARTIFACT_ROOT', str(ROOT / 'data')))
HTML = PAPER / 'NAWAH_Research_Paper_EN.html'
s = HTML.read_text()
soup = BeautifulSoup(s, 'html.parser')
stats = json.loads((PAPER / 'analysis.json').read_text())
checks, failures = [], []

def ok(name, cond, detail=''):
    checks.append({'check': name, 'pass': bool(cond), 'detail': detail})
    if not cond:
        failures.append(name + ' :: ' + detail)

# 1 no template residue
ok('no unresolved template marker', not re.search(r'\{\{[A-Za-z0-9_]+\}\}', s))

# 2 offline safety: no element may fetch a resource
bad = []
for tag in soup.find_all(True):
    for attr in ('src', 'srcset', 'data', 'poster'):
        v = tag.get(attr)
        if v:
            bad.append((tag.name, attr, v[:60]))
    if tag.name == 'link':
        bad.append(('link', 'href', (tag.get('href') or '')[:60]))
ok('no external resource attributes', not bad, str(bad[:4]))
ok('no network-capable css import', '@import' not in s and 'url(http' not in s)
ok('no <img> elements (all figures are inline SVG)', not soup.find_all('img'))
ok('script elements are local only', all((sc.get('src') in (None, '')) for sc in soup.find_all('script')),
   str([sc.get('src') for sc in soup.find_all('script')]))

# 3 internal anchors (toc, references, figure ids)
anchors = [a['href'][1:] for a in soup.select('a[href^="#"]')]
missing = sorted({a for a in anchors if not soup.find(id=a)})
ok('all internal anchors resolve', not missing, str(missing[:6]))

# 4 figure / table inventory
figs = soup.find_all('figure')
ok('14 figures', len(figs) == 14, str(len(figs)))
ok('14 inline SVG figures', len(soup.find_all('svg')) == 14, str(len(soup.find_all('svg'))))
ok('12 tables', len(soup.find_all('table')) == 12, str(len(soup.find_all('table'))))
ok('figure ids unique', len({f.get('id') for f in figs}) == 14)
ok('every figure has a caption', all(f.find('figcaption') for f in figs))

# 5 SVG XML validity, unique ids, monochrome palette
ids = []
xmlfail = []
for svg in soup.find_all('svg'):
    try:
        ElementTree.fromstring(str(svg))
    except Exception as e:                       # pragma: no cover
        xmlfail.append(str(e))
    ids += [t.get('id') for t in svg.find_all(id=True)]
ok('all SVG parse as XML', not xmlfail, str(xmlfail[:3]))
ok('SVG ids globally unique', len(ids) == len(set(ids)), f'{len(ids)} ids')
ok('aria-labelledby targets exist', all(soup.find(id=x) for svg in soup.find_all('svg')
                                        for x in (svg.get('aria-labelledby') or '').split()))
colours = {c.lower() for c in re.findall(r'(?:fill|stroke)="([^"]+)"', s)}
allowed = {'#000', '#fff', '#000000', '#ffffff', 'none', 'currentcolor'}
ok('monochrome palette only', colours <= allowed, str(sorted(colours - allowed)))
ok('no colour words outside palette', not re.search(r'(?:fill|stroke)="(?:red|blue|green|orange|purple|yellow)"', s))

# 6 summary numbers reproduce analysis.json
def pct(x): return f'{x*100:.2f}'
for key, arms in [('pilot', ['bare', 'retry', 'nawah_adapter']), ('v5_dev', ['bare', 'retry', 'nawah']),
                  ('v5_test', ['bare', 'retry', 'nawah']), ('v6', ['bare', 'retry', 'nawah'])]:
    for a in arms:
        st = stats[key][a]
        ok(f'summary k/n {key}/{a}', f'{st["k"]}/{st["n"]}' in s, f'{st["k"]}/{st["n"]}')
        ok(f'summary rate {key}/{a}', pct(st['rate']) in s, pct(st['rate']))

# 7 Wilson intervals recomputed independently from k/n
z = 1.959963984540054
def wilson(k, n):
    p = k / n
    c = p + z*z/(2*n)
    h = z*math.sqrt(p*(1-p)/n + z*z/(4*n*n))
    lo, hi = (c-h)/(1+z*z/n), (c+h)/(1+z*z/n)
    return lo, hi
for key, arms in [('pilot', ['bare', 'retry', 'nawah_adapter']), ('v5_dev', ['bare', 'retry', 'nawah']),
                  ('v5_test', ['bare', 'retry', 'nawah']), ('v6', ['bare', 'retry', 'nawah'])]:
    for a in arms:
        st = stats[key][a]
        lo, hi = wilson(st['k'], st['n'])
        ok(f'wilson numeric {key}/{a}', abs(lo-st['wilson95'][0]) < 1e-12 and abs(hi-st['wilson95'][1]) < 1e-12,
           f'{lo:.6f},{hi:.6f}')
        ok(f'wilson printed {key}/{a}', f'{lo*100:.4f}' in s and f'{hi*100:.4f}' in s)

# 8 exact conditional paired test recomputed by full enumeration
def exact(b, c):
    n = b + c
    if n == 0:
        return None
    tail = sum(math.comb(n, j) for j in range(0, min(b, c)+1)) / 2**n
    return min(1.0, 2*tail)
for name, x in stats['paired'].items():
    ok(f'paired counts {name}', f'>{x["both"]}<' in s and f'>{x["wins"]}<' in s and f'>{x["losses"]}<' in s)
    r = exact(x['wins'], x['losses'])
    ok(f'paired exact p {name}', (r is None and x['exact_p'] is None) or (r is not None and abs(r-x['exact_p']) < 1e-12),
       f'{r} vs {x["exact_p"]}')

# 9 audit: 156 recorded replays, all matching
re_ = json.loads((ROOT / 'audit/candidate_rechecks.json').read_text())
ok('156 recheck records', len(re_) == 156, str(len(re_)))
ok('all rechecks match', all(bool(r.get('match')) for r in re_), str(sum(bool(r.get('match')) for r in re_)))
ok('recheck split 72/72/12', (sum(1 for r in re_ if r.get('study') == 'pilot') == 72 and
                              sum(1 for r in re_ if r.get('study') in ('v5_dev', 'v5_test')) == 72 and
                              sum(1 for r in re_ if r.get('study') == 'v6') == 12),
   str({k: sum(1 for r in re_ if r.get('study') == k) for k in {r.get('study') for r in re_}}))
ok('paper states 156/156', '156/156' in s)

# 10 embedded JSON parses and agrees with the analysis
node = soup.find('script', id='evidence-json')
ev = json.loads(node.string)
ok('embedded evidence parses', isinstance(ev, dict) and 'analysis' in ev)
ok('embedded analysis matches analysis.json', ev['analysis'] == stats)
ok('embedded results match raw files', ev['v5_results'] == json.loads((BASE/'nawah_v5/results.json').read_text())
   and ev['pilot_results'] == json.loads((BASE/'public_bench/results.json').read_text()))
ok('embedded rechecks match audit file', ev['candidate_rechecks'] == re_)
ok('embedded JSON has no raw angle brackets', '<' not in node.string and '>' not in node.string)

# 11 hash table reproduces the files
for p, h in ev['hashes'].items():
    ok('hash entry ' + p, hashlib.sha256((BASE / p).read_bytes()).hexdigest() == h and h[:16] in s)

# 12 claim hygiene: forbidden overclaims absent
forbidden = ['state of the art', 'state-of-the-art', 'AGI has been achieved', 'proves general intelligence',
             'outperforms GPT', 'guarantees correctness', 'peer reviewed and accepted']
low = s.lower()
ok('no overclaim phrases', not any(f.lower() in low for f in forbidden),
   str([f for f in forbidden if f.lower() in low]))
ok('limitations section present', 'Threats to validity' in s)
ok('AI disclosure present', 'Disclosure of AI assistance' in s)
ok('authorship caveat present', 'qualifying human contributions' in s or 'must be determined by the holders' in s)
ok('no invented author list', 'Anonymous' not in s.split('<h1')[0])

report = {'file': HTML.name, 'bytes': HTML.stat().st_size, 'checks': len(checks),
          'passed': sum(c['pass'] for c in checks), 'failed': failures,
          'figures': len(figs), 'tables': len(soup.find_all('table')),
          'sha256': hashlib.sha256(HTML.read_bytes()).hexdigest()}
(ROOT / 'audit/validation_en.json').write_text(json.dumps(report, indent=2))
print(f"{report['passed']}/{report['checks']} checks passed; figures={report['figures']} tables={report['tables']} bytes={report['bytes']}")
for f in failures:
    print('FAIL:', f)
raise SystemExit(1 if failures else 0)
