"""Assemble the self-contained English manuscript (black-and-white, no network resources).

Reuses the same archived artefacts as the Arabic build: analysis.json, the raw
public_bench / v5 / v6 result files, the audit logs and the 14 SVG assets.
"""
from pathlib import Path
import json, re, html, hashlib, os

ROOT = Path(__file__).resolve().parent.parent      # repository root
PAPER = ROOT / 'paper'
BASE = Path(os.environ.get('NAWAH_ARTIFACT_ROOT', str(ROOT / 'data')))
load = lambda p: json.loads(Path(p).read_text())
stats = load(PAPER / 'analysis.json')
pilot = load(BASE / 'public_bench/results.json')['tasks']
v5 = load(BASE / 'nawah_v5/results.json')
v6 = load(BASE / 'nawah_v6/demo_results.json')
A = PAPER / 'assets'

# ---------------------------------------------------------------- figures 1-2
def text(x, y, s, size=16, anchor='middle', weight='normal'):
    return (f'<text x="{x}" y="{y}" text-anchor="{anchor}" font-family="Arial,sans-serif" '
            f'font-size="{size}" font-weight="{weight}" fill="#000">{html.escape(s)}</text>')

def box(x, y, w, h, lines):
    z = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#fff" stroke="#000" stroke-width="1.5"/>'
    for i, s in enumerate(lines):
        z += text(x + w / 2, y + 27 + i * 23, s, 15)
    return z

def diagram(name, title, content, height):
    svg = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 900 {height}" role="img" '
           f'aria-label="{title}"><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" '
           f'markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" '
           f'fill="#000"/></marker></defs><rect width="900" height="{height}" fill="#fff"/>{content}</svg>')
    (A / (name + '.svg')).write_text(svg)

def arrow(x1, y1, x2, y2, dash=False):
    return (f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#000" stroke-width="1.5" '
            f'marker-end="url(#arrow)"' + (' stroke-dasharray="6 4"' if dash else '') + '/>')

z = text(450, 28, 'v6: trusted inputs, bounded proposals, observed-test acceptance', 20, weight='bold')
z += box(20, 65, 175, 92, ['Issue + source', 'Editable paths', 'Trusted inputs'])
z += box(240, 65, 175, 92, ['Local fixed LLM', 'Full-file proposal', 'No weight updates'])
z += box(460, 65, 175, 92, ['Patch gate', 'Paths + syntax', 'Partial AST checks'])
z += box(680, 65, 195, 92, ['Temporary copy', 'Frozen public tests', 'Subprocess runner'])
for x1, x2 in [(195, 240), (415, 460), (635, 680)]:
    z += arrow(x1, 110, x2, 110)
z += box(680, 230, 195, 90, ['Acceptance rule', 'Keep passing IDs', 'Strict count gain'])
z += arrow(777, 157, 777, 230)
z += box(240, 230, 395, 90, ['Final candidate + diff + JSON / SQLite', 'No auto-apply to source',
                             'Audit persistence, not skill retrieval'])
z += arrow(680, 275, 635, 275)
z += box(20, 230, 175, 90, ['External evaluator', 'Held-out tests', 'After solve only'])
z += arrow(240, 275, 195, 275)
z += (f'<path d="M 680 300 L 655 300 L 655 355 L 220 355 L 220 190 L 330 190 L 330 157" fill="none" '
      'stroke="#000" stroke-width="1.5" stroke-dasharray="6 4" marker-end="url(#arrow)"/>')
z += text(490, 348, 'Next request, if budget remains', 13)
z += text(450, 395, 'Conceptual boundary diagram; worktree copies are NOT a security sandbox.', 14)
diagram('f01_architecture', 'Conceptual v6 architecture, not measured performance', z, 415)

z = text(450, 27, 'Three distinct cohorts; no pooled success rate', 20, weight='bold')
z += box(20, 58, 270, 100, ['A · pilot: 24 public tasks', 'HumanEval 12 + MBPP 12', '384 tokens / request'])
z += box(315, 58, 270, 100, ['B · v5: MBPP split', 'Development 8 / test 16', '512 tokens / request'])
z += box(610, 58, 270, 100, ['C · v6: 4 authored fixtures', 'Small trusted repositories', '512 tokens / request'])
for x in [155, 450, 745]:
    z += arrow(x, 158, x, 207)
z += box(20, 207, 270, 70, ['72 saved arm-task outcomes', '24 tasks × 3 arms'])
z += box(315, 207, 270, 70, ['72 saved arm-task outcomes', '24 tasks × 3 arms'])
z += box(610, 207, 270, 70, ['12 saved arm-task outcomes', '4 fixtures × 3 arms'])
for x in [155, 450, 745]:
    z += f'<path d="M {x} 277 L {x} 310 L 450 310" fill="none" stroke="#000" stroke-width="1.5"/>'
z += arrow(450, 310, 450, 340)
z += box(180, 340, 540, 73, ['Current audit: re-run saved candidates on the SAME tests',
                             '156 / 156 binary outcomes matched; no new model inference'])
z += text(450, 448, 'Conceptual protocol diagram. Rechecks do not add 156 independent tasks.', 14)
diagram('f02_protocol', 'Conceptual study cohorts and execution audit', z, 465)

# ---------------------------------------------------------------- captions
captions = {
 1: ('Conceptual architecture of v6', 'Conceptual rendering',
     'Trusted-source boundary, model proposal, patch gate, test execution and candidate persistence. '
     'The dashed arrow is a later request within the remaining budget; the held-out evaluation happens after solving ends. '
     'File copies are not a sandbox.', 'repo_agent.py; conceptual rendering'),
 2: ('Protocol diagram and the denominator of each arm', 'Conceptual rendering',
     'The studies form three separate cohorts. The recheck collects 156 arm-task records, not 156 new tasks; '
     'each evaluation uses the same candidate and the same tests.', 'manifests; candidate_rechecks.json; conceptual rendering'),
 3: ('Pilot success counts by arm', 'Archived measurements',
     'Each bar is the number of solved tasks out of its group denominator. The Repair adapter is the early adapter, '
     'not v6 and not the evaluation of the whole original project. The Combined grouping must not be read as a new independent study.',
     'public_bench/results.json'),
 4: ('Development and test counts in v5', 'Archived measurements',
     'Development is not merged with test. No gain on development and a one-task gain on test. Hatching separates arms without colour.',
     'nawah_v5/results.json; phase'),
 5: ('Point estimates with Wilson intervals', 'Analytical calculation from measurements',
     'Task success proportions with nominal 95% Wilson intervals from Eq. (3). These are not standard deviations across runs, '
     'and they guarantee no coverage of a general task population; interpretation conditions are in §5.2.',
     'analysis.json; k/n; Wilson closed-form calculation'),
 6: ('Per-task success matrix for the v5 test split', 'Archived measurements',
     'A black cell is 1 (all hidden tests pass), a white cell is 0 (failure). The only difference between arms is MBPP/388. '
     'Row order follows the manifest, not time.', 'nawah_v5/results.json; test split'),
 7: ('Paired comparison matrix for v5', 'Direct enumeration',
     'Rows are bare and columns are NAWAH: 10 shared successes, 5 shared failures, one task solved by NAWAH alone and none by the comparator alone. '
     'The exploratory conditional test value is p = 1.0.', 'v5 test paired outcomes; exact enumeration'),
 8: ('Stacked counts of the public-test gap', 'Archived measurements',
     'In every arm two tasks pass the visible example and fail the hidden tests. No case passes hidden while failing public in this sample. '
     'The segments sum to 16 tasks per arm.', 'v5 test status and passed fields'),
 9: ('Effort: success against interface requests', 'Analytical calculation from measurements',
     'Points are summary values for the three v5 test arms: mean requests against task success rate, from Eq. (2). '
     'The horizontal axis is not seconds, tokens or money; requests may include cache hits.', 'v5 test calls and passed fields'),
 10: ('Distribution of request counts', 'Archived measurements',
      'How many tasks used 1, 2 or 3 requests. Each arm column sums to 16. This is a discrete histogram of recorded requests, '
      'not a re-run budget experiment.', 'v5 test calls field'),
 11: ('Individual v6 tests by fixture', 'Archived measurements',
      'Hidden tests passed inside each fixture. Denominators are 4, 4, 4 and 3; these are correlated tests inside four cases, '
      'not 15 independent tasks. Every arm fails the headers fixture outright.', 'nawah_v6/demo_results.json; heldout_results'),
 12: ('Slope chart: initial and final candidate in v6', 'Archived measurements',
      'Shows NAWAH alone on public tests. Line ends are offset horizontally by a small amount to separate identical cases '
      'without changing any vertical value. No causal effect relative to the other arms can be inferred.',
      'v6 runs/*/nawah/result.json; initial_tests and final_public_tests'),
 13: ('Attempt timeline for MBPP/388', 'Archived measurements',
      'The horizontal axis is candidate index, not time. The lines show public-example success for each attempt that actually exists '
      'and stop at the last attempt without being extended by assumed data. Hidden results for intermediate candidates are not shown.',
      'v5 test MBPP/388; history[].passed'),
 14: ('Distribution of final outcomes in the pilot', 'Counts with a declared taxonomy',
      'Stacked horizontal bars summing to 24 tasks. Syntax is a format rejection, Assertion an assertion failure, and Runtime groups '
      'TypeError and IndexError. The taxonomy describes the recorded exit reason and does not establish the root cause.',
      'public_bench/results.json; reason; taxonomy in analyze.py'),
}
names = ['f01_architecture', 'f02_protocol', 'f03_pilot', 'f04_v5', 'f05_intervals', 'f06_task_matrix',
         'f07_paired', 'f08_public_gap', 'f09_effort', 'f10_calls', 'f11_v6_tests', 'f12_v6_slope',
         'f13_progress', 'f14_failures']

def svg_inline(p, prefix):
    s = p.read_text()
    s = s[s.find('<svg'):]
    s = re.sub(r'<metadata>.*?</metadata>', '', s, flags=re.S)
    ids = re.findall(r'\bid="([^"]+)"', s)
    for ident in sorted(set(ids), key=len, reverse=True):
        s = (s.replace('id="' + ident + '"', 'id="' + prefix + '_' + ident + '"')
              .replace('url(#' + ident + ')', 'url(#' + prefix + '_' + ident + ')')
              .replace('href="#' + ident + '"', 'href="#' + prefix + '_' + ident + '"'))
    s = s.replace('<svg ', '<svg role="img" aria-labelledby="' + prefix + '_title ' + prefix + '_desc" ', 1)
    s = s.replace('role="img" aria-label="Conceptual v6 architecture, not measured performance"', '')
    s = s.replace('role="img" aria-label="Conceptual study cohorts and execution audit"', '')
    start = s.find('>') + 1
    num = int(prefix[1:])
    title, typ, desc, source = captions[num]
    s = (s[:start] + f'<title id="{prefix}_title">{html.escape(title)}</title>'
         f'<desc id="{prefix}_desc">{html.escape(desc)}</desc>' + s[start:])
    return s

def figure(i, name):
    title, typ, desc, src = captions[i]
    return (f'<figure class="fig" id="fig{i}">{svg_inline(A / (name + ".svg"), "f" + str(i))}'
            f'<figcaption class="figcap"><b>Fig. {i}.</b> {html.escape(title)}.'
            f'<span class="figtype">{typ}</span> {html.escape(desc)}'
            f'<span class="source">Source: {html.escape(src)}</span></figcaption></figure>')

def table(caption, headers, rows):
    return ('<div class="tw"><table class="data"><caption>' + caption + '</caption><thead><tr>'
            + ''.join('<th scope="col">' + x + '</th>' for x in headers) + '</tr></thead><tbody>'
            + ''.join('<tr>' + ''.join('<td>' + str(x) + '</td>' for x in row) + '</tr>' for row in rows)
            + '</tbody></table></div>')

def num(x):
    return '<span dir="ltr">' + str(x) + '</span>'

# ---------------------------------------------------------------- tables
coh = [('Pilot (A)', 'pilot', ['bare', 'retry', 'nawah_adapter']),
       ('v5 development (B)', 'v5_dev', ['bare', 'retry', 'nawah']),
       ('v5 test (B)', 'v5_test', ['bare', 'retry', 'nawah']),
       ('v6 integration (C)', 'v6', ['bare', 'retry', 'nawah'])]
ARM = {'bare': 'Bare', 'retry': 'Retry', 'nawah': 'NAWAH', 'nawah_adapter': 'Repair adapter'}
summary, cirows = [], []
for lab, key, arms in coh:
    for a in arms:
        s = stats[key][a]
        summary.append([lab, ARM[a], num(f'{s["k"]}/{s["n"]}'), num(f'{s["rate"]*100:.2f}%'),
                        num(s['calls']), num(f'{s["mean_calls"]:.4f}')])
        cirows.append([lab, ARM[a], num(f'{s["rate"]*100:.2f}'),
                       num(f'[{s["wilson95"][0]*100:.4f}, {s["wilson95"][1]*100:.4f}]')])

def taskrows(rows, keys):
    return [[num(r.get('task', r.get('id')))]
            + [num(f'{int(r["arms"][a]["passed"])} · {r["arms"][a]["calls"]}') for a in keys]
            for r in rows]

heads = ['Task', 'Bare: pass · requests', 'Retry: pass · requests', 'NAWAH: pass · requests']
test = [r for r in v5 if r['phase'] == 'test']
dev = [r for r in v5 if r['phase'] == 'dev']

replacements = {
 'SUMMARY_TABLE': table('<b>Table 4.</b> Task outcomes and interface requests by study and arm; denominators and studies are never pooled.',
                        ['Study', 'Arm', 'Success / n', 'Rate', 'Requests', 'Mean requests'], summary),
 'V5_TASK_TABLE': table('<b>Table A1.</b> Every v5 test task (n = 16).', heads, taskrows(test, ['bare', 'retry', 'nawah'])),
 'PILOT_TASK_TABLE': table('<b>Table A2.</b> Every pilot task; the NAWAH column here is the repair adapter.', heads,
                           taskrows(pilot, ['bare', 'retry', 'nawah_adapter'])),
 'DEV_TASK_TABLE': table('<b>Table A3.</b> Every v5 development task (n = 8).', heads, taskrows(dev, ['bare', 'retry', 'nawah'])),
 'CI_TABLE': table('<b>Table A5.</b> Nominal 95% Wilson intervals in percent; assumptions are stated in §5.2.',
                   ['Study', 'Arm', 'Rate', 'Nominal interval'], cirows),
}
v6rows = []
for r in v6:
    for a in ['bare', 'retry', 'nawah']:
        x = r['arms'][a]
        v6rows.append([r['task'], ARM[a], num(int(x['public_passed'])), num(int(x['heldout_passed'])),
                       num(f'{sum(t["ok"] for t in x["heldout_results"])}/{len(x["heldout_results"])}'),
                       num(x['calls'])])
replacements['V6_TABLE'] = table('<b>Table A4.</b> All v6 fixtures and arms; individual-test success is not task success.',
                                 ['Fixture', 'Arm', 'Public pass', 'All hidden pass', 'Hidden tests passed', 'Requests'], v6rows)
pr = []
for k, label in [('v5_nawah_vs_bare', 'v5: NAWAH vs Bare'), ('v5_nawah_vs_retry', 'v5: NAWAH vs Retry'),
                 ('pilot_retry_vs_bare', 'Pilot: Retry vs Bare'), ('v6_nawah_vs_bare', 'v6: NAWAH vs Bare')]:
    x = stats['paired'][k]
    pr.append([label, num(x['both']), num(x['neither']), num(x['wins']), num(x['losses']),
               num(f'{100*x["delta"]:.4f}'),
               num('not evaluable' if x['exact_p'] is None else f'{x["exact_p"]:.4f}')])
replacements['PAIR_TABLE'] = table('<b>Table A6.</b> Paired comparisons; a win is a task solved by the first-named arm alone.',
                                   ['Comparison', 'Both solved', 'Neither solved', 'Wins', 'Losses', 'Difference (pp)', 'Exploratory p'], pr)

paths = ['public_bench/data/mbpp.json', 'public_bench/data/HumanEval.jsonl.gz', 'public_bench/results.json',
         'public_bench/manifest.json', 'nawah_v5/results.json', 'nawah_v5/manifest.json',
         'nawah_v6/demo_results.json', 'nawah_v6/demo_manifest.json', 'nawah_v6/repo_agent.py']
hashes = {p: hashlib.sha256((BASE / p).read_bytes()).hexdigest() for p in paths}
replacements['HASH_TABLE'] = table('<b>Table A7.</b> Content hashes of the core local files.',
                                   ['Path', 'SHA-256'],
                                   [[f'<span class="small">{p}</span>', f'<code>{v}</code>'] for p, v in hashes.items()])

# ---------------------------------------------------------------- embedded evidence
rawruns = {str(p.relative_to(ROOT / 'evidence/nawah_v6')): load(p)
           for p in (ROOT / 'evidence/nawah_v6/runs').glob('*/*/result.json')}
evidence = {
  'document': 'NAWAH empirical audit; 2026-10-22; no new inference during paper preparation',
  'analysis': stats,
  'pilot_results': load(BASE / 'public_bench/results.json'),
  'v5_results': v5,
  'v6_results': v6,
  'v6_detailed_results': rawruns,
  'manifests': {p: load(BASE / p) for p in ['public_bench/manifest.json', 'nawah_v5/manifest.json', 'nawah_v6/demo_manifest.json']},
  'candidate_rechecks': load(ROOT / 'audit/candidate_rechecks.json'),
  'hashes': hashes,
  'figure_sources': load(PAPER / 'figure_sources.json'),
  'v6_restored_hash_checks': load(ROOT / 'audit/restored_v6_hashes.json'),
}
replacements['EMBEDDED_JSON'] = (json.dumps(evidence, ensure_ascii=False)
                                 .replace('<', '\\u003c').replace('>', '\\u003e').replace('&', '\\u0026'))

s = (PAPER / 'manuscript_en.html.in').read_text()
for i, name in enumerate(names, 1):
    s = s.replace('{{F' + str(i).zfill(2) + '}}', figure(i, name))
for k, v in replacements.items():
    s = s.replace('{{' + k + '}}', v)
assert '{{' not in s, 'unresolved template marker'
out = PAPER / 'NAWAH_Research_Paper_EN.html'
out.write_text(s)
print('HTML bytes:', len(s.encode()), 'figures:', len(names), 'tables:', s.count('<table class="data">'),
      'recheck rows:', len(load(ROOT / 'audit/candidate_rechecks.json')))
