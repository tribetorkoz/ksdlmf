"""محوّل النموذج الحقيقي: llama.cpp + ذاكرة مؤقتة على القرص.

تشارك نفس ذاكرة nawah_real كي لا نعيد ما دُفع ثمنه مرة.
"""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

CACHE_PATHS = [
    Path("/home/user/nawah_v4/llm_cache.json"),
    Path("/home/user/nawah_real/llm_cache.json"),
]

STATS = {"calls": 0, "hits": 0, "sec": 0.0}


def _load_cache() -> dict:
    merged: dict = {}
    for p in reversed(CACHE_PATHS):
        if p.exists():
            try:
                merged.update(json.loads(p.read_text(encoding="utf-8")))
            except Exception:
                pass
    return merged


CACHE = _load_cache()


def flush_cache(extra: dict | None = None):
    out = dict(CACHE)
    if extra:
        out.update(extra)
    CACHE_PATHS[0].write_text(json.dumps(out, ensure_ascii=False),
                              encoding="utf-8")


class LLM:
    def __init__(self, model_path: str, n_ctx: int = 1024, n_threads: int = 2,
                 max_tokens: int = 48):
        from llama_cpp import Llama
        self.path = model_path
        self.tag = Path(model_path).stem
        self.max_tokens = max_tokens
        self.llm = Llama(model_path=model_path, n_ctx=n_ctx,
                         n_threads=n_threads, verbose=False)

    def __call__(self, prompt: str, system: str = "", max_tokens: int | None = None) -> str:
        mt = max_tokens or self.max_tokens
        key = hashlib.sha256(
            f"{self.tag}|{mt}|{system}|{prompt}".encode()).hexdigest()
        if key in CACHE:
            STATS["hits"] += 1
            return CACHE[key]
        t0 = time.time()
        out = self.llm.create_chat_completion(
            messages=[
                {"role": "system",
                 "content": system or "You are a precise engineering assistant."},
                {"role": "user", "content": prompt},
            ],
            max_tokens=mt, temperature=0.0, top_p=1.0,
        )
        STATS["calls"] += 1
        STATS["sec"] += time.time() - t0
        text = (out["choices"][0]["message"]["content"] or "").strip()
        CACHE[key] = text
        if STATS["calls"] % 25 == 0:
            flush_cache()
        return text


class DualLLM:
    """كاتب كبير + عامل صغير: التوليف للكاتب، وحلّ المهام للعامل.

    الفكرة: الكتابة (تحويل وصف إلى دالة) هي المكان الذي تظهر فيه جودة
    النموذج؛ والتطبيق لا يحتاج كبيرًا إن كانت المهارة مكتوبة جيدًا.
    يُختبر هذا بتقديم مُلَوِّنات صحيحة: هل يقترب العامل الصغير + الكاتب
    الكبير من مستوى النموذج الكبير وحده؟
    """

    SYNTH_HEADS = (
        "Write a reusable Python function",
        "Your function fails",
        "Your function is wrong",
        "Write a Python function",
    )

    def __init__(self, worker, writer):
        self.worker, self.writer = worker, writer

    def __call__(self, prompt: str, system: str = "", max_tokens: int | None = None) -> str:
        head = (prompt or "").lstrip()[:40]
        target = (self.writer
                  if head.startswith(self.SYNTH_HEADS) else self.worker)
        return target(prompt, system=system, max_tokens=max_tokens)
