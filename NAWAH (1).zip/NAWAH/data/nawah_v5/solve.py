#!/usr/bin/env python3
"""Solve a trusted local coding specification with public examples.
Never run on hostile user uploads. The executor is not a hardened sandbox.
Usage: python3 solve.py example_task.json --model /path/to/model.gguf
"""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));sys.path.insert(0,'/home/user/nawah_v4')
from agent import CodingAgent,CodingTask,Memory
from v4.llm import LLM,flush_cache

def main():
    p=argparse.ArgumentParser()
    p.add_argument('task');p.add_argument('--model',required=True)
    p.add_argument('--budget',type=int,default=3)
    p.add_argument('--out',default='solution.json')
    p.add_argument('--memory',default='audit.sqlite')
    a=p.parse_args();d=json.loads(Path(a.task).read_text())
    allowed={'key','specification','public_tests','test_imports'}
    if set(d)-allowed:raise ValueError('Unknown task fields. Do not include hidden tests or reference answers.')
    task=CodingTask(**d)
    llm=LLM(a.model,n_ctx=2048,n_threads=2,max_tokens=512)
    m=Memory(a.memory)
    result=CodingAgent(llm,budget=a.budget,memory=m).solve(task)
    Path(a.out).write_text(json.dumps(result,ensure_ascii=False,indent=2))
    flush_cache();m.close()
    print(result['status'], 'calls:',result['calls'])
    print(result['selected']['code'])
if __name__=='__main__':main()
