#!/usr/bin/env python3
"""Pre-registered new MBPP split: development then untouched test, no tuning
between phases. Prior pilot tasks excluded. Hidden outcomes never reach agent.
"""
import argparse,hashlib,json,random,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));sys.path.insert(0,'/home/user/nawah_v4')
from agent import CodingAgent,CodingTask,Memory,execute
from v4.llm import LLM,flush_cache
DATA=Path('/home/user/public_bench/data/mbpp.json')

def prepare():
    all_tasks=json.loads(DATA.read_text())
    old=set(json.loads(Path('/home/user/public_bench/manifest.json').read_text())['ids'])
    rng=random.Random(5032026)
    dev=rng.sample([t for t in all_tasks if 511<=t['task_id']<=600],8)
    test=rng.sample([t for t in all_tasks if 11<=t['task_id']<=510 and 'MBPP/'+str(t['task_id']) not in old],16)
    manifest={'seed':5032026,'dataset_sha256':hashlib.sha256(DATA.read_bytes()).hexdigest(),
       'dev_ids':[t['task_id'] for t in dev],'test_ids':[t['task_id'] for t in test],
       'budget':3,'max_tokens':512,'visible':'first original test only',
       'heldout':'remaining original tests','protocol':'same first prompt; one draft vs up-to-three independent/repair candidates; selection by public tests only; no changes between dev/test; no cross-task retrieval.'}
    target=ROOT/'manifest.json'
    if target.exists() and json.loads(target.read_text())!=manifest:raise ValueError('manifest changed')
    target.write_text(json.dumps(manifest,indent=2))
    return dev,test

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--prepare-only',action='store_true');args=ap.parse_args()
    dev,test=prepare()
    sanity=[]
    for phase,ts in [('dev',dev),('test',test)]:
        for t in ts:
            imp='\n'.join(t.get('test_imports',[]))
            ok,why=execute(t['code'],imp+'\n'+'\n'.join(t['test_list']))
            sanity.append({'phase':phase,'id':t['task_id'],'ok':ok,'reason':why})
    (ROOT/'sanity.json').write_text(json.dumps(sanity,indent=2))
    if not all(s['ok'] for s in sanity):raise ValueError('Reference harness failure. No generation allowed.')
    if args.prepare_only:print('Prepared',len(sanity),'reference tasks, all passed');return
    llm=LLM('/home/user/models/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf',n_ctx=2048,n_threads=2,max_tokens=512)
    memory=Memory(str(ROOT/'audit.sqlite'))
    agent=CodingAgent(llm,budget=3,max_tokens=512,memory=memory)
    p=ROOT/'results.json';results=json.loads(p.read_text()) if p.exists() else []
    for phase,ts in [('dev',dev),('test',test)]:
        for t in ts:
            key='MBPP/'+str(t['task_id'])
            if any(x['task']==key for x in results):continue
            imp='\n'.join(t.get('test_imports',[]))
            task=CodingTask(key,t['prompt'],(t['test_list'][0],),imp)
            row={'phase':phase,'task':key,'arms':{}}
            for arm in ['bare','retry','nawah']:
                result=agent.solve(task,strategy=arm)
                # Scoring only after final selection. Never send hidden tests/results to solver.
                ok,why=execute(result['selected']['code'],imp+'\n'+'\n'.join(t['test_list'][1:]))
                row['arms'][arm]={'passed':ok,'hidden_reason':why,**result}
            results.append(row);p.write_text(json.dumps(results,indent=2,ensure_ascii=False));flush_cache()
            print(phase,key,{a:r['passed'] for a,r in row['arms'].items()},flush=True)
    memory.close();print('DONE',flush=True)
if __name__=='__main__':main()
