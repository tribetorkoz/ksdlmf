"""NAWAH v5: bounded coding search with explicit public contract.

No hidden-test/expected-answer access in the agent API. This is a coding
research agent, NOT AGI. Execution delegates to the pilot subprocess runner;
that runner is defense-in-depth, not an adversarial security sandbox.
"""
from dataclasses import dataclass, asdict
import ast
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
sys.path.insert(0, '/home/user/public_bench')
from run_public import execute, extract

@dataclass(frozen=True)
class CodingTask:
    key: str
    specification: str
    public_tests: tuple[str, ...]
    test_imports: str = ''

@dataclass
class Candidate:
    code: str
    passed: int
    total: int
    syntax_ok: bool
    errors: list
    source: str

    @property
    def rank(self):
        return (self.passed, self.syntax_ok)

class Memory:
    """Persistent audit artifacts only; never a hidden-answer store."""
    def __init__(self, path):
        self.db=sqlite3.connect(path)
        self.db.execute('CREATE TABLE IF NOT EXISTS artifacts (task TEXT, spec_hash TEXT, payload TEXT)')
    def put(self, task, result):
        self.db.execute('INSERT INTO artifacts VALUES (?,?,?)',
            (task.key,hashlib.sha256(task.specification.encode()).hexdigest(),json.dumps(result)))
        self.db.commit()
    def count(self):
        return self.db.execute('SELECT count(*) FROM artifacts').fetchone()[0]
    def close(self): self.db.close()

def assess(code, task, source='draft', runner=execute):
    try: ast.parse(code); syntax=True
    except SyntaxError: syntax=False
    # No tests means no evidence, NOT a declaration of correctness.
    passed=0; errors=[]
    for test in task.public_tests:
        ok,why=runner(code,task.test_imports+'\n'+test)
        passed+=int(ok)
        if not ok: errors.append({'test':test,'reason':why})
    return Candidate(code,passed,len(task.public_tests),syntax,errors,source)

def plan(task):
    """Deterministic work plan; do not pretend this is general reasoning."""
    return {'goal':'Implement the specified function',
            'verification':'Execute caller-supplied public examples only',
            'steps':['draft','check signature/syntax/examples',
                     'repair or independently regenerate',
                     'retain best verified-so-far candidate'],
            'uncertainty':'Visible examples are incomplete; hidden behavior remains unknown.'}

class CodingAgent:
    def __init__(self,llm,budget=3,max_tokens=512,memory=None,runner=execute):
        if budget<1: raise ValueError('budget must be >= 1')
        self.llm=llm;self.budget=budget;self.max_tokens=max_tokens
        self.memory=memory;self.runner=runner

    def solve(self,task,strategy='nawah'):
        if strategy not in ('nawah','retry','bare'):raise ValueError('unknown strategy')
        base=('Implement the specification as a complete reusable Python function. '
              'Preserve exactly the function name and call signature required by the examples. '
              'Return a single python code block, no prose.\nSPECIFICATION:\n'+task.specification+
              '\nPUBLIC EXAMPLES:\n'+'\n'.join(task.public_tests))
        best=None;history=[];calls=0
        limit=1 if strategy=='bare' else self.budget
        for i in range(limit):
            if i==0:prompt=base
            elif strategy=='retry' or i%2==0:
                prompt=base+'\nUse a different algorithm. Check boundary cases, input types, and the exact signature. '
                if i>1:prompt+='Avoid repeating this failed draft:\n'+history[-1]['code']
            else:
                prompt=(base+'\nRepair this draft without changing the required interface:\n'+best.code+
                        '\nFailures on public examples:\n'+json.dumps(best.errors,ensure_ascii=False)+
                        '\nKeep working behavior; return complete code, not a diff.')
            raw=self.llm(prompt,max_tokens=self.max_tokens);calls+=1
            code=extract(raw)
            cand=assess(code,task,'draft' if not i else ('repair' if strategy=='nawah' and i%2 else 'regenerate'),self.runner)
            history.append(asdict(cand))
            # Strict improvement only; a bad repair never overwrites a stronger draft.
            if best is None or cand.rank>best.rank:best=cand
            if best.total>0 and best.passed==best.total and best.syntax_ok:break
        result={'task':task.key,'strategy':strategy,'calls':calls,'plan':plan(task),
                'selected':asdict(best),'history':history,
                'status':('public_examples_passed' if best.total>0 and best.passed==best.total and best.syntax_ok
                          else 'needs_review')}
        if self.memory:self.memory.put(task,result)
        return result
