# NAWAH v5 — bounded, verifiable coding agent

## What this is
A small-model coding research agent with explicit public contracts, bounded search, non-regressing visible-test selection, and a persistent audit log. **Not AGI, not a production security sandbox.**

## Components
- `agent.py`: task contract, deterministic work plan, candidate verification, alternating repair/regeneration, visible-test ranking, SQLite artifacts.
- `solve.py`: command-line interface for trusted local tasks.
- `example_task.json` / `example_solution.json`: real executed column-header normalization example (four public assertions).
- `evaluate.py`: fixed development/test split on sanitized MBPP; external scoring never reaches agent.
- `manifest.json`: split IDs, data hash and protocol fixed before inference.
- `sanity.json`: all 24 official reference solutions passed executor before model generation.
- `results.json`: all drafts, public feedback, final selections, external scores and model invocation counts.
- `tests/test_agent.py`: ten functional tests, including rollback, budget, no-test uncertainty and persistent audit.

## Run
This workspace version imports the adjacent `nawah_v4` LLM backend and `public_bench` executor; it is not a standalone pip package.

```bash
pip install --only-binary :all: llama-cpp-python==0.3.36 \
  --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu
python3 -m unittest discover -s tests -v
python3 solve.py example_task.json \
  --model /home/user/models/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf \
  --out solution.json
python3 evaluate.py --prepare-only
python3 -u evaluate.py
```
Model weights are not included. Local model: Qwen2.5-Coder-1.5B-Instruct Q4_K_M, temperature 0, context 2048, maximum 512 generated tokens/call. Evaluation resumes completed tasks in `results.json`.

## Measured, not promised
| Split | N | Single draft | Independent retry | NAWAH v5 |
|---|---:|---:|---:|---:|
| Development | 8 | 5 | 5 | 5 |
| New test | 16 | 10 | 10 | 11 |

Maximum three model calls for retry and NAWAH, one for bare. Mean test calls: 1.00 / 1.50 / 1.4375. Stop once all public examples pass. Hidden tests never trigger retries. Only MBPP/388 changed outcome in NAWAH's favor versus retry: **one paired gain, not strong statistical evidence**.

## Scope limits
- No learned general planner: `plan()` is a fixed coding workflow.
- Audit storage is memory of artifacts, not automatic general skill transfer. No claim of continual learning here.
- Public examples passing does not imply hidden behavior correctness. Rank can preserve visible behavior while hidden behavior regresses.
- No model weight training or increased base intelligence.
- Data is public and may have occurred in model pretraining; disjoint local IDs do not imply contamination-free evaluation.
- Original MBPP, custom first-test-visible protocol; not MBPP+ or an official leaderboard result.
- Public benchmark executor has privilege/resource/AST restrictions but is not hardened against arbitrary hostile Python. Use trusted local tasks only.
- No changes were made between development and final test. Do not tune on this final test after seeing results.

See `PROGRESS_AR.md` for the Arabic assessment and next-stage acceptance criteria.
