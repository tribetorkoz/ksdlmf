import json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from agent import CodingAgent,CodingTask,Memory,assess

class Scripted:
    def __init__(self,answers):self.answers=iter(answers);self.prompts=[]
    def __call__(self,p,max_tokens=None):self.prompts.append(p);return next(self.answers)

def runner(code,test):
    if code=='def f(x): return x':return ('case1' in test,'public failure')
    if code=='def f(x): return x + 1':return (True,'passed')
    return (False,'syntax')

class AgentTests(unittest.TestCase):
    def test_no_hidden_answer_field(self):
        self.assertNotIn('hidden',CodingTask.__dataclass_fields__)
        self.assertNotIn('reference',CodingTask.__dataclass_fields__)
    def test_repair_cannot_destroy_best(self):
        llm=Scripted(['def f(x): return x','bad syntax','also bad'])
        a=CodingAgent(llm,budget=3,runner=runner)
        r=a.solve(CodingTask('t','increment',('case1','case2')))
        self.assertEqual(r['selected']['passed'],1)
        self.assertEqual(r['selected']['code'],'def f(x): return x')
        self.assertEqual(r['status'],'needs_review')
    def test_early_stop(self):
        llm=Scripted(['def f(x): return x + 1'])
        r=CodingAgent(llm,runner=runner).solve(CodingTask('t','increment',('case2',)))
        self.assertEqual(r['calls'],1)
        self.assertEqual(r['status'],'public_examples_passed')
    def test_repair_improves(self):
        llm=Scripted(['def f(x): return x','def f(x): return x + 1'])
        r=CodingAgent(llm,runner=runner).solve(CodingTask('t','increment',('case1','case2')))
        self.assertEqual(r['calls'],2)
        self.assertEqual(r['selected']['passed'],2)
    def test_budget(self):
        llm=Scripted(['bad']*3)
        r=CodingAgent(llm,runner=runner).solve(CodingTask('t','increment',('case1',)))
        self.assertEqual(r['calls'],3)
    def test_bare_one_call(self):
        llm=Scripted(['bad'])
        r=CodingAgent(llm,runner=runner).solve(CodingTask('t','increment',('case1',)),strategy='bare')
        self.assertEqual(r['calls'],1)
    def test_no_tests_no_certainty(self):
        llm=Scripted(['def f(x): return x']*3)
        r=CodingAgent(llm,runner=runner).solve(CodingTask('t','increment',()))
        self.assertEqual(r['status'],'needs_review')
    def test_memory_survives_restart(self):
        with tempfile.TemporaryDirectory() as d:
            p=str(Path(d)/'m.sqlite');m=Memory(p)
            r=CodingAgent(Scripted(['def f(x): return x + 1']),memory=m,runner=runner).solve(CodingTask('t','increment',('case1',)))
            self.assertEqual(m.count(),1);m.close()
            m=Memory(p);self.assertEqual(m.count(),1);m.close()
    def test_invalid_budget(self):
        with self.assertRaises(ValueError):CodingAgent(None,budget=0)
    def test_execution_real(self):
        t=CodingTask('t','increment',('assert f(2)==3',))
        self.assertEqual(assess('def f(x): return x+1',t).passed,1)
        self.assertEqual(assess('def f(x): return x',t).passed,0)
if __name__=='__main__':unittest.main()
