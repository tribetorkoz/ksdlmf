"""NAWAH v6: transactional repair for small, TRUSTED local Python repos.

A worktree is a copy, not a security boundary. Model cannot propose test edits.
Tests are supplied by caller, outside the model patch interface. No arbitrary
shell command tool. This implementation is not an untrusted-code sandbox.
"""
from dataclasses import dataclass,asdict
from pathlib import Path,PurePosixPath
import ast,difflib,hashlib,json,os,re,resource,shutil,sqlite3,subprocess,sys,tempfile

@dataclass(frozen=True)
class RepoTask:
    key:str
    issue:str
    editable:tuple[str,...]

RUNNER='''import json,sys,unittest,io
sys.path.insert(0,sys.argv[1])
sys.path.insert(0,sys.argv[2])
class R(unittest.TestResult):
    def __init__(self): super().__init__(); self.rows=[]
    def addSuccess(self,t): super().addSuccess(t);self.rows.append({'id':t.id(),'ok':True})
    def addFailure(self,t,e): super().addFailure(t,e);self.rows.append({'id':t.id(),'ok':False,'error':self._exc_info_to_string(e,t)[-1000:]})
    def addError(self,t,e): super().addError(t,e);self.rows.append({'id':t.id(),'ok':False,'error':self._exc_info_to_string(e,t)[-1000:]})
r=R();suite=unittest.defaultTestLoader.discover(sys.argv[2],pattern='test_*.py');suite.run(r)
print('NAWAH_RESULT='+json.dumps(r.rows))
'''

def limits():
    resource.setrlimit(resource.RLIMIT_CPU,(4,4))
    resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
    resource.setrlimit(resource.RLIMIT_FSIZE,(1024**2,1024**2))
    if os.getuid()==0:
        os.setgroups([]);os.setgid(65534);os.setuid(65534)

def digest_files(root):
    root=Path(root)
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob('*')) if p.is_file()}

def copy_checked(source,target):
    source=Path(source)
    if any(p.is_symlink() for p in source.rglob('*')):raise ValueError('Symlinks unsupported')
    shutil.copytree(source,target)
    for p in [Path(target),*Path(target).rglob('*')]:
        p.chmod(0o755 if p.is_dir() else 0o644)

def run_tests(work,tests):
    try:
        p=subprocess.run([sys.executable,'-I','-B','-c',RUNNER,str(work),str(tests)],
            cwd=work,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,
            timeout=7,env={'PATH':'/usr/bin:/bin'},preexec_fn=limits)
        lines=[l for l in p.stdout.splitlines() if l.startswith('NAWAH_RESULT=')]
        if p.returncode or not lines:return [{'id':'runner','ok':False,'error':p.stderr[-600:] or 'runner_failed'}]
        rows=json.loads(lines[-1].split('=',1)[1])
        return rows or [{'id':'no_tests','ok':False,'error':'No tests discovered'}]
    except subprocess.TimeoutExpired:return [{'id':'timeout','ok':False,'error':'test timeout'}]

def score(rows):return sum(r['ok'] for r in rows)
def passing(rows):return {r['id'] for r in rows if r['ok']}
def complete(rows):return bool(rows) and all(r['ok'] for r in rows)

def parse_patch(raw,editable):
    # Path labels outside code fences; no fuzzy matching, no arbitrary shell.
    blocks=re.findall(r'FILE:\s*([^\n]+)\n```(?:python)?\s*\n(.*?)```',raw,re.S)
    if not blocks:raise ValueError('Expected FILE: path followed by fenced Python')
    changes={}
    for name,code in blocks:
        name=name.strip();p=PurePosixPath(name)
        if p.is_absolute() or '..' in p.parts or '\\' in name or name not in editable:
            raise ValueError('Path outside edit allowlist: '+name)
        if name in changes:raise ValueError('Duplicate path')
        ast.parse(code)
        # Block obvious privileged operations in generated patches; not full isolation.
        for n in ast.walk(ast.parse(code)):
            if isinstance(n,ast.Name) and n.id in {'eval','exec','open','__import__','compile'}:
                raise ValueError('Disallowed code operation')
            if isinstance(n,ast.Attribute) and n.attr.startswith('__'):raise ValueError('Disallowed attribute')
            if isinstance(n,ast.Import) and any(a.name.split('.')[0] in {'os','sys','subprocess','socket','ctypes','pathlib','shutil'} for a in n.names):raise ValueError('Disallowed import')
            if isinstance(n,ast.ImportFrom) and (n.module or '').split('.')[0] in {'os','sys','subprocess','socket','ctypes','pathlib','shutil'}:raise ValueError('Disallowed import')
        changes[name]=code.rstrip()+'\n'
    return changes

class Ledger:
    def __init__(self,path):
        self.db=sqlite3.connect(path)
        self.db.execute('CREATE TABLE IF NOT EXISTS events(task TEXT,step INTEGER,payload TEXT)')
    def record(self,key,step,event):
        self.db.execute('INSERT INTO events VALUES(?,?,?)',(key,step,json.dumps(event)));self.db.commit()
    def close(self):self.db.close()

class RepositoryAgent:
    def __init__(self,llm,budget=3,max_tokens=512):
        if budget<1:raise ValueError('budget must be positive')
        self.llm=llm;self.budget=budget;self.max_tokens=max_tokens

    def solve(self,source,public_tests,task,output,strategy='nawah'):
        source=Path(source).resolve();public_tests=Path(public_tests).resolve();output=Path(output).resolve()
        if strategy not in {'nawah','retry','bare'}:raise ValueError('unknown strategy')
        for protected in (source,public_tests):
            if output==protected or protected in output.parents or output in protected.parents:
                raise ValueError('Output must be disjoint from source and public tests')
        for f in task.editable:
            p=PurePosixPath(f)
            if p.is_absolute() or '..' in p.parts or '\\' in f or not f.endswith('.py'):raise ValueError('Invalid edit path')
        output.mkdir(parents=True,exist_ok=True)
        original=digest_files(source);test_hash=digest_files(public_tests)
        ledger=Ledger(output/'ledger.sqlite');events=[]
        try:
            with tempfile.TemporaryDirectory() as td:
                td=Path(td);td.chmod(0o755)
                # Tests are sibling to repo, not in editable context.
                frozen_tests=td/'public_tests';copy_checked(public_tests,frozen_tests)
                base=td/'base';copy_checked(source,base)
                initial=run_tests(base,frozen_tests)
                best_rows=initial;best_changes={};baseline_passes=passing(initial)
                context='\n'.join('FILE: '+f+'\n```python\n'+(source/f).read_text()+'```' for f in task.editable)
                common=('Repair the Python repository for this issue. Preserve existing API and imports. '
                    'Edit only the listed files. Do not change tests. Return full replacement files as:\n'
                    'FILE: filename.py\n```python\n...\n```\nISSUE:\n'+task.issue+'\nSOURCE:\n'+context+
                    '\nPUBLIC TEST FEEDBACK:\n'+json.dumps(initial,ensure_ascii=False))
                # Initial tests are observations, not solved-task ground truth.
                max_steps=1 if strategy=='bare' else self.budget
                for step in range(max_steps):
                    if complete(best_rows):break
                    prompt=common
                    if step:
                        if strategy=='nawah':
                            prompt+='\nCURRENT BEST EDITS:\n'+json.dumps(best_changes)+'\nLAST ATTEMPT:\n'+json.dumps(events[-1],ensure_ascii=False)+'\nFix failures without regressing existing passing tests.'
                        else:prompt+='\nUse a different approach than previous attempts. Previous response:\n'+events[-1].get('raw','')
                    raw=self.llm(prompt,max_tokens=self.max_tokens)
                    event={'step':step+1,'raw':raw,'accepted':False}
                    try:
                        changes=parse_patch(raw,task.editable)
                        candidate=td/f'candidate{step}';copy_checked(source,candidate)
                        for f,code in changes.items():
                            dest=candidate/f
                            if dest.is_symlink() or candidate not in dest.resolve().parents:raise ValueError('Unsafe destination')
                            if not dest.is_file():raise ValueError('Only existing files may be edited')
                            dest.write_text(code)
                        rows=run_tests(candidate,frozen_tests)
                        if digest_files(frozen_tests)!=test_hash:raise ValueError('Public tests changed')
                        event['tests']=rows
                        # Preserve every baseline and best-so-far passed test, not just the count.
                        retain=passing(best_rows)|baseline_passes
                        if retain<=passing(rows) and score(rows)>score(best_rows):
                            best_rows=rows;best_changes=changes;event['accepted']=True
                    except (ValueError,SyntaxError,OSError) as e:event['error']=str(e)
                    events.append(event);ledger.record(task.key,step+1,event)
                    (output/'progress.json').write_text(json.dumps({'task':task.key,'step':step+1,'passing':sorted(passing(best_rows)),'complete':complete(best_rows)},indent=2))
                final=output/'candidate'
                if final.exists():shutil.rmtree(final)
                copy_checked(source,final)
                for f,code in best_changes.items():(final/f).write_text(code)
                diff=''
                for f,code in best_changes.items():diff+=''.join(difflib.unified_diff((source/f).read_text().splitlines(True),code.splitlines(True),fromfile='a/'+f,tofile='b/'+f))
                (output/'change.patch').write_text(diff)
                result={'task':task.key,'strategy':strategy,'model_calls':len(events),
                    'initial_tests':initial,'final_public_tests':best_rows,
                    'public_complete':complete(best_rows),'events':events,
                    'source_unchanged':original==digest_files(source),
                    'tests_unchanged':test_hash==digest_files(public_tests),
                    'status':'public_tests_passed' if complete(best_rows) else 'needs_review'}
                (output/'result.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
                return result
        finally:ledger.close()
