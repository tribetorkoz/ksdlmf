#!/usr/bin/env python3
"""Integration demonstration on authored repos. Not SWE-bench, not AGI eval."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT));sys.path.insert(0,'/home/user/nawah_v4')
from fixtures import CASES,materialize
from repo_agent import RepoTask,RepositoryAgent,run_tests
from v4.llm import LLM,flush_cache

def main():
    fixtures=materialize(ROOT/'fixtures')
    manifest={'case_ids':[c['key'] for c in CASES], 'model':'Qwen2.5-Coder-1.5B-Instruct Q4_K_M',
        'ctx':2048,'max_tokens':512,'budget':3,
        'source':'four assistant-authored Python repository integration fixtures, NOT external benchmark',
        'code_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('*.py')}}
    (ROOT/'demo_manifest.json').write_text(json.dumps(manifest,indent=2))
    llm=LLM('/home/user/models/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf',n_ctx=2048,n_threads=2,max_tokens=512)
    out=ROOT/'demo_results.json';results=json.loads(out.read_text()) if out.exists() else []
    for c in CASES:
        if any(r['task']==c['key'] for r in results):continue
        b=fixtures/c['key'];row={'task':c['key'],'arms':{}}
        for arm in ['bare','retry','nawah']:
            output=ROOT/'runs'/c['key']/arm
            r=RepositoryAgent(llm).solve(b/'source',b/'public',RepoTask(c['key'],c['issue'],tuple(c['source'])),output,arm)
            held=run_tests(output/'candidate',b/'heldout')
            row['arms'][arm]={'public_passed':r['public_complete'],'heldout_passed':all(t['ok'] for t in held),
                'heldout_results':held,'calls':r['model_calls'],
                'source_unchanged':r['source_unchanged'],'tests_unchanged':r['tests_unchanged']}
        results.append(row);out.write_text(json.dumps(results,indent=2));flush_cache()
        print(c['key'],row['arms'],flush=True)
    print('DONE',flush=True)
if __name__=='__main__':main()
