#!/usr/bin/env python3
"""CLI for small trusted Python repositories. Never a hostile-code sandbox."""
import argparse,json,sys
from pathlib import Path
from repo_agent import RepoTask,RepositoryAgent

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('task',type=Path,help='JSON: key, issue, editable (relative .py paths)')
    p.add_argument('--source',required=True,type=Path)
    p.add_argument('--public-tests',required=True,type=Path)
    p.add_argument('--out',required=True,type=Path)
    p.add_argument('--model',required=True,type=Path)
    p.add_argument('--backend-root',type=Path,default=Path('/home/user/nawah_v4'))
    p.add_argument('--budget',type=int,default=3)
    p.add_argument('--max-tokens',type=int,default=512)
    p.add_argument('--ctx',type=int,default=2048)
    p.add_argument('--strategy',choices=['bare','retry','nawah'],default='nawah')
    a=p.parse_args()
    data=json.loads(a.task.read_text())
    if not isinstance(data.get('editable'),list) or not all(isinstance(x,str) for x in data['editable']):
        p.error('editable must be a list of relative Python file paths')
    if not a.model.is_file():p.error('Model file not found')
    sys.path.insert(0,str(a.backend_root.resolve()))
    from v4.llm import LLM,flush_cache
    llm=LLM(str(a.model.resolve()),n_ctx=a.ctx,n_threads=2,max_tokens=a.max_tokens)
    r=RepositoryAgent(llm,budget=a.budget,max_tokens=a.max_tokens).solve(
        a.source,a.public_tests,RepoTask(data['key'],data['issue'],tuple(data['editable'])),a.out,a.strategy)
    flush_cache()
    print(json.dumps({k:r[k] for k in ['task','status','model_calls','source_unchanged','tests_unchanged']},indent=2))
if __name__=='__main__':main()
