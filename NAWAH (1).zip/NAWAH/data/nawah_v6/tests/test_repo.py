import json,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from repo_agent import RepoTask,RepositoryAgent,parse_patch,digest_files,run_tests
from fixtures import materialize

class Scripted:
    def __init__(self,responses):self.it=iter(responses);self.calls=0
    def __call__(self,p,max_tokens=None):self.calls+=1;return next(self.it)

GOOD="FILE: sequence.py\n```python\ndef chunks(items,size):\n    if size <= 0: raise ValueError('size')\n    return [items[i:i+size] for i in range(0,len(items),size)]\n```"
BAD="FILE: sequence.py\n```python\ndef chunks(items,size):\n    return []\n```"

class Tests(unittest.TestCase):
    def test_parse(self):self.assertIn('sequence.py',parse_patch(GOOD,('sequence.py',)))
    def test_no_traversal(self):
        with self.assertRaises(ValueError):parse_patch(GOOD.replace('sequence.py','../sequence.py'),('sequence.py',))
    def test_no_test_edits(self):
        with self.assertRaises(ValueError):parse_patch(GOOD.replace('sequence.py','test_public.py'),('sequence.py',))
    def test_no_duplicates(self):
        with self.assertRaises(ValueError):parse_patch(GOOD+'\n'+GOOD,('sequence.py',))
    def test_no_syntax_error(self):
        with self.assertRaises(SyntaxError):parse_patch(GOOD.replace('return [','return !!!! ['),('sequence.py',))
    def test_disallows_obvious_system_access(self):
        with self.assertRaises(ValueError):parse_patch('FILE: x.py\n```python\nimport os\n```',('x.py',))
    def test_symlinks_rejected(self):
        from repo_agent import copy_checked
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'src').mkdir();(p/'src'/'link').symlink_to('/etc/passwd')
            with self.assertRaises(ValueError):copy_checked(p/'src',p/'dst')
    def test_repo_transaction_and_heldout(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);materialize(p/'fixtures');b=p/'fixtures'/'chunks'
            before=digest_files(b/'source');tb=digest_files(b/'public')
            llm=Scripted([GOOD]);r=RepositoryAgent(llm).solve(b/'source',b/'public',RepoTask('chunks','fix chunks',('sequence.py',)),p/'out')
            self.assertTrue(r['public_complete']);self.assertEqual(r['model_calls'],1)
            self.assertEqual(before,digest_files(b/'source'));self.assertEqual(tb,digest_files(b/'public'))
            self.assertTrue(all(t['ok'] for t in run_tests(p/'out'/'candidate',b/'heldout')))
            self.assertTrue((p/'out'/'change.patch').read_text())
            self.assertTrue((p/'out'/'progress.json').exists())
    def test_bad_patch_keeps_baseline(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);materialize(p/'fixtures');b=p/'fixtures'/'chunks'
            r=RepositoryAgent(Scripted([BAD]),budget=1).solve(b/'source',b/'public',RepoTask('chunks','fix',('sequence.py',)),p/'out')
            # Empty output destroys passing invalid-size check; reject regression.
            self.assertFalse(r['events'][0]['accepted'])
            self.assertEqual(digest_files(p/'out'/'candidate'),digest_files(b/'source'))
    def test_rejects_original_as_output(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);materialize(p/'f');b=p/'f'/'chunks'
            with self.assertRaises(ValueError):RepositoryAgent(None).solve(b/'source',b/'public',RepoTask('c','fix',('sequence.py',)),b/'source')
    def test_rejects_tests_as_output(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);materialize(p/'f');b=p/'f'/'chunks'
            with self.assertRaises(ValueError):RepositoryAgent(None).solve(b/'source',b/'public',RepoTask('c','fix',('sequence.py',)),b/'public')
    def test_rejects_ancestor_as_output(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);materialize(p/'f');b=p/'f'/'chunks'
            with self.assertRaises(ValueError):RepositoryAgent(None).solve(b/'source',b/'public',RepoTask('c','fix',('sequence.py',)),p)
    def test_no_hidden_in_task_api(self):
        self.assertNotIn('heldout',RepoTask.__dataclass_fields__)
if __name__=='__main__':unittest.main()
