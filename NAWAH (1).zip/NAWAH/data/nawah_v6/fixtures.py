"""Small authored integration fixtures, not external benchmark evidence."""
from pathlib import Path
import json

CASES=[
 dict(key='invoice',issue='Fix subtotal(rows) in invoice.py: sum quantity * unit_price for every row and round to two decimals using money.round_money. Empty input gives 0.0. Preserve the helper API.',
 source={'invoice.py':"from money import round_money\ndef subtotal(rows):\n    return round_money(sum(r['unit_price'] for r in rows))\n",
         'money.py':'def round_money(value):\n    return round(value, 2)\n'},
 public=["self.assertEqual(subtotal([]), 0.0)","self.assertEqual(subtotal([{'quantity':3,'unit_price':4.5}]),13.5)","self.assertEqual(subtotal([{'quantity':2,'unit_price':5},{'quantity':1,'unit_price':3}]),13)"],
 hidden=["self.assertEqual(subtotal([{'quantity':0,'unit_price':99}]),0)","self.assertEqual(subtotal([{'quantity':5,'unit_price':1.25}]),6.25)","self.assertEqual(subtotal([{'quantity':2,'unit_price':0.333}]),0.67)","self.assertEqual(subtotal([{'quantity':-1,'unit_price':10}]),-10)"], imp='from invoice import subtotal'),
 dict(key='chunks',issue='Fix chunks(items,size): return contiguous lists, including the shorter final chunk. Empty input gives []. Raise ValueError for size <= 0. Do not mutate items.',
 source={'sequence.py':'def chunks(items, size):\n    if size <= 0:\n        raise ValueError("size")\n    return [items[i:i+size] for i in range(0, len(items)-size+1, size)]\n'},
 public=["self.assertEqual(chunks([],2),[])","self.assertEqual(chunks([1,2,3],2),[[1,2],[3]])","with self.assertRaises(ValueError): chunks([1],0)"],
 hidden=["self.assertEqual(chunks([1],4),[[1]])","self.assertEqual(chunks([1,2,3,4],2),[[1,2],[3,4]])","self.assertEqual(chunks([1,2,3,4,5],3),[[1,2,3],[4,5]])","with self.assertRaises(ValueError): chunks([],-1)"],imp='from sequence import chunks'),
 dict(key='headers',issue='Fix headers(text): split a comma-separated header string, strip each column, lowercase it, and discard empty columns. Whitespace inside a column is preserved.',
 source={'columns.py':'def headers(text):\n    return [x.lower() for x in text.split(",")]\n'},
 public=["self.assertEqual(headers('ID,NAME'),['id','name'])","self.assertEqual(headers(' ID, , Full Name '),['id','full name'])","self.assertEqual(headers(''),[])"],
 hidden=["self.assertEqual(headers('  Age  '),['age'])","self.assertEqual(headers(',,, ,'),[])","self.assertEqual(headers('A,A'),['a','a'])","self.assertEqual(headers('A\\tB,C'),['a\\tb','c'])"],imp='from columns import headers'),
 dict(key='grouping',issue='Fix group_by(rows,key): return a dict mapping each key value to the list of rows with that value, preserving original order within each group. Skip rows missing the key. Empty input gives {}. Do not mutate the rows.',
 source={'groups.py':'def group_by(rows, key):\n    out = {}\n    for row in rows:\n        if key in row:\n            out[row[key]] = [row]\n    return out\n'},
 public=["self.assertEqual(group_by([], 'k'),{})","self.assertEqual(group_by([{'k':'a','v':1},{'k':'a','v':2}], 'k'),{'a':[{'k':'a','v':1},{'k':'a','v':2}]})","self.assertEqual(group_by([{'v':1}], 'k'),{})"],
 hidden=["self.assertEqual(group_by([{'k':0},{'k':0}], 'k'),{0:[{'k':0},{'k':0}]})","self.assertEqual(group_by([{'k':None},{'v':3}], 'k'),{None:[{'k':None}]})","self.assertEqual(group_by([{'k':'x'},{'k':'y'},{'k':'x'}], 'k'),{'x':[{'k':'x'},{'k':'x'}],'y':[{'k':'y'}]})"],imp='from groups import group_by'),
]

def tests_code(imp,asserts):
    return 'import unittest\n'+imp+'\nclass Tests(unittest.TestCase):\n'+''.join(f'    def test_{i}(self):\n        {s}\n' for i,s in enumerate(asserts))

def materialize(root):
    root=Path(root)
    for c in CASES:
        base=root/c['key']
        for label in ['source','public','heldout']:(base/label).mkdir(parents=True,exist_ok=True)
        for f,code in c['source'].items():(base/'source'/f).write_text(code)
        (base/'public'/'test_public.py').write_text(tests_code(c['imp'],c['public']))
        (base/'heldout'/'test_heldout.py').write_text(tests_code(c['imp'],c['hidden']))
    return root
