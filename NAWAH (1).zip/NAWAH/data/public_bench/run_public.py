#!/usr/bin/env python3
"""Public benchmark pilot. Never expose held-out tests to generation/repair.
This is a task adapter for NAWAH v4's generate/verify/repair code loop,
not the original string-task agent and not an official benchmark submission.
"""
import ast, doctest, gzip, hashlib, json, math, os, random, re, resource
import subprocess, sys, tempfile, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,'/home/user/nawah_v4')
from v4.llm import LLM, flush_cache

# Generated code is restricted before execution. This is defense-in-depth for
# local benchmark code, NOT a general hostile-code security sandbox.
ALLOWED_IMPORTS={'math','typing','collections','itertools','functools','re',
 'string','heapq','bisect','statistics','decimal','fractions','operator','copy','array'}
DENIED={'open','eval','exec','compile','__import__','input','breakpoint',
 'globals','locals','vars','getattr','setattr','delattr','help','exit','quit'}
def policy(code):
 try: tree=ast.parse(code)
 except SyntaxError: return 'syntax'
 for n in ast.walk(tree):
  if isinstance(n,ast.Name) and (n.id in DENIED or n.id.startswith('__')): return 'blocked_name'
  if isinstance(n,ast.Attribute) and n.attr.startswith('__'): return 'blocked_attribute'
  if isinstance(n,ast.Import) and any(a.name.split('.')[0] not in ALLOWED_IMPORTS for a in n.names): return 'blocked_import'
  if isinstance(n,ast.ImportFrom) and (n.level or (n.module or '').split('.')[0] not in ALLOWED_IMPORTS): return 'blocked_import'
 return None

def limits():
 resource.setrlimit(resource.RLIMIT_CPU,(3,3))
 resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
 resource.setrlimit(resource.RLIMIT_FSIZE,(1024*1024,1024*1024))
 resource.setrlimit(resource.RLIMIT_NOFILE,(32,32))
 if os.getuid()==0:
  os.setgroups([]);os.setgid(65534);os.setuid(65534)

def execute(code,tests):
 reason=policy(code)
 if reason:return False,reason
 with tempfile.TemporaryDirectory() as d:
  os.chmod(d,0o755)
  p=Path(d)/'check.py'
  p.write_text('from typing import *\nimport math\n'+code+'\n'+tests+'\n')
  p.chmod(0o444)
  try:
   r=subprocess.run([sys.executable,'-I','-B',str(p)],cwd=d,env={'PATH':'/usr/bin:/bin'},
      stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,text=True,
      timeout=5,preexec_fn=limits)
   return r.returncode==0, ('passed' if r.returncode==0 else
       (r.stderr.strip().splitlines()[-1][:200] if r.stderr.strip() else 'process_exit'))
  except subprocess.TimeoutExpired:return False,'timeout'

def extract(raw,prompt=''):
 m=re.search(r'```(?:python)?\s*\n?(.*?)```',raw,re.S)
 code=(m.group(1) if m else raw).strip()
 # Chat output is normally a whole function; preserve imports.
 if 'def ' not in code and prompt:code=prompt+'\n'+code
 return code

def load():
 h=[json.loads(l) for l in gzip.open(ROOT/'data/HumanEval.jsonl.gz','rt')]
 m=json.loads((ROOT/'data/mbpp.json').read_text())
 # Fixed before model execution. MBPP sanitized test split: original IDs 11..510.
 rng=random.Random(20261022)
 hs=sorted(rng.sample(h,12),key=lambda t:int(t['task_id'].split('/')[-1]))
 ms=sorted(rng.sample([t for t in m if 11<=t['task_id']<=510],12),key=lambda t:t['task_id'])
 tasks=[]
 for t in hs:
  visible=[]
  for ex in doctest.DocTestParser().get_examples(t['prompt']):
   # Only ordinary expression doctests: unsupported displays are not invented.
   if ex.want.strip() and not ex.exc_msg:
    try:ast.parse(ex.source.strip(),mode='eval');ast.literal_eval(ex.want.strip())
    except Exception:continue
    visible.append(f'assert ({ex.source.strip()}) == ({ex.want.strip()})')
  tasks.append(dict(id=t['task_id'],suite='HumanEval',prompt=t['prompt'],
    visible='\n'.join(visible),hidden=t['test']+'\ncheck('+t['entry_point']+')',
    reference=t['prompt']+t['canonical_solution']))
 for t in ms:
  # Show only first official test (and required imports); reserve remaining 2.
  imports='\n'.join(t.get('test_imports',[]))
  tasks.append(dict(id='MBPP/'+str(t['task_id']),suite='MBPP',
    prompt=t['prompt']+'\nExample test:\n'+t['test_list'][0]+'\n'+imports,
    visible=imports+'\n'+t['test_list'][0],
    hidden=imports+'\n'+'\n'.join(t['test_list'][1:]),reference=t['code']))
 return tasks

def main():
 tasks=load()
 manifest={'seed':20261022,'ids':[t['id'] for t in tasks],
 'sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'data').iterdir()},
 'protocol':'12 random HumanEval + 12 sanitized MBPP test IDs 11..510; temp=0; 384 tokens/call; hidden tests never guide selection; max 2 generations per retry/repair arm; no cross-task learning.'}
 (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2))
 # Sanity-check evaluator against original reference solutions BEFORE inference.
 sanity=[]
 for t in tasks:
  ok,why=execute(t['reference'],t['hidden'])
  sanity.append({'id':t['id'],'passed':ok,'reason':why})
 (ROOT/'reference_sanity.json').write_text(json.dumps(sanity,indent=2))
 if not all(t['passed'] for t in sanity):raise RuntimeError('Reference sanity failed; inspect file')
 model='/home/user/models/qwen2.5-coder-1.5b-instruct-q4_k_m.gguf'
 llm=LLM(model,n_ctx=2048,n_threads=2,max_tokens=384)
 results=[]
 out=ROOT/'results.json'
 if out.exists():results=json.loads(out.read_text())['tasks']
 for t in tasks:
  if any(r['id']==t['id'] for r in results):continue
  p='Write a complete Python function solving this specification. Return only a python code block.\n\n'+t['prompt']
  first=extract(llm(p,max_tokens=384),t['prompt'] if t['suite']=='HumanEval' else '')
  # Selection uses ONLY visible examples. Hidden tests are run after selection.
  v_ok,v_reason=execute(first,t['visible']) if t['visible'].strip() else (True,'no_visible_tests')
  arms={'bare':(first,1),'retry':(first,1),'nawah_adapter':(first,1)}
  if not v_ok:
   retry=extract(llm(p+'\nTry a structurally different solution. Check the displayed examples carefully.',max_tokens=384))
   repair=extract(llm('Repair this Python solution to satisfy the specification and its displayed examples.\nSPECIFICATION:\n'+t['prompt']+'\nCANDIDATE:\n'+first+'\nVISIBLE TESTS:\n'+t['visible']+'\nVISIBLE FAILURE:\n'+v_reason+'\nReturn the complete corrected code in one python block.',max_tokens=384))
   # Never discard a passing draft to repair it; no hidden-test selection.
   arms['retry']=(retry,2);arms['nawah_adapter']=(repair,2)
  row={'id':t['id'],'suite':t['suite'],'visible_first_ok':v_ok,'arms':{}}
  for name,(code,calls) in arms.items():
   ok,why=execute(code,t['hidden'])
   row['arms'][name]={'passed':ok,'calls':calls,'reason':why,'code':code}
  results.append(row)
  out.write_text(json.dumps({'manifest':manifest,'model':Path(model).name,'tasks':results},indent=2,ensure_ascii=False))
  flush_cache()
  print(t['id'],{k:v['passed'] for k,v in row['arms'].items()},flush=True)
 print('DONE',len(results),flush=True)
if __name__=='__main__':main()
