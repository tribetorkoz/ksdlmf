from money import round_money
def subtotal(rows):
    if not rows:
        return 0.0
    return round_money(sum(r['unit_price'] * r['quantity'] for r in rows))
