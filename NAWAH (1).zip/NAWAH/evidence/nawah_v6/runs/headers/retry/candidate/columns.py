def headers(text):
    return [x.lower() for x in text.split(",") if x.strip() and x]
