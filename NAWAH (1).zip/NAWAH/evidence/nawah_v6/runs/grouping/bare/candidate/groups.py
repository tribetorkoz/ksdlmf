def group_by(rows, key):
    out = {}
    for row in rows:
        if key in row:
            if row[key] not in out:
                out[row[key]] = []
            out[row[key]].append(row)
    return out
