import unittest
from sequence import chunks
class Tests(unittest.TestCase):
    def test_0(self):
        self.assertEqual(chunks([],2),[])
    def test_1(self):
        self.assertEqual(chunks([1,2,3],2),[[1,2],[3]])
    def test_2(self):
        with self.assertRaises(ValueError): chunks([1],0)
