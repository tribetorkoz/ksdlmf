import unittest
from sequence import chunks
class Tests(unittest.TestCase):
    def test_0(self):
        self.assertEqual(chunks([1],4),[[1]])
    def test_1(self):
        self.assertEqual(chunks([1,2,3,4],2),[[1,2],[3,4]])
    def test_2(self):
        self.assertEqual(chunks([1,2,3,4,5],3),[[1,2,3],[4,5]])
    def test_3(self):
        with self.assertRaises(ValueError): chunks([],-1)
