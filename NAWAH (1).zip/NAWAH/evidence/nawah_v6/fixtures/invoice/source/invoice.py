from money import round_money
def subtotal(rows):
    return round_money(sum(r['unit_price'] for r in rows))
