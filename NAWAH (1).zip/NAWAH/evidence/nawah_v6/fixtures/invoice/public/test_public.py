import unittest
from invoice import subtotal
class Tests(unittest.TestCase):
    def test_0(self):
        self.assertEqual(subtotal([]), 0.0)
    def test_1(self):
        self.assertEqual(subtotal([{'quantity':3,'unit_price':4.5}]),13.5)
    def test_2(self):
        self.assertEqual(subtotal([{'quantity':2,'unit_price':5},{'quantity':1,'unit_price':3}]),13)
