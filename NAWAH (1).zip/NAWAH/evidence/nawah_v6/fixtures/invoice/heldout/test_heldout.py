import unittest
from invoice import subtotal
class Tests(unittest.TestCase):
    def test_0(self):
        self.assertEqual(subtotal([{'quantity':0,'unit_price':99}]),0)
    def test_1(self):
        self.assertEqual(subtotal([{'quantity':5,'unit_price':1.25}]),6.25)
    def test_2(self):
        self.assertEqual(subtotal([{'quantity':2,'unit_price':0.333}]),0.67)
    def test_3(self):
        self.assertEqual(subtotal([{'quantity':-1,'unit_price':10}]),-10)
