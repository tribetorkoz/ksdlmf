import unittest
from columns import headers
class Tests(unittest.TestCase):
    def test_0(self):
        self.assertEqual(headers('  Age  '),['age'])
    def test_1(self):
        self.assertEqual(headers(',,, ,'),[])
    def test_2(self):
        self.assertEqual(headers('A,A'),['a','a'])
    def test_3(self):
        self.assertEqual(headers('A\tB,C'),['a\tb','c'])
