def headers(text):
    return [x.lower() for x in text.split(",")]
