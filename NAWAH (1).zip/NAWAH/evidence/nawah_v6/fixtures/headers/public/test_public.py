import unittest
from columns import headers
class Tests(unittest.TestCase):
    def test_0(self):
        self.assertEqual(headers('ID,NAME'),['id','name'])
    def test_1(self):
        self.assertEqual(headers(' ID, , Full Name '),['id','full name'])
    def test_2(self):
        self.assertEqual(headers(''),[])
