def group_by(rows, key):
    out = {}
    for row in rows:
        if key in row:
            out[row[key]] = [row]
    return out
