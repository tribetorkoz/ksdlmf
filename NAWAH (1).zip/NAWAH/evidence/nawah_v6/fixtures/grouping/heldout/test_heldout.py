import unittest
from groups import group_by
class Tests(unittest.TestCase):
    def test_0(self):
        self.assertEqual(group_by([{'k':0},{'k':0}], 'k'),{0:[{'k':0},{'k':0}]})
    def test_1(self):
        self.assertEqual(group_by([{'k':None},{'v':3}], 'k'),{None:[{'k':None}]})
    def test_2(self):
        self.assertEqual(group_by([{'k':'x'},{'k':'y'},{'k':'x'}], 'k'),{'x':[{'k':'x'},{'k':'x'}],'y':[{'k':'y'}]})
