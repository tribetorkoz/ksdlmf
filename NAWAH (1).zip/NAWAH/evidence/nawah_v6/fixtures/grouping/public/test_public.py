import unittest
from groups import group_by
class Tests(unittest.TestCase):
    def test_0(self):
        self.assertEqual(group_by([], 'k'),{})
    def test_1(self):
        self.assertEqual(group_by([{'k':'a','v':1},{'k':'a','v':2}], 'k'),{'a':[{'k':'a','v':1},{'k':'a','v':2}]})
    def test_2(self):
        self.assertEqual(group_by([{'v':1}], 'k'),{})
