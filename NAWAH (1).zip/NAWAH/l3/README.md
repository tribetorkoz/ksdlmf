# NAWAH level 3 — apparatus for measuring *accumulating generality*

This directory is the concrete answer to the instruction "move toward a higher level".
It is **not** an AGI system, and it does not contain a single capability number.

## What was built

| File | Role |
|---|---|
| `skills.py` | Executable skill library. A skill is admitted only if its own tests pass; retrieval is deterministic TF-IDF cosine, so runs are repeatable. |
| `gate.py` | The v6 no-observed-regression gate, isolated and reusable (set-of-passing-IDs logic). |
| `transfer.py` | Build / freeze / transfer protocol, paired analysis, prompt construction. |
| `resources.py` | JSONL logger for wall time, tokens, cache flag and provenance; missing values stay `None`, never estimated. |
| `backends.py` | `LlamaCppBackend` (real, requires weights) and `ScriptedBackend` (engineering test double only). |
| `tests_l3.py` | 12 apparatus tests; all pass. |
| `demo_engineering.py` | End-to-end run with the test double, writing an artefact labelled `engineering_only`. |

## Two anti-self-deception guards, enforced in code

1. `capability_report()` raises `PermissionError` if the backend is scripted.
   A scripted double can only produce `engineering_only` artefacts whose payload begins with
   *"NOT model performance, NOT evidence about capability, transfer or intelligence."*
2. `LlamaCppBackend` raises `BackendError` when the weights file is missing.
   The apparatus refuses to run rather than impute numbers.

## What the L3 study would test (falsifiable)

Hypothesis: *skills verified on family A raise success on the unseen family B when retrieval is enabled,
relative to the same model on the same tasks with retrieval disabled.*

The study reports `n`, `both`, `neither`, `only_second`, `only_first` and the task IDs in each cell,
so a null or negative result is published as easily as a gain. Token and wall-clock observations are
reported with explicit counts of how many values were actually observed.

## Running it for real

```bash
# requires a local GGUF file; nothing is downloaded here
python3 - <<'PY'
from backends import LlamaCppBackend
from transfer import Task, run_study, capability_report
b = LlamaCppBackend("/path/to/Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf")
build = [Task("A/...", "familyA", "description", ["assert ..."])]
transfer = [Task("B/...", "familyB", "description", ["assert ..."])]
out = run_study(b, build, transfer, "runs/l3_real")
capability_report(b, out["summary"], out["results"], "runs/l3_real/capability.json")
PY
```

Weight updates are impossible by design: `LlamaCppBackend` only performs inference.

## Status, stated plainly

* Apparatus: complete and tested (12/12).
* Real capability or transfer evidence: **none** — no weights, no inference, no compute budget here.
* Proximity to AGI: unchanged by this directory. It raises the *measurability* of a system, not its
  intelligence. Any claim that this constitutes AGI progress would be unsupported by its own logs.
