"""Skill library for the level-3 experiment.

A skill is stored only after its own tests pass under the same no-regression
gate used by v6. Nothing here trains weights; the library is the only place
where experience accumulates.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from pathlib import Path
import json, re, math, signal, hashlib, tempfile, os, time

TOKEN = re.compile(r"[a-z0-9_]+")


@dataclass
class Skill:
    name: str
    signature: str
    description: str
    code: str
    tests: list[str]
    provenance: dict = field(default_factory=dict)
    skill_id: str = ""

    def __post_init__(self):
        if not self.skill_id:
            key = (self.name + "|" + self.signature + "|" + self.description + "|" + self.code).encode()
            self.skill_id = "sk_" + hashlib.sha256(key).hexdigest()[:16]


class _Timeout(Exception):
    pass


def _alarm(signum, frame):          # pragma: no cover - signal handler
    raise _Timeout()


def verify_code(code: str, tests: list[str], seconds: int = 5) -> dict:
    """Execute `code` then each test string. Declared engineering check."""
    if not tests:
        return {"ok": False, "reason": "no tests declared", "passed": 0, "total": 0}
    ns: dict = {"__name__": "skill_under_test"}
    old = signal.signal(signal.SIGALRM, _alarm)
    signal.alarm(seconds)
    passed, reason = 0, "ok"
    try:
        exec(compile(code, "<skill>", "exec"), ns)
        for t in tests:
            exec(compile(t, "<test>", "exec"), ns)
            passed += 1
    except _Timeout:
        reason = "timeout"
    except Exception as e:                      # noqa: BLE001 - reported, not hidden
        reason = f"{type(e).__name__}: {e}"
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, old)
    return {"ok": passed == len(tests), "reason": reason, "passed": passed, "total": len(tests)}


class SkillStore:
    """Append-only JSON store with deterministic TF-IDF retrieval."""

    def __init__(self, path: str | os.PathLike):
        self.path = Path(path)
        self.skills: list[Skill] = []
        if self.path.exists():
            for d in json.loads(self.path.read_text()):
                self.skills.append(Skill(**d))

    # ---------------------------------------------------------------- writing
    def add(self, skill: Skill, verification: dict | None = None) -> tuple[bool, str]:
        """Admission rule: the skill's own tests must all pass."""
        v = verification if verification is not None else verify_code(skill.code, skill.tests)
        if not v["ok"]:
            return False, f"rejected: {v['reason']} ({v['passed']}/{v['total']})"
        if any(s.skill_id == skill.skill_id for s in self.skills):
            return False, "rejected: duplicate"
        self.skills.append(skill)
        self._flush()
        return True, "admitted"

    def _flush(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps([asdict(s) for s in self.skills], indent=2))
        tmp.replace(self.path)

    # ---------------------------------------------------------------- reading
    def _docs(self):
        return [f"{s.name} {s.signature} {s.description}" for s in self.skills]

    def retrieve(self, query: str, k: int = 3) -> list[Skill]:
        if not self.skills or k <= 0:
            return []
        docs = [TOKEN.findall(d.lower()) for d in self._docs()]
        q = TOKEN.findall(query.lower())
        vocab = sorted({t for d in docs for t in d} | set(q))
        df = {t: sum(1 for d in docs if t in d) for t in vocab}
        n = len(docs)
        idf = {t: math.log((n + 1) / (df[t] + 1)) + 1 for t in vocab}

        def vec(tokens):
            tf = {}
            for t in tokens:
                tf[t] = tf.get(t, 0) + 1
            v = {t: (1 + math.log(c)) * idf[t] for t, c in tf.items() if t in idf}
            norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
            return {t: x / norm for t, x in v.items()}

        qv = vec(q)
        scored = []
        for s, d in zip(self.skills, docs):
            dv = vec(d)
            score = sum(w * dv.get(t, 0.0) for t, w in qv.items())
            if score > 0:
                scored.append((score, s.skill_id, s))
        scored.sort(key=lambda x: (-x[0], x[1]))
        return [s for _, _, s in scored[:k]]

    def stats(self) -> dict:
        return {"skills": len(self.skills),
                "ids": [s.skill_id for s in self.skills],
                "sha256": hashlib.sha256(self.path.read_bytes()).hexdigest() if self.path.exists() else None}
