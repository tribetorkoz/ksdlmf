"""End-to-end apparatus demo with a scripted test double.

This writes an artefact explicitly labelled engineering_only. It is not a
capability result and must never be cited as one.
"""
from pathlib import Path
import json
from backends import ScriptedBackend
from transfer import Task, engineering_artefact, run_study

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "runs" / "engineering_demo"

SUM_CODE = "def total(values):\n    return sum(values)\n"
JOIN_CODE = "def label(name, values):\n    return name + ':' + '-'.join(map(str, values))\n"

build = [
    Task("build/sum", "numeric", "write total(values) returning the arithmetic sum",
         ["assert total([1, 2, 3]) == 6"]),
    Task("build/join", "numeric", "write label(name, values) joining numbers with hyphens",
         ["assert label('x', [1, 2]) == 'x:1-2'"]),
]
transfer = [
    Task("transfer/compose", "text", "compose a label for the total of the values",
         ["assert label('t', [1, 2]) == 't:1-2'"]),
]
backend = ScriptedBackend({
    "build/sum": "```python\n" + SUM_CODE + "```",
    "build/join": "```python\n" + JOIN_CODE + "```",
    "Executable skills already verified": "```python\n" + JOIN_CODE + "```",
    "transfer/compose": "```python\npass\n```",
})

out = run_study(backend, build, transfer, OUT)
art = engineering_artefact(out["summary"], out["results"], OUT / "engineering_demo.json")
print(json.dumps(json.loads(art.read_text())["measurement_class"]))
print(json.dumps(out["summary"]["paired_transfer"]))
print("artefact:", art)
