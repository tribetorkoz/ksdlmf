"""Apparatus tests for the level-3 experiment. No model inference happens here.

These tests answer one question only: does the machinery behave as specified?
They say nothing about capability, transfer or intelligence.
"""
from __future__ import annotations

import json, tempfile, unittest
from pathlib import Path

from backends import BackendError, LlamaCppBackend, ScriptedBackend
from gate import acceptable, best_of, pass_ids
from resources import ResourceLog
from skills import Skill, SkillStore, verify_code
from transfer import (Task, capability_report, engineering_artefact, paired,
                      run_study, strip_code)

ADD = "def add(a, b):\n    return a + b\n"
ADD_WRONG = "def add(a, b):\n    return a - b\n"
FENCE = "```python\n" + ADD + "```\n"


class TestGate(unittest.TestCase):
    def test_superset_accepted(self):
        base = {"t1": True, "t2": False}
        cand = {"t1": True, "t2": True}
        self.assertTrue(acceptable(cand, base, base))

    def test_swap_rejected_despite_equal_count(self):
        base = {"t1": True, "t2": False}
        cand = {"t1": False, "t2": True}
        self.assertFalse(acceptable(cand, base, base),
                         "an equal count that loses a passing id must be rejected")

    def test_chain_and_bound(self):
        base = {"a": False, "b": False, "c": False}
        best, n = best_of([{"a": True, "b": False, "c": False},
                           {"a": True, "b": True, "c": False},
                           {"a": False, "b": True, "c": True}], base)
        self.assertEqual(n, 2)
        self.assertEqual(pass_ids(best), {"a", "b"})


class TestSkills(unittest.TestCase):
    def test_verify(self):
        self.assertTrue(verify_code(ADD, ["assert add(2, 3) == 5"])["ok"])
        bad = verify_code(ADD_WRONG, ["assert add(2, 3) == 5"])
        self.assertFalse(bad["ok"])
        self.assertIn("AssertionError", bad["reason"])

    def test_admission_requires_passing_tests(self):
        with tempfile.TemporaryDirectory() as d:
            store = SkillStore(Path(d) / "skills.json")
            bad = Skill("add", "(a, b)", "adds two numbers", ADD_WRONG, ["assert add(2, 3) == 5"])
            ok, msg = store.add(bad)
            self.assertFalse(ok)
            self.assertEqual(store.stats()["skills"], 0)
            good = Skill("add", "(a, b)", "adds two numbers", ADD, ["assert add(2, 3) == 5"])
            ok, msg = store.add(good)
            self.assertTrue(ok)
            self.assertEqual(store.stats()["skills"], 1)
            ok, msg = store.add(good)
            self.assertFalse(ok)
            self.assertIn("duplicate", msg)

    def test_persistence_and_retrieval_ranking(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / "skills.json"
            s = SkillStore(p)
            s.add(Skill("slugify", "(text)", "lowercase words joined by hyphens for urls",
                        "def slugify(t):\n    return '-' .join(t.lower().split())\n",
                        ["assert slugify('A B') == 'a-b'"]))
            s.add(Skill("clamp", "(x, lo, hi)", "limit a number to an interval",
                        "def clamp(x, lo, hi):\n    return max(lo, min(hi, x))\n",
                        ["assert clamp(5, 0, 3) == 3"]))
            top = s.retrieve("make a url slug from words", k=1)
            self.assertEqual(top[0].name, "slugify")
            self.assertEqual(SkillStore(p).stats()["skills"], 2)


class TestApparatus(unittest.TestCase):
    def setUp(self):
        self.build = [Task("A/1", "arithmetic", "write add(a, b) that returns the sum", ["assert add(2, 3) == 5"])]
        self.transfer = [Task("B/1", "strings", "reuse the verified sum skill to add 4 and 6",
                              ["assert add(4, 6) == 10"])]
        self.backend = ScriptedBackend({
            "Task B/1": FENCE,                       # correct only when skills are injected
            "Task A/1": FENCE,
        })
        self.scripted_aware = ScriptedBackend({
            "Task A/1": FENCE,
            "Executable skills already verified": FENCE,
            "Task B/1": "```python\ndef add(a, b):\n    return 0\n```",
        })

    def test_strip_code(self):
        self.assertEqual(strip_code(FENCE).strip(), ADD.strip())

    def test_study_runs_and_labels_engineering_only(self):
        with tempfile.TemporaryDirectory() as d:
            out = run_study(self.scripted_aware, self.build, self.transfer, d)
            self.assertEqual(out["summary"]["library_frozen"]["skills"], 1)
            res = out["summary"]["resources"]
            self.assertEqual(res["measurement_class"], "engineering_only")
            pt = out["summary"]["paired_transfer"]
            self.assertEqual(pt["n"], 1)
            self.assertGreaterEqual(pt["only_second"], 1, "retrieval-on should differ from retrieval-off")

    def test_capability_report_refused_for_scripted_backend(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(PermissionError):
                capability_report(self.backend, {"x": 1}, {}, Path(d) / "cap.json")
            art = engineering_artefact({"x": 1}, {}, Path(d) / "eng.json")
            payload = json.loads(art.read_text())
            self.assertEqual(payload["measurement_class"], "engineering_only")
            self.assertIn("NOT model performance", payload["warning"])

    def test_real_backend_refuses_without_weights(self):
        with self.assertRaises(BackendError):
            LlamaCppBackend("/home/user/models/does_not_exist.gguf")

    def test_resource_summary_never_invents_values(self):
        with tempfile.TemporaryDirectory() as d:
            log = ResourceLog(Path(d) / "r.jsonl")
            log.record(phase="p", task_id="t", family="f", condition="c", ok=True,
                       backend={"is_real": False})
            s = log.summarise()
            row = s["groups"][0]
            self.assertIsNone(row["mean_tokens"])
            self.assertIsNone(row["mean_wall_s"])
            self.assertEqual(row["tokens_observed"], 0)
            self.assertEqual(s["measurement_class"], "engineering_only")

    def test_paired_counts(self):
        a = [{"task": "1", "ok": True}, {"task": "2", "ok": False}]
        b = [{"task": "1", "ok": True}, {"task": "2", "ok": True}]
        self.assertEqual(paired(a, b)["only_second"], 1)
        self.assertEqual(paired(a, b)["gain_tasks"], ["2"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
