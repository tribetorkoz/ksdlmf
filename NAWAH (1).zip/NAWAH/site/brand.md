# The name: PASSKEPT

**Decision.** The project's public name is **PASSKEPT** (pronounced *pass-kept*), Arabic gloss
«ما نجحَ يُحفَظ». The engine and its agent versions keep the name **NAWAH** (`nawah_v5`, `nawah_v6`, `nawah_l3`).
So: *PASSKEPT is the project; NAWAH is the machinery inside it.*

## Why this name

| Reason | Detail |
|---|---|
| It states the invariant | The gate's whole content is: every test that already passed must still pass. Two English words, no metaphor needed. |
| It is falsifiable | If a kept candidate drops a previously passing test, the name is wrong and the code is wrong. That is a good property for a name. |
| It is honest about limits | "Kept" is not "correct". The name promises retention, not intelligence. |
| It survives translation | «ما نجح يُحفظ» is a sentence a reader understands without a glossary. |
| It is short, spellable, and lowercase-friendly | `passkept`, `PASSKEPT`, `/site`, one word. |

Rejected formulations that implied more than the evidence supports: *verified intelligence*, *self-improving*,
*autonomous engineer*, *AGI layer*, *self-evolving*. Each of these is contradicted by the project's own logs
(no weight updates, no transfer result, one paired task gain, four authored fixtures).

## Search record for collisions (22 October 2026)

Searched before choosing. Findings, recorded so the decision can be audited later:

| Candidate | What the web search found | Verdict |
|---|---|---|
| **Mizan** (ميزان) | Many AI projects: `mizan-harness` (LLM prompt-bank harness), `Moshe-ship/mizan` (signed evidence layer for agents), `mizan-al-hadith`, several others | rejected — crowded, and two of them are near-identical in spirit |
| **Tawthiq** (توثيق) | Commercial verification companies: `tawthiq.org` (social-account verification), `tawthiq.sa` (organic certification), `tawthiq.tech` (PDPL compliance) | rejected — heavy trademark/domain collision |
| **Qistas** (قسطاس) | `qistas.com` / `qistas.ai` — an established Arabic legal-AI company (since 2010); several GitHub repos | rejected — established company in the same region and field |
| **PassKeep** | At least six GitHub projects, all password managers | rejected — one letter away from a crowded namespace |
| **NAWAH** alone | `nawah-ai` GitHub account exists; Nawah Energy Company (UAE) owns the word commercially | kept as the *engine* name only, not as the public brand |
| **PASSKEPT** | No project, product or repository found under this spelling | **chosen** |

This is a web search, not a legal clearance. It reduces obvious embarrassment; it does not establish that the
name is registrable.

## What remains for the owner to do (in order)

1. **Trademark check** in your jurisdiction (OMPIC in Morocco, or the relevant office) for the class of software services.
2. **Domain / handle check** for `passkept` (`.com`, `.dev`, `.ai`) and for a GitHub organisation of the same name.
3. **If any check fails**, the fallback list below is already screened against the same engine searches;
   pick the first that clears.
4. Only then publish the repository under the chosen name and add the `LICENSE` and `AUTHORS` files.

Fallbacks, in order of preference — each a compound that states a property, none found in the searches above:
`KEPT-SET`, `HOLDPASS`, `REGRESS-FREE`, `SETKEEP`.

## How the name is used

* Repository: `passkept` (or `NAWAH` while private).
* Papers: keep the technical title; add one line in the abstract: *"This project is distributed as PASSKEPT."*
* Code: `nawah_*` module names stay. Renaming working code for branding breaks the hashes in `audit/` and the
  reproduction commands, and the record matters more than the label.
* Never write "PASSKEPT proves" or "PASSKEPT ensures correctness". Write "PASSKEPT keeps the passing set",
  which is precisely true, and "the gate's proof is limited to the assumptions in §3.3", which is also true.

## One line for a README badge

> **PASSKEPT** — keeps what passed, records what ran, refuses what it cannot prove.
