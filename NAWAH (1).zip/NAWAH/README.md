# PASSKEPT

**PASSKEPT** — *keeps what passed, records what ran, refuses what it cannot prove.*
Arabic gloss: «ما نجحَ يُحفَظ». The engine inside keeps its original name, **NAWAH**.

> **What is it, in one sentence?** A verification gate wrapped around a small frozen local language model:
> a proposed code change is kept only if it preserves every test that already passed and strictly increases the
> number that pass, with a replayable audit trail — plus an honest report of what that bought on real archived runs
> (one paired task gain out of sixteen, a visible-test blind spot in two tasks per arm, a three-way tie on four
> authored repositories).

**Landing page:** open [`site/index.html`](site/index.html) in a browser — a single black-and-white file, no network
requests. The naming rationale, the collision search record and the remaining trademark checks are in
[`site/brand.md`](site/brand.md).

---

# NAWAH (project repository)

**A verification-guided code-repair harness around a frozen 1.5 B local model — and an honest audit of what that harness does and does not buy.**

This repository contains two complete manuscripts, the archived evidence they report, and the scripts that
recompute every number in them. Nothing here trains a model, and nothing here claims general intelligence.

| | |
|---|---|
| **Landing page** | [`site/index.html`](site/index.html) — what PASSKEPT is, in seven sections |
| **English paper** | [`paper/NAWAH_Research_Paper_EN.html`](paper/NAWAH_Research_Paper_EN.html) — 14 figures, 12 tables, 27 A4 pages |
| **Arabic paper** | [`paper/NAWAH_Research_Paper_AR.html`](paper/NAWAH_Research_Paper_AR.html) — 14 figures, 11 tables, 29 A4 pages |
| **Reproduce** | `cd reproduce && python3 analyze.py && python3 build_paper_en.py && python3 validate_paper_en.py` |
| **Status** | Unreviewed technical draft, 22 October 2026. No authors, affiliation, DOI or acceptance is claimed. |

Both HTML files are standalone: inline SVG figures, system fonts, no CDN, no network request, no JavaScript
required to read them. Each has a button that downloads the embedded evidence JSON.

## What the evidence actually says

* Three **non-poolable** studies: a 24-task HumanEval/MBPP pilot, a v5 MBPP split (8 development, 16 test), and
  four authored repository integration fixtures.
* Held-out task success: 16/24, 18/24, 16/24 (pilot); 10/16, 10/16, 11/16 (v5 test); 3/4 for every arm (v6).
* The only paired gain is **one task** (MBPP/388: a missing `import math`); exact conditional `p = 1.0`.
* Visible-test success hid hidden failures in **two tasks per arm** (conditional precision 10/12 and 11/13).
* **156/156** saved arm–task outcomes re-execute identically on the same tests. This is a consistency check,
  not new tasks and not new model inference.
* No token, latency, memory or cost figures exist historically, so none are reported.

Extended statement of scope and limits: [`docs/STATUS.md`](docs/STATUS.md).

## Layout

```
paper/        the two manuscripts, their templates, the 14 SVG assets, analysis.json, observations.csv,
              figure_sources.json, embedded_evidence.json
reproduce/    analyze, build, validate, browser, site and recheck scripts + requirements
site/         landing page (index.html) and the naming record (brand.md)
data/         raw study artefacts: public_bench, nawah_v5, nawah_v6, nawah_v4 backend (portable copy)
evidence/     76 restored v6 run/fixture files, each matching its archived hash
audit/        recheck logs, checksum tables, validation reports (JSON/TXT only)
l3/           level-3 apparatus: executable skill library, transfer protocol, anti-overclaim guards
docs/         status, Arabic notes, research notes, original v3 checksums
```

## Verify everything

```bash
cd reproduce
python3 analyze.py             # recompute analysis.json + the 12 quantitative SVGs (deterministic)
python3 build_paper.py         # Arabic HTML   -> paper/
python3 build_paper_en.py      # English HTML  -> paper/
python3 validate_paper.py      # 54 checks
python3 validate_paper_en.py   # 95 checks (statistical inversion, hashes, offline safety, claim hygiene)
python3 browser_check_en.py    # layout, zero external requests, A4 page count (Playwright needed)
python3 recheck_artifacts.py   # 156 saved candidates re-executed; NOT a security sandbox
cd ../l3 && python3 -m unittest tests_l3    # 12/12 apparatus tests
```

Recheck environments: `NAWAH_ARTIFACT_ROOT=/path/to/data` if the artefacts live elsewhere.

## What this repository deliberately does not contain

* No model weights — the GGUF file is not redistributable here and is not needed to recompute any result.
* No generated images, caches, screenshots or build output.
* No claim of AGI, continual learning, transferable skill, general superiority or production isolation.
* No invented authors, affiliations, funding, conflicts of interest, DOI or peer review.

## Licences

Code: see [`LICENSE.md`](LICENSE.md). Third-party task data: see [`THIRD_PARTY.md`](THIRD_PARTY.md).
Before publishing this repository publicly, the owner must choose a licence and review the upstream
licences of HumanEval and MBPP.
