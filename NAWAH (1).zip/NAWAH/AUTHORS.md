# Authorship

This repository is a technical draft. **No author names or affiliations are supplied in this version.**

Before any public release or submission, the following must be completed by the human holders of the work:

1. Name every person with a substantial contribution to the design, implementation, experiments, analysis
   or writing, and obtain their consent to be listed.
2. Record affiliations, corresponding author, funding, and any conflict of interest.
3. Confirm that AI assistance is disclosed in the papers (it is, in the Methods/Appendix B of both versions)
   and that no AI system is listed as an author.
4. Review the licences of the third-party task data (see `THIRD_PARTY.md`).
5. Decide whether the repository becomes public, and under which licence.

Nothing in this repository asserts authorship, institutional endorsement, peer review or acceptance.
