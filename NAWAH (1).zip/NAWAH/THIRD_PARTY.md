# Third-party material and provenance

| Path | What it is | Upstream | Licence (verify before redistribution) |
|---|---|---|---|
| `data/public_bench/data/HumanEval.jsonl.gz` | 164 hand-written Python problems with tests | `github.com/openai/human-eval` | MIT (upstream repository licence) |
| `data/public_bench/data/mbpp.json` | Locally held sanitized MBPP subset (427 rows) | `github.com/google-research/google-research/tree/master/mbpp` | Apache-2.0 (upstream repository licence) |
| `data/nawah_v4/v4/llm.py` | Backend shim used by the recheck harness | project-internal | owner |

Notes that matter for honesty:

* The papers define "held out" only as *not present in the prompt or selection interface*. No training-data
  contamination audit was performed; public tasks may exist in the model's training data.
* `mbpp.json` here is a local sanitized subset. Split identifiers cited in the papers follow the upstream
  documentation (tests 11–510, development 511–600); the file must not be described as the complete
  upstream corpus.
* The HumanEval harness upstream warns that executing generated code requires a strong sandbox. The recheck
  script in this repository is **not** a sandbox and must not be used on untrusted candidates.
* If redistribution is undesirable, delete `data/public_bench/data/` and re-fetch the two files from the
  upstream repositories; `reproduce/recheck_artifacts.py` will then need the files restored to the same
  paths, and the SHA-256 values recorded in `audit/input_hashes.json` let you confirm byte identity.
