# Licence status: not yet granted

The owner of this repository has **not yet chosen a licence**. No permission is granted by default; all rights
are reserved by the owner until a licence file is added.

Recommended before publishing:

| Part | Suggested licence | Why |
|---|---|---|
| Code in `reproduce/`, `l3/`, and the agent sources in `data/` | MIT or Apache-2.0 | Permissive, standard for research code |
| The two manuscripts in `paper/` | CC BY 4.0 (or CC BY-NC-ND if a preprint embargo is wanted) | Allows reading, quoting and redistribution with attribution |
| `data/` results produced by this project | CC0 or CC BY 4.0 | Maximises reuse; the numbers are facts, not creative works |
| Third-party task data (`data/public_bench/data/`) | **unchanged upstream licences** | They are not the owner's to relicense; see `THIRD_PARTY.md` |

To apply a licence, add the chosen `LICENSE` file, replace this document, and update the licence line in
`README.md`. Do not publish before step 4 of `AUTHORS.md` is complete.
