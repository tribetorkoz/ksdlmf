# Reproduction guide

## Requirements

* Python 3.11+ (developed on 3.13)
* `matplotlib`, `numpy`, `scipy`, `beautifulsoup4` — see `reproduce/requirements-analysis.txt`
* `playwright` + Chromium only for the layout/print audits: `python3 -m playwright install chromium`
* `pymupdf` only for the page-count assertion
* Model weights are **not** required: every reported number comes from archived result files

## Order of operations

```bash
cd reproduce
python3 analyze.py            # analysis.json, observations.csv, figure_sources.json, 12 SVGs
python3 build_paper.py        # paper/NAWAH_Research_Paper_AR.html
python3 build_paper_en.py     # paper/NAWAH_Research_Paper_EN.html
python3 validate_paper.py     # 54 checks
python3 validate_paper_en.py  # 95 checks
python3 browser_check.py      # Arabic layout + A4 print audit
python3 browser_check_en.py   # English layout, zero external requests, page count
python3 recheck_artifacts.py  # re-execute 156 saved candidates on the same tests
```

`analyze.py` is deterministic: two consecutive runs produce byte-identical HTML (SVG hash salt fixed).

## What reproduction can and cannot show

| Shown | Not shown |
|---|---|
| The tables, figures and percentages follow from the archived files | That the archived runner measured what it claimed |
| 156 saved binary outcomes re-execute identically | New model inference, or 156 independent tasks |
| 79 original project checksums, 10/10 and 13/13 unit tests still pass | Full re-inference: no weights, no historical environment |
| Hashes identify every input byte | That no leakage occurred during the original runs |
