"""Layer smoke test: prove the five layers are wired, not that the system is AGI.

Exit code 0 means every assertion below held. Nothing here is a capability
measurement: the only place a capability number exists is eval/results.json, and
this script prints that file's status instead of inventing its own.

Run from anywhere:
    python test_agi.py
    python AGI_PROJECT/test_agi.py
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.agi_loop import AGILoop, Task                    # noqa: E402
from core.backends import ScriptedBackend                 # noqa: E402
from core.causal_memory_v2 import CausalMemoryStore       # noqa: E402
from core.dreamer import Dreamer                          # noqa: E402
from core.gate import acceptable                          # noqa: E402
from core.swarm import Swarm                              # noqa: E402

CHECKS: list[str] = []


def ok(name: str) -> None:
    CHECKS.append(name)
    print(f"ok {name}")


def test_gate() -> None:
    """The gate demands monotone progress: no lost checks, at least one new pass."""
    assert acceptable({"a": True, "b": True}, {"a": True}, {}) is True
    assert acceptable({"a": True}, {"a": True}, {}) is False
    assert acceptable({"a": True}, {"a": True, "b": True}, {}) is False
    assert acceptable({"a": True, "b": True}, {"a": True}, {"c": True}) is False
    ok("gate: regression refused, monotone progress accepted")


def test_causal_memory() -> None:
    """Retrieval follows the causal path, and a prevention inhibits."""
    with tempfile.TemporaryDirectory(prefix="nawah_memory_") as folder:
        store = CausalMemoryStore(Path(folder) / "memory.jsonl")
        store.add("Forgetting import math causes NameError",
                  cause_of="NameError", caused_by="forgetting import math")
        store.add("Random info about weather", cause_of="rain", caused_by="cloud")

        found = store.retrieve_causal("I have a NameError in code", k=1)
        assert found and "import math" in found[0].content
        assert all("weather" not in memory.content for memory in found)

        okay, prevented_id = store.add("A try/except prevented the NameError",
                                       cause_of="NameError", caused_by="try/except",
                                       relation="prevented")
        assert okay
        prevented = next(m for m in store.mems if m.mem_id == prevented_id)
        assert store.intervention_score("NameError", prevented) < 0
    ok("causal memory: causal retrieval, prevented relation inhibited")


def test_dreamer() -> None:
    """Consequences are grounded in the state, and a destructive plan is filtered."""
    dreamer = Dreamer(seed=0)
    state = "a.py imports math; b.py imports a; api.py queries the users table"
    dreams = dreamer.dream(state, "remove import math", n=3)

    assert len(set(dreams)) == 3
    assert all(len(dream) < 100 for dream in dreams)
    assert any("NameError" in dream for dream in dreams)

    kept = dreamer.filter_safe(state, ["delete the users table",
                                       "run the linter",
                                       "implement the function body"], n=3)
    assert "delete the users table" not in kept
    assert "run the linter" in kept
    ok("dreamer: five distinct futures, destructive action filtered")


def test_swarm() -> None:
    """Agents coordinate only through traces, and each sees the previous ones."""
    with tempfile.TemporaryDirectory(prefix="nawah_swarm_") as folder:
        swarm = Swarm(Path(folder), run="smoke")
        seen: dict[str, list[str]] = {}

        def explorer(task, context):
            seen["explorer"] = [trace["agent"] for trace in context]
            return {"idea": "try method A"}

        def critic(task, context):
            seen["critic"] = [trace["agent"] for trace in context]
            return {"critique": "A has a risk", "stop": False}

        def fixer(task, context):
            seen["fixer"] = [trace["agent"] for trace in context]
            return {"fix": "use B", "stop": True}

        traces = swarm.run_team("repair the parser",
                                {"explorer": explorer, "critic": critic, "fixer": fixer})

        assert [trace["agent"] for trace in traces] == ["explorer", "critic", "fixer"]
        assert seen["explorer"] == []
        assert seen["critic"] == ["explorer"]
        assert seen["fixer"] == ["explorer", "critic"]
        assert len(list(Path(folder).glob("*.json"))) >= 3
    ok("swarm: three traces, each agent reads the previous ones")


def test_loop() -> None:
    """The integrated loop accepts only what the gate accepts."""
    task = Task(task_id="add_two", family="arithmetic",
                description="Implement add(a, b) returning the sum",
                tests=["assert add(2, 3) == 5", "assert add(-1, 1) == 0"])
    backend = ScriptedBackend({
        "attempt 1": "def add(a, b):\n    return a - b",
        "attempt 2": "def add(a, b):\n    return a + b",
        "attempt 3": "def add(a, b):\n    return a + b if a >= 0 else 0",
    })
    with tempfile.TemporaryDirectory(prefix="nawah_loop_") as folder:
        result = AGILoop(task, backend, Path(folder), max_candidates=3).run()

    assert result["accepted_count"] == 1
    assert result["best_candidate"].strip() == "def add(a, b):\n    return a + b"
    assert result["measurement_class"] == "engineering_only"
    steps = {entry["step"] for entry in result["audit_log"]}
    assert {"plan", "dream", "memory", "propose", "gate"} <= steps
    ok("loop: one of three accepted, every step audited")


def report_measurement() -> None:
    """Print what the repository actually measured; claim nothing more."""
    path = ROOT / "eval" / "results.json"
    if not path.exists():
        print("measurement: not_run (eval/results.json is absent)")
        return
    payload = json.loads(path.read_text(encoding="utf-8"))
    status = payload.get("status")
    if status == "measured":
        assert payload.get("pass_rate") is not None
        print(f"measurement: {payload['suite']} {payload['summary']} "
              f"(git {str(payload.get('git'))[:7]}, {payload.get('timestamp')})")
        print("capability: 0/20 on ARC-AGI-1 evaluation is the measured result; "
              "this script does not change it")
    else:
        print(f"measurement: {status} - {payload.get('reason', 'no reason recorded')}")


def main() -> int:
    print("NAWAH-AGI layer smoke test (engineering only, no capability claim)\n")
    test_gate()
    test_causal_memory()
    test_dreamer()
    test_swarm()
    test_loop()
    print()
    report_measurement()
    print(f"\nlayers wired: {len(CHECKS)}/5")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
