# Measured results

Every row below comes from a real command; the harness writes `not_run`
instead of a number when a dataset, weight file or sandbox is missing.

## ARC - ARC-AGI-1 [evaluation (public)]

- Run at: 2026-10-23T00:19:24Z
- Git: daf850499b5e1788aa93b7d493a64e64409e5d22
- Dataset: eval/data/arc_agi1_evaluation_seed0.json
- Backend: arc_dsl_v1 (is_real=True)
- Status: **measured**
- Result: **0/20 (0% vs human 66%)**
- Scored tasks: 20 (invalid: 0)
- Baseline note: comparable to the ARC Prize human baseline

## ARC - ARC-AGI-1 [training (public)]

- Run at: 2026-10-23T00:19:27Z
- Git: daf850499b5e1788aa93b7d493a64e64409e5d22
- Dataset: eval/data/arc_agi1_training_seed0.json
- Backend: arc_dsl_v1 (is_real=True)
- Status: **measured**
- Result: **2/20 (10%) - not comparable to the human 66% baseline**
- Scored tasks: 20 (invalid: 0)
- Baseline note: training split: easier than the evaluation split the 66 percent baseline was measured on, so this percentage is not comparable

