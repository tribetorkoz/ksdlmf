"""One-time download of the public ARC-AGI-1 evaluation split.

The harness never touches the network.  This script does, exactly once, and
writes a frozen subset next to its provenance so a later run can be checked
against the same bytes.

Dataset: ARC-AGI-1 (Francois Chollet), https://github.com/fchollet/ARC
Licence : Apache-2.0
Split   : data/evaluation, the public evaluation set (400 tasks).

Usage:
    python eval/fetch_arc.py --n 20 --seed 0
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import random
import urllib.request
import zipfile
from pathlib import Path

SOURCE = "https://codeload.github.com/fchollet/ARC/zip/refs/heads/master"
HUMAN_BASELINE = 0.66
HUMAN_SOURCE = ("ARC Prize: average human score on the ARC-AGI-1 private "
                "evaluation set, reported as roughly 66 percent")


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def download(cache: Path) -> Path:
    cache.mkdir(parents=True, exist_ok=True)
    archive = cache / "ARC-master.zip"
    if not archive.exists():
        with urllib.request.urlopen(SOURCE, timeout=120) as response:
            archive.write_bytes(response.read())
    return archive


def read_split_tasks(archive: Path, split: str) -> dict[str, dict]:
    tasks = {}
    marker = f"/data/{split}/"
    with zipfile.ZipFile(archive) as bundle:
        for name in bundle.namelist():
            if marker not in name or not name.endswith(".json"):
                continue
            payload = json.loads(bundle.read(name).decode("utf-8"))
            task_id = Path(name).stem
            tasks[task_id] = payload
    return tasks


def build_subset(tasks: dict[str, dict], n: int, seed: int) -> list[dict]:
    ids = sorted(tasks)
    chosen = sorted(random.Random(seed).sample(ids, min(n, len(ids))))
    rows = []
    for task_id in chosen:
        body = {"train": tasks[task_id]["train"], "test": tasks[task_id]["test"]}
        canonical = json.dumps(body, sort_keys=True,
                               separators=(",", ":")).encode("utf-8")
        rows.append({"task_id": task_id, "train": body["train"],
                     "test": body["test"], "sha256": sha256_bytes(canonical)})
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Freeze an ARC-AGI-1 subset")
    parser.add_argument("--n", type=int, default=20)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--cache", type=Path, default=Path("eval/.cache"))
    parser.add_argument("--split", choices=("evaluation", "training"), default="evaluation")
    parser.add_argument("--out", type=Path, default=None)
    args = parser.parse_args()

    out = args.out or Path(f"eval/data/arc_agi1_{args.split}_seed{args.seed}.json")
    archive = download(args.cache)
    tasks = read_split_tasks(archive, args.split)
    if not tasks:
        raise SystemExit("no evaluation tasks found in the archive")

    rows = build_subset(tasks, args.n, args.seed)
    payload = {
        "dataset": "ARC-AGI-1",
        "source": "https://github.com/fchollet/ARC",
        "source_archive": SOURCE,
        "source_archive_sha256": sha256_bytes(archive.read_bytes()),
        "license": "Apache-2.0",
        "split": f"{args.split} (public)",
        "available_tasks": len(tasks),
        "selection": {
            "method": "random.Random(seed).sample(sorted(task_ids), n), then sorted",
            "seed": args.seed,
            "n": len(rows),
        },
        "human_baseline": HUMAN_BASELINE,
        "human_baseline_source": HUMAN_SOURCE,
        "tasks": rows,
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=1), encoding="utf-8")
    print(f"wrote {out} with {len(rows)} tasks from {len(tasks)} available ({args.split})")
    print("ids:", ", ".join(row["task_id"] for row in rows))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
