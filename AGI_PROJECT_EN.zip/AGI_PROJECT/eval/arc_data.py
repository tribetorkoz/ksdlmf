"""Typed access to the frozen ARC-AGI-1 subset.

The subset is real: twenty tasks from ``data/evaluation`` of the public
ARC-AGI-1 repository, chosen by a published rule
(``random.Random(seed).sample(sorted(ids), n)``) and pinned by SHA-256.

Nothing here invents a task, resizes a grid, or fills in a missing colour.  A
task that fails validation is returned as invalid and the harness records it;
the alternative, silently repairing the data, would corrupt the measurement.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from pathlib import Path

DEFAULT_SUBSET = Path(__file__).resolve().parent / "data" / "arc_agi1_evaluation_seed0.json"
COLOURS = range(0, 10)


@dataclass
class ArcTask:
    task_id: str
    train: list[dict]
    test: list[dict]
    sha256: str = ""
    metadata: dict = field(default_factory=dict)

    @property
    def pairs(self) -> int:
        return len(self.train) + len(self.test)


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: str | Path) -> str:
    return sha256_bytes(Path(path).read_bytes())


def canonical(payload: dict) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _grid_problems(grid, label: str) -> list[str]:
    problems = []
    if not isinstance(grid, list) or not grid:
        return [f"{label}: grid is empty"]
    if not all(isinstance(row, list) for row in grid):
        return [f"{label}: ragged grid, not every row is a list"]
    width = len(grid[0])
    if any(len(row) != width for row in grid):
        problems.append(f"{label}: ragged grid, rows differ in width")
    for row in grid:
        for cell in row:
            if not isinstance(cell, int) or isinstance(cell, bool) or cell not in COLOURS:
                problems.append(f"{label}: colour {cell!r} outside 0..9")
                return problems
    return problems


def validate_task(task: ArcTask) -> list[str]:
    """Return every reason the task cannot be scored. Empty list means valid."""
    problems = []
    if not task.train:
        problems.append("no train pairs")
    if not task.test:
        problems.append("no test inputs")
    for index, pair in enumerate(task.train):
        if not isinstance(pair, dict) or "input" not in pair or "output" not in pair:
            problems.append(f"train[{index}]: missing input or output")
            continue
        problems += _grid_problems(pair["input"], f"train[{index}].input")
        problems += _grid_problems(pair["output"], f"train[{index}].output")
    for index, pair in enumerate(task.test):
        if not isinstance(pair, dict) or "input" not in pair:
            problems.append(f"test[{index}]: missing input")
            continue
        problems += _grid_problems(pair["input"], f"test[{index}].input")
    return problems


def verify_arc_dataset(tasks: list[ArcTask]) -> dict:
    report = {"ok": True, "total": len(tasks), "valid": 0, "invalid": [], "problems": {}}
    for task in tasks:
        problems = validate_task(task)
        if problems:
            report["invalid"].append(task.task_id)
            report["problems"][task.task_id] = problems
        else:
            report["valid"] += 1
    report["ok"] = not report["invalid"]
    return report


def load_arc_subset(path: str | Path = DEFAULT_SUBSET) -> list[ArcTask]:
    """Load the frozen subset and refuse any task whose bytes changed."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"{path} is missing. Run: python eval/fetch_arc.py --n 20 --seed 0")
    payload = json.loads(path.read_text(encoding="utf-8"))
    tasks = []
    for row in payload.get("tasks", []):
        body = {"train": row["train"], "test": row["test"]}
        digest = sha256_bytes(canonical(body))
        if row.get("sha256") and digest != row["sha256"]:
            raise ValueError(
                f"sha256 mismatch for task {row.get('task_id')}: "
                f"expected {row['sha256']}, computed {digest}")
        tasks.append(ArcTask(task_id=row["task_id"], train=row["train"],
                             test=row["test"], sha256=digest,
                             metadata={"dataset": payload.get("dataset"),
                                       "split": payload.get("split"),
                                       "license": payload.get("license")}))
    return tasks


def load_manifest(path: str | Path = DEFAULT_SUBSET) -> dict:
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    return {key: value for key, value in payload.items() if key != "tasks"}


def grid_as_text(grid) -> str:
    """Compact one-line rendering for prompts. Real grids only."""
    return "[" + ",".join("[" + ",".join(str(cell) for cell in row) + "]" for row in grid) + "]"
