"""Phase 5 - the evaluation harness.

A run reports one of three states and never blurs them:

* ``measured`` - a real backend ran against real tasks; the numbers are counts.
* ``not_run``  - the dataset, the weights or the sandbox were absent.  No
                 number is produced; ``pass_rate`` and ``solved`` stay ``None``.
* ``partial``  - some tasks could not be scored.  The denominator says how many
                 were actually scored.

The ARC suite drives the real control loop: the training pairs become the
checks the gate uses, the solver never sees the test outputs, and the accepted
program is scored once against the held-back test pair.

Usage:
    python eval/harness.py --suite arc --n 20 --seed 0
    python eval/harness.py --suite arc --split training --n 20 --out eval/results_training.json
    python eval/harness.py --suite swebench
"""
from __future__ import annotations

import argparse
import json
import os
import platform
import random
import re
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

try:                                    # script execution
    from eval.arc_data import (DEFAULT_SUBSET, load_arc_subset, load_manifest,
                               validate_task)
    from eval.arc_dsl import ArcDSLBackend, apply_source
except ImportError:                     # pragma: no cover - package execution
    from arc_data import (DEFAULT_SUBSET, load_arc_subset, load_manifest,
                          validate_task)
    from arc_dsl import ArcDSLBackend, apply_source

from core.agi_loop import AGILoop, Task

HUMAN_BASELINE = 0.66
HUMAN_SOURCE = ("ARC Prize: average human score on the ARC-AGI-1 private "
                "evaluation set, reported as roughly 66 percent")


# --------------------------------------------------------------------- helpers
def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def git_hash() -> str | None:
    try:
        out = subprocess.run(["git", "rev-parse", "HEAD"], cwd=ROOT,
                             capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None
    return out.stdout.strip() or None


def environment() -> dict:
    return {"python": sys.version.split()[0], "platform": platform.platform(),
            "git": git_hash(), "timestamp": now_utc()}


def grid_literal(grid) -> str:
    return repr(grid)


def test_statements(train: list[dict]) -> list[str]:
    return [f"assert solve({grid_literal(pair['input'])}) == {grid_literal(pair['output'])}"
            for pair in train]


def subset_path(split: str) -> Path:
    return ROOT / "eval" / "data" / f"arc_agi1_{split}_seed0.json"


def empty_result(suite: str, reason: str, **extra) -> dict:
    payload = {
        "suite": suite,
        "status": "not_run",
        "reason": reason,
        "summary": "not run",
        "solved": None,
        "scored": 0,
        "invalid": 0,
        "pass_rate": None,
        "human_baseline": HUMAN_BASELINE if suite == "arc" else None,
        "human_baseline_source": HUMAN_SOURCE if suite == "arc" else None,
        "tasks": [],
        "backend": {"label": "none", "is_real": False},
        **environment(),
    }
    payload.update(extra)
    return payload


def write_json(path: str | Path | None, payload: dict) -> None:
    if path is None:
        return
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def write_index(path: str | Path | None, payload: dict, dataset_note: str) -> None:
    if path is None:
        return
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    header = "" if path.exists() else (
        "# Measured results\n\n"
        "Every row below comes from a real command; the harness writes `not_run`\n"
        "instead of a number when a dataset, weight file or sandbox is missing.\n\n")
    lines = [
        f"## {payload['suite'].upper()} - {payload.get('dataset', {}).get('name', 'unknown dataset')} "
        f"[{payload.get('dataset', {}).get('split', 'n/a')}]",
        "",
        f"- Run at: {payload['timestamp']}",
        f"- Git: {payload.get('git') or 'unavailable'}",
        f"- Dataset: {dataset_note}",
        f"- Backend: {payload.get('backend', {}).get('label', 'none')} "
        f"(is_real={payload.get('backend', {}).get('is_real')})",
        f"- Status: **{payload['status']}**",
        f"- Result: **{payload['summary']}**",
        f"- Scored tasks: {payload.get('scored')} (invalid: {payload.get('invalid')})",
        f"- Baseline note: {payload.get('dataset', {}).get('baseline_note', 'n/a')}",
        "",
    ]
    with path.open("a", encoding="utf-8") as handle:
        if not (path.exists() and path.stat().st_size > 0):
            handle.write(header)
        handle.write("\n".join(lines) + "\n")


# ------------------------------------------------------------------------- ARC
def display_path(path: Path) -> str:
    """Record repo-relative paths so a result file survives a move to another machine."""
    try:
        return path.resolve().relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def select_tasks(tasks, n: int | None, seed: int):
    if n is None or n >= len(tasks):
        return sorted(tasks, key=lambda task: task.task_id)
    chosen = random.Random(seed).sample(sorted(tasks, key=lambda t: t.task_id), n)
    return sorted(chosen, key=lambda task: task.task_id)


def evaluate_arc(tasks, *, backend, out=None, seed: int = 0,
                 dataset: dict | None = None, index=None) -> dict:
    rows, scored, solved, invalid = [], 0, 0, 0
    started = time.time()

    # The 66 percent figure was measured on the public evaluation split. A run on
    # any other split may not be compared with it, and must not imply that it can.
    split_label = str((dataset or {}).get("split", ""))
    comparable = split_label.startswith("evaluation") if split_label else True
    baseline = HUMAN_BASELINE if comparable else None

    for task in tasks:
        problems = validate_task(task)
        if problems:
            invalid += 1
            rows.append({"task_id": task.task_id, "status": "invalid", "success": False,
                         "calls": 0, "problems": problems,
                         "human_baseline": baseline})
            continue

        workdir = Path(tempfile.mkdtemp(prefix=f"arc_{task.task_id}_"))
        loop_task = Task(
            task_id=task.task_id,
            family="arc",
            description=(f"ARC-AGI-1 task {task.task_id}: infer the grid transformation "
                         f"from {len(task.train)} training pairs"),
            tests=test_statements(task.train),
            metadata={"context": {"train": task.train}},
        )
        backend.calls = 0
        loop = AGILoop(loop_task, backend, workdir, max_candidates=3, seed=seed)
        result = loop.run()
        calls = backend.calls

        candidate = result["best_candidate"]
        success, error = False, None
        if candidate:
            try:
                success = all(apply_source(candidate, pair["input"]) == pair["output"]
                              for pair in task.test)
            except Exception as exc:                   # noqa: BLE001 - recorded, not hidden
                error = f"{type(exc).__name__}: {exc}"

        rows.append({
            "task_id": task.task_id,
            "status": "scored",
            "success": bool(success),
            "calls": calls,
            "accepted": result["accepted_count"],
            "train_pairs": len(task.train),
            "test_pairs": len(task.test),
            "sha256": task.sha256,
            "human_baseline": baseline,
            "error": error,
        })
        scored += 1
        solved += int(bool(success))

    rate = (solved / scored) if scored else None
    if scored and comparable:
        summary = f"{solved}/{scored} ({round(100 * rate)}% vs human 66%)"
    elif scored:
        summary = (f"{solved}/{scored} ({round(100 * rate)}%) - not comparable "
                   f"to the human 66% baseline")
    else:
        summary = "not run"
    payload = {
        "suite": "arc",
        "status": "measured" if scored else "not_run",
        "reason": "" if scored else "no valid task to score",
        "summary": summary,
        "solved": solved if scored else None,
        "scored": scored,
        "invalid": invalid,
        "pass_rate": rate,
        "human_baseline": baseline,
        "human_baseline_source": HUMAN_SOURCE if comparable else None,
        "dataset": dataset or {},
        "backend": backend.identity(),
        "measurement_class": "real" if getattr(backend, "is_real", False) else "engineering_only",
        "tasks": rows,
        "wall_s": round(time.time() - started, 3),
        **environment(),
    }
    write_json(out, payload)
    write_index(index, payload, dataset.get("path", "unknown") if dataset else "unknown")
    return payload


def run_arc(*, n: int | None = 20, seed: int = 0, data=None, split: str = "evaluation",
            out=None, index=None, backend=None) -> dict:
    """Measure one ARC subset. Writing is opt-in: pass out/index to persist.

    A library call must never overwrite a recorded measurement, so the defaults
    write nothing. The command line interface below supplies the repository paths.
    """
    path = Path(data) if data else subset_path(split)
    if not path.exists():
        payload = empty_result("arc", f"dataset not found: {path}. "
                                      f"Run: python eval/fetch_arc.py --n {n or 20} --seed {seed}",
                               dataset={"path": str(path), "name": "ARC-AGI-1"})
        write_json(out, payload)
        return payload

    tasks = load_arc_subset(path)
    manifest = load_manifest(path)
    chosen = select_tasks(tasks, n, seed)
    dataset = {
        "name": "ARC-AGI-1",
        "split": manifest.get("split", split),
        "baseline_note": ("comparable to the ARC Prize human baseline"
                           if split == "evaluation" else
                           "training split: easier than the evaluation split the 66 percent "
                           "baseline was measured on, so this percentage is not comparable"),
        "path": display_path(path),
        "sha256": __import__("hashlib").sha256(path.read_bytes()).hexdigest(),
        "tasks_available": len(tasks),
        "tasks_selected": len(chosen),
        "selection": {"method": "random.Random(seed).sample(sorted(task_ids), n)",
                      "seed": seed, "n": n},
        "license": manifest.get("license"),
        "source": manifest.get("source"),
        "available_tasks_in_split": manifest.get("available_tasks"),
    }
    backend = backend or ArcDSLBackend(seed=seed)
    return evaluate_arc(chosen, backend=backend, out=out, seed=seed,
                        dataset=dataset, index=index)


# -------------------------------------------------------------------- SWE-bench
def run_swebench(*, path=None, sandbox: str | None = None, out=None, index=None) -> dict:
    """Measure SWE-bench Lite or record why it cannot run. Writing is opt-in."""
    if path is None or not Path(path).exists():
        payload = empty_result(
            "swebench",
            "dataset not found: SWE-bench Lite requires its JSONL file "
            "(downloaded separately; this repository ships no SWE-bench data).",
            dataset={"name": "SWE-bench Lite", "path": str(path)})
        write_json(out, payload)
        return payload

    rows = [json.loads(line) for line in Path(path).read_text(encoding="utf-8").splitlines()
            if line.strip()]
    if not sandbox:
        payload = empty_result(
            "swebench",
            "no sandbox command supplied: each instance needs the repository checked out "
            "at its base commit in a container, and this harness will not simulate that.",
            dataset={"name": "SWE-bench Lite", "path": str(path), "instances": len(rows)})
        write_json(out, payload)
        return payload

    results, solved = [], 0
    for row in rows:
        instance = row.get("instance_id", "unknown")
        env = dict(os.environ, NAWAH_INSTANCE_ID=instance,
                   NAWAH_REPO=row.get("repo", ""),
                   NAWAH_BASE_COMMIT=row.get("base_commit", ""),
                   NAWAH_PROBLEM=row.get("problem_statement", ""))
        try:
            proc = subprocess.run(sandbox, shell=True, cwd=Path(path).parent,
                                  env=env, capture_output=True, text=True, timeout=1800)
            ok = proc.returncode == 0
        except subprocess.SubprocessError as exc:
            ok, proc = False, None
            results.append({"instance_id": instance, "success": False,
                            "error": str(exc)})
            continue
        solved += int(ok)
        results.append({"instance_id": instance, "success": ok,
                        "returncode": proc.returncode,
                        "tail": (proc.stdout or "")[-400:]})

    payload = {
        "suite": "swebench",
        "status": "measured" if results else "not_run",
        "reason": "" if results else "no instances in the file",
        "summary": f"{solved}/{len(results)} resolved" if results else "not run",
        "solved": solved if results else None,
        "scored": len(results),
        "invalid": 0,
        "pass_rate": (solved / len(results)) if results else None,
        "human_baseline": None,
        "dataset": {"name": "SWE-bench Lite", "path": str(path)},
        "backend": {"label": "sandbox", "is_real": True, "command": sandbox},
        "measurement_class": "real",
        "tasks": results,
        **environment(),
    }
    write_json(out, payload)
    write_index(index, payload, str(path))
    return payload


# ------------------------------------------------------------------------- CLI
def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="NAWAH evaluation harness")
    parser.add_argument("--suite", choices=("arc", "swebench", "all"), default="arc")
    parser.add_argument("--n", type=int, default=20)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--split", choices=("evaluation", "training"), default="evaluation")
    parser.add_argument("--data", type=Path, default=None)
    parser.add_argument("--backend", choices=("arc_dsl", "llama_cpp", "none"),
                        default="arc_dsl")
    parser.add_argument("--model", type=Path, default=None)
    parser.add_argument("--sandbox", default=None)
    parser.add_argument("--out", type=Path, default=None)
    parser.add_argument("--index", type=Path, default=Path("eval/RESULTS.md"))
    args = parser.parse_args(argv)

    backend = None
    if args.backend == "arc_dsl":
        backend = ArcDSLBackend(seed=args.seed)
    elif args.backend == "llama_cpp":
        try:
            from core.backends import BackendError, LlamaCppBackend
            if args.model is None:
                raise BackendError("--model is required for the llama_cpp backend")
            backend = LlamaCppBackend(args.model)
        except Exception as exc:                    # noqa: BLE001 - reported as not_run
            payload = empty_result("arc", f"backend unavailable: {exc}")
            write_json(args.out, payload)
            print(f"not_run: {payload['reason']}")
            return 0

    if args.suite in ("arc", "all"):
        out = args.out or Path("eval/results.json")
        result = run_arc(n=args.n, seed=args.seed, data=args.data, split=args.split,
                         out=out, index=args.index, backend=backend)
        print(f"arc ({args.split}): {result['status']} - {result['summary']}")
    if args.suite in ("swebench", "all"):
        out = (args.out if args.suite == "swebench" and args.out
               else Path("eval/results_swebench.json"))
        result = run_swebench(path=args.data, sandbox=args.sandbox,
                              out=out, index=args.index)
        print(f"swebench: {result['status']} - {result['summary']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
