# ARC-AGI-1 subset provenance

| Field | Value |
|---|---|
| Dataset | ARC-AGI-1 |
| Authors | Francois Chollet et al. |
| Repository | https://github.com/fchollet/ARC |
| Licence | Apache-2.0 |
| Split used | `data/evaluation` (the public evaluation set) |
| Tasks available in split | 400 |
| Tasks in this subset | 20 |
| Selection rule | `random.Random(seed).sample(sorted(task_ids), n)`, then sorted |
| Seed | 0 |
| Public human baseline | 0.66 (ARC Prize, ARC-AGI-1 private evaluation set) |
| Frozen file | `eval/data/arc_agi1_subset.json` |
| Per-task integrity | SHA-256 over canonical `{"train", "test"}` JSON, verified on load |

The harness never downloads anything. `eval/fetch_arc.py` performs the one-time
download and freezes the bytes; `eval/arc_data.py` refuses to load a subset
whose task hashes no longer match.

The public evaluation split contains the expected test outputs. The solver
never receives them: `ArcDSLBackend.complete` is given the train pairs only,
and the harness compares predictions with the held-back test outputs exactly
once, at scoring time. The split is therefore a holdout with respect to this
solver, though not a private one.

## Why a 20-task subset

`PROMPTS.md` asks for `--n 20`. Twenty tasks keep the frozen artifact at about
0.6 MB, inside the 5 MB release budget, while remaining a real slice of the
real benchmark rather than hand-written toys. A larger run is one command:

```
python eval/fetch_arc.py --n 200 --seed 0 --out eval/data/arc_agi1_200.json
python eval/harness.py --suite arc --data eval/data/arc_agi1_200.json
```

The result will be a different, larger measurement; the README records which
file produced which number.
