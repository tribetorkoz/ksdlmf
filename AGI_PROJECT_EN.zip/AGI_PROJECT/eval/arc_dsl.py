"""A deterministic DSL solver used as the evaluation backend.

This is program synthesis, not a language model.  It enumerates a fixed family
of grid transformations, keeps only those that reproduce *every* training pair
exactly, and ranks the survivors by complexity.  The test pair is never shown
to this module's search: the harness calls ``complete`` with ``train`` only,
and scores the accepted program later.

What the DSL can express: identity, the eight dihedral transforms, a learned
colour map, a constant output, crop-to-content, integer tiling, integer
scaling, mirror-symmetry repair, and a 3x3 neighbourhood rule.

What it cannot express: anything involving counting objects, comparing sizes,
sorting, or composing two learned rules.  The reported pass rate is therefore
a floor for this DSL, not a ceiling for the architecture, and it says nothing
about general intelligence.

No imports beyond builtins inside the generated programs, no network, no
randomness: two runs produce the same source for the same training pairs.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

GENERATED_HEADER = "def solve(g):"


@dataclass(frozen=True)
class Program:
    name: str
    source: str
    complexity: int


def apply_source(source: str, grid):
    """Execute a generated program on one grid. Raises on a broken program."""
    namespace: dict = {}
    exec(compile(source, "<program>", "exec"), namespace)
    return namespace["solve"](grid)


def matches(source: str, train: list[dict]) -> bool:
    """True only when the program reproduces every training pair exactly."""
    try:
        solve = apply_source
        for pair in train:
            if solve(source, pair["input"]) != pair["output"]:
                return False
        return True
    except Exception:                                  # noqa: BLE001 - a broken program is a miss
        return False


def _shape(grid):
    return len(grid), len(grid[0])


def _same_shape(pairs: list[dict]) -> bool:
    try:
        return all(_shape(p["input"]) == _shape(p["output"]) for p in pairs)
    except (TypeError, IndexError):
        return False


def valid_grid(grid) -> bool:
    """A real ARC grid: non-empty, rectangular, integer colours 0..9."""
    if not isinstance(grid, list) or not grid:
        return False
    if not all(isinstance(row, list) and row for row in grid):
        return False
    if len({len(row) for row in grid}) != 1:
        return False
    return all(isinstance(cell, int) and not isinstance(cell, bool) and 0 <= cell <= 9
               for row in grid for cell in row)


def valid_train(train) -> bool:
    if not isinstance(train, list) or not train:
        return False
    return all(isinstance(pair, dict) and valid_grid(pair.get("input"))
               and valid_grid(pair.get("output")) for pair in train)


def _most_common(grid) -> int:
    counts: dict[int, int] = {}
    for row in grid:
        for cell in row:
            counts[cell] = counts.get(cell, 0) + 1
    return max(counts, key=lambda colour: (counts[colour], -colour))


# --------------------------------------------------------------------- families
GEOMETRY = [
    ("identity", "[row[:] for row in g]"),
    ("rot90", "[list(row) for row in zip(*g[::-1])]"),
    ("rot180", "[row[::-1] for row in g[::-1]]"),
    ("rot270", "[list(row) for row in zip(*g)][::-1]"),
    ("flip_h", "[row[::-1] for row in g]"),
    ("flip_v", "[row[:] for row in g[::-1]]"),
    ("transpose", "[list(row) for row in zip(*g)]"),
    ("anti_transpose", "[list(row) for row in zip(*[row[::-1] for row in g[::-1]])]"),
]

TRANSFORMS = dict(GEOMETRY)


def geometry_programs() -> list[Program]:
    return [Program(name, f"def solve(g):\n    return {expression}", 1)
            for name, expression in GEOMETRY]


def colour_map_program(train: list[dict]) -> Program | None:
    if not _same_shape(train):
        return None
    mapping: dict[int, int] = {}
    for pair in train:
        for in_row, out_row in zip(pair["input"], pair["output"]):
            for source_colour, target_colour in zip(in_row, out_row):
                if mapping.setdefault(source_colour, target_colour) != target_colour:
                    return None
    literal = "{" + ", ".join(f"{key}: {value}" for key, value in sorted(mapping.items())) + "}"
    source = (f"def solve(g):\n    mapping = {literal}\n"
              "    return [[mapping.get(cell, cell) for cell in row] for row in g]")
    return Program("colour_map", source, 2)


def composed_colour_program(train: list[dict], name: str, expression: str) -> Program | None:
    """A dihedral transform followed by a learned colour map."""
    if not _same_shape(train):
        return None
    namespace: dict = {}
    exec(f"def solve(g):\n    return {expression}", namespace)
    transform = namespace["solve"]
    mapping: dict[int, int] = {}
    for pair in train:
        try:
            transformed = transform(pair["input"])
        except Exception:                                  # noqa: BLE001
            return None
        target = pair["output"]
        if len(transformed) != len(target):
            return None
        if any(len(source_row) != len(target_row)
               for source_row, target_row in zip(transformed, target)):
            return None
        for source_row, target_row in zip(transformed, target):
            for source_colour, target_colour in zip(source_row, target_row):
                if mapping.setdefault(source_colour, target_colour) != target_colour:
                    return None
    literal = "{" + ", ".join(f"{key}: {value}" for key, value in sorted(mapping.items())) + "}"
    source = (f"def solve(g):\n    mapping = {literal}\n"
              f"    return [[mapping.get(cell, cell) for cell in row] for row in {expression}]")
    return Program(f"{name}_colour", source, 3)


def constant_program(train: list[dict]) -> Program | None:
    # Two pairs are the minimum evidence that the output ignores the input.
    if len(train) < 2:
        return None
    first = train[0]["output"]
    if any(pair["output"] != first for pair in train[1:]):
        return None
    rows = ", ".join(str(row) for row in first)
    source = f"def solve(g):\n    return [{rows}]"
    return Program("constant_output", source, 3)


def crop_program(train: list[dict]) -> Program | None:
    source = (
        "def solve(g):\n"
        "    counts = {}\n"
        "    for row in g:\n"
        "        for cell in row:\n"
        "            counts[cell] = counts.get(cell, 0) + 1\n"
        "    bg = max(counts, key=lambda colour: (counts[colour], -colour))\n"
        "    cells = [(r, c) for r, row in enumerate(g)\n"
        "             for c, cell in enumerate(row) if cell != bg]\n"
        "    if not cells:\n"
        "        return [row[:] for row in g]\n"
        "    r0 = min(r for r, _ in cells); r1 = max(r for r, _ in cells)\n"
        "    c0 = min(c for _, c in cells); c1 = max(c for _, c in cells)\n"
        "    return [row[c0:c1 + 1] for row in g[r0:r1 + 1]]"
    )
    return Program("crop_to_content", source, 3)


def tile_program(train: list[dict]) -> Program | None:
    try:
        in_h, in_w = _shape(train[0]["input"])
        out_h, out_w = _shape(train[0]["output"])
    except (TypeError, IndexError):
        return None
    if in_h == 0 or in_w == 0 or out_h % in_h or out_w % in_w:
        return None
    vertical, horizontal = out_h // in_h, out_w // in_w
    if (vertical, horizontal) == (1, 1):
        return None
    blocks = {
        "identity": "g",
        "flip_v": "g[::-1]",
        "flip_h": "[row[::-1] for row in g]",
        "rot180": "[row[::-1] for row in g[::-1]]",
    }
    source_template = (
        "def solve(g):\n"
        "    block = {block}\n"
        "    h = len(block); w = len(block[0])\n"
        "    out = [[0] * (w * {horizontal}) for _ in range(h * {vertical})]\n"
        "    for i in range({vertical}):\n"
        "        for j in range({horizontal}):\n"
        "            for r in range(h):\n"
        "                for c in range(w):\n"
        "                    out[i * h + r][j * w + c] = block[r][c]\n"
        "    return out"
    )
    return Program(f"tile_{vertical}x{horizontal}",
                   source_template.format(block=blocks["identity"],
                                          vertical=vertical, horizontal=horizontal), 4)


def scale_program(train: list[dict]) -> Program | None:
    try:
        in_h, in_w = _shape(train[0]["input"])
        out_h, out_w = _shape(train[0]["output"])
    except (TypeError, IndexError):
        return None
    if in_h == 0 or in_w == 0:
        return None
    if out_h % in_h or out_w % in_w:
        return None
    factor_h, factor_w = out_h // in_h, out_w // in_w
    if factor_h != factor_w or factor_h < 2:
        return None
    source = (f"def solve(g):\n    factor = {factor_h}\n"
              "    return [[cell for cell in row for _ in range(factor)]\n"
              "            for row in g for _ in range(factor)]")
    return Program(f"scale_{factor_h}x", source, 4)


def background_candidates(train: list[dict]) -> list[int]:
    """Backgrounds worth trying: 0 (ARC convention) and the most common colour."""
    candidates = [0]
    try:
        common = _most_common(train[0]["input"])
    except (TypeError, ValueError, IndexError, KeyError):
        common = None
    if common is not None and common not in candidates:
        candidates.append(common)
    return candidates


def symmetry_program(train: list[dict], bg: int = 0) -> Program | None:
    if not _same_shape(train):
        return None
    source = (
        f"def solve(g):\n"
        f"    bg = {bg}\n"
        "    h = len(g); w = len(g[0])\n"
        "    out = [row[:] for row in g]\n"
        "    for r in range(h):\n"
        "        for c in range(w):\n"
        "            if out[r][c] != bg:\n"
        "                continue\n"
        "            for rr, cc in ((r, w - 1 - c), (h - 1 - r, c), (h - 1 - r, w - 1 - c)):\n"
        "                if out[rr][cc] != bg:\n"
        "                    out[r][c] = out[rr][cc]\n"
        "                    break\n"
        "    return out"
    )
    return Program("symmetry_repair", source, 5)


def neighbourhood_program(train: list[dict], limit: int = 400) -> Program | None:
    if not _same_shape(train):
        return None
    rule: dict[tuple, int] = {}

    def key_for(grid, r, c):
        h, w = _shape(grid)
        centre = grid[r][c]
        values = []
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                rr, cc = r + dr, c + dc
                values.append(grid[rr][cc] if 0 <= rr < h and 0 <= cc < w else centre)
        return tuple(values)

    for pair in train:
        grid, target = pair["input"], pair["output"]
        h, w = _shape(grid)
        for r in range(h):
            for c in range(w):
                key = key_for(grid, r, c)
                if rule.setdefault(key, target[r][c]) != target[r][c]:
                    return None
    if len(rule) > limit:
        return None
    literal = "{" + ", ".join(f"{key!r}: {value}" for key, value in sorted(rule.items())) + "}"
    source = (
        f"def solve(g):\n    rule = {literal}\n"
        "    h = len(g); w = len(g[0])\n"
        "    out = []\n"
        "    for r in range(h):\n"
        "        row = []\n"
        "        for c in range(w):\n"
        "            centre = g[r][c]\n"
        "            key = tuple(g[r + dr][c + dc]\n"
        "                        if 0 <= r + dr < h and 0 <= c + dc < w else centre\n"
        "                        for dr in (-1, 0, 1) for dc in (-1, 0, 1))\n"
        "            row.append(rule.get(key, centre))\n"
        "        out.append(row)\n"
        "    return out"
    )
    return Program("neighbourhood_3x3", source, 7)


def candidate_programs(train: list[dict]) -> list[Program]:
    """Every family this DSL can express, before verification."""
    programs = geometry_programs()
    for name, expression in GEOMETRY:
        if name == "identity":
            continue
        program = composed_colour_program(train, name, expression)
        if program is not None:
            programs.append(program)
    for bg in background_candidates(train):
        program = symmetry_program(train, bg)
        if program is not None:
            programs.append(program)
    for builder in (colour_map_program, constant_program, crop_program,
                    tile_program, scale_program, neighbourhood_program):
        try:
            program = builder(train)
        except (TypeError, ValueError, IndexError, KeyError):
            program = None
        if program is not None:
            programs.append(program)
    return programs


def programs_for(train: list[dict]) -> list[Program]:
    """Programs that reproduce every training pair, ranked by complexity."""
    if not valid_train(train):
        return []
    survived, seen = [], set()
    for program in candidate_programs(train):
        if program.source in seen:
            continue
        if matches(program.source, train):
            survived.append(program)
            seen.add(program.source)
    survived.sort(key=lambda program: (program.complexity, program.name))
    return survived


class ArcDSLBackend:
    """A real, non-neural backend: it returns code, and the loop verifies it."""

    is_real = True
    supports_context = True
    label = "arc_dsl_v1"

    def __init__(self, seed: int = 0):
        self.seed = seed
        self.calls = 0

    def identity(self) -> dict:
        return {
            "label": self.label,
            "is_real": True,
            "weights_sha256": None,
            "note": ("deterministic program synthesis over a fixed DSL; "
                     "no learned weights, no general intelligence claim"),
        }

    def programs_for(self, train: list[dict]) -> list[Program]:
        return programs_for(train)

    def best_source(self, train: list[dict]) -> str | None:
        programs = programs_for(train)
        return programs[0].source if programs else None

    def complete(self, prompt: str, context: dict | None = None) -> dict:
        self.calls += 1
        train = (context or {}).get("train") or []
        programs = programs_for(train)
        attempt = 1
        match = re.search(r"attempt (\d+)", prompt or "")
        if match:
            attempt = int(match.group(1))
        program = programs[attempt - 1] if 0 < attempt <= len(programs) else None
        return {
            "code": program.source if program else "",
            "program": program.name if program else None,
            "programs_found": len(programs),
            "tokens_in": None,
            "tokens_out": None,
            "cached": False,
        }
