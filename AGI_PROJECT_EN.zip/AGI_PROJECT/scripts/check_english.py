"""Scan every project text file for characters in the Arabic Unicode block.

Acceptance for phase 7 requires zero matches for U+0600..U+06FF. This script is
the mechanical check; it prints one line per offender and a final count.

    python scripts/check_english.py
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARABIC = re.compile(r"[\u0600-\u06FF]")
TEXT_SUFFIXES = {".py", ".md", ".json", ".sh", ".ps1", ".txt", ".ini", ".cfg",
                 ".toml", ".yml", ".yaml", ".html", ".css", ".js", ".bat"}
EXTRA_NAMES = {".gitignore", "pytest.ini"}
SKIP_DIRS = {".git", "__pycache__", ".cache", ".venv", "venv", "node_modules",
             ".pytest_cache", ".mypy_cache"}


def text_files() -> list[Path]:
    files = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        if path.suffix.lower() in TEXT_SUFFIXES or path.name in EXTRA_NAMES:
            files.append(path)
    return sorted(files)


def main() -> int:
    files = text_files()
    matches = 0
    for path in files:
        try:
            lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        except OSError as exc:
            print(f"unreadable: {path} ({exc})")
            continue
        for number, line in enumerate(lines, 1):
            for hit in ARABIC.finditer(line):
                matches += 1
                print(f"{path.relative_to(ROOT)}:{number}:{hit.start() + 1}: "
                      f"U+{ord(hit.group()):04X}")
    print(f"\nscanned {len(files)} text files")
    print(f"{matches} matches in U+0600..U+06FF")
    return 0 if matches == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
