"""Build AGI_PROJECT_EN.zip, the release archive.

The archive contains one top-level directory, AGI_PROJECT/, with the specification,
all seven phases, the evaluation harness and data, the tests, and the reproduction
scripts. Caches, virtual environments, git metadata, model weights and the archive
itself are excluded. The build fails if the archive reaches 5 MB.

    python scripts/make_release.py
"""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / "AGI_PROJECT_EN.zip"
MAX_BYTES = 5 * 1024 * 1024
SKIP_DIRS = {".git", "__pycache__", ".cache", ".venv", "venv", "node_modules",
             ".pytest_cache", ".mypy_cache"}
SKIP_SUFFIXES = {".pyc", ".pyo", ".gguf", ".zip", ".log", ".tmp"}
INCLUDE = ["PROMPTS.md", "PHASES.md", "README.md", "requirements.txt", "pytest.ini",
           "test_agi.py", ".gitignore", "core", "eval", "reproduce", "scripts",
           "tests", "docs"]


def wanted(path: Path) -> bool:
    relative = path.relative_to(ROOT)
    if any(part in SKIP_DIRS for part in relative.parts):
        return False
    if path.suffix.lower() in SKIP_SUFFIXES:
        return False
    if path == ARCHIVE:
        return False
    return True


def collect() -> list[Path]:
    files: list[Path] = []
    for name in INCLUDE:
        target = ROOT / name
        if target.is_file() and wanted(target):
            files.append(target)
        elif target.is_dir():
            files.extend(sorted(path for path in target.rglob("*") if path.is_file()
                                and wanted(path)))
    return sorted(set(files))


def main() -> int:
    files = collect()
    if not files:
        print("nothing to archive", file=sys.stderr)
        return 1
    if ARCHIVE.exists():
        ARCHIVE.unlink()
    with zipfile.ZipFile(ARCHIVE, "w", compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9) as bundle:
        for path in files:
            bundle.write(path, arcname="AGI_PROJECT/" + path.relative_to(ROOT).as_posix())

    size = ARCHIVE.stat().st_size
    with zipfile.ZipFile(ARCHIVE) as bundle:
        bad = bundle.testzip()
        members = bundle.namelist()

    print(f"wrote {ARCHIVE.name}: {size} bytes ({size / 1024 / 1024:.2f} MB)")
    print(f"members: {len(members)}")
    print(f"integrity: {'ok' if bad is None else 'broken at ' + str(bad)}")
    required = ["PROMPTS.md", "PHASES.md", "README.md", "test_agi.py",
                "core/agi_loop.py", "eval/harness.py", "eval/results.json",
                "reproduce/reproduce.sh", "scripts/check_english.py"]
    missing = [name for name in required
               if not any(member.endswith(name) for member in members)]
    if missing:
        print(f"missing required members: {missing}", file=sys.stderr)
        return 1
    if size >= MAX_BYTES:
        print(f"archive exceeds the 5 MB budget: {size} bytes", file=sys.stderr)
        return 1
    print("budget: under 5 MB")
    return 0


if __name__ == "__main__":
    sys.exit(main())
