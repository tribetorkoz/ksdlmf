"""Verify every artefact and every claim this repository makes.

Run:
    python reproduce/check.py

Exit code 0 means: all required files exist, both ARC subsets match their per-task
hashes, every results file is internally consistent, every SUPPORTED claim in
reproduce/CLAIMS.md names an existing evidence file, the project text contains zero
Arabic-block characters, and - if the release archive exists - it is under 5 MB and
contains the expected members.

Exit code 1 means at least one check failed; every failure is printed.
"""
from __future__ import annotations

import json
import re
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

try:
    from eval.arc_data import load_arc_subset
except ImportError:                                  # pragma: no cover
    from arc_data import load_arc_subset

TEXT_SUFFIXES = {".py", ".md", ".json", ".sh", ".ps1", ".txt", ".ini", ".cfg",
                 ".toml", ".yml", ".yaml", ".html", ".css", ".js", ".bat"}
SKIP_DIRS = {".git", "__pycache__", ".cache", ".venv", "venv", "node_modules",
             ".pytest_cache", ".mypy_cache"}
ARABIC = re.compile(r"[\u0600-\u06FF]")
ZIP_PATH = ROOT / "AGI_PROJECT_EN.zip"
MAX_ZIP_BYTES = 5 * 1024 * 1024

REQUIRED_FILES = [
    "PROMPTS.md",
    "README.md",
    "requirements.txt",
    "test_agi.py",
    "core/gate.py",
    "core/causal_memory_v2.py",
    "core/dreamer.py",
    "core/swarm.py",
    "core/skills.py",
    "core/agi_loop.py",
    "eval/harness.py",
    "eval/arc_data.py",
    "eval/arc_dsl.py",
    "eval/fetch_arc.py",
    "eval/data/PROVENANCE.md",
    "eval/data/arc_agi1_evaluation_seed0.json",
    "eval/data/arc_agi1_training_seed0.json",
    "eval/results.json",
    "eval/results_training.json",
    "eval/results_swebench.json",
    "eval/RESULTS.md",
    "reproduce/CLAIMS.md",
    "reproduce/check.py",
    "reproduce/reproduce.sh",
    "reproduce/reproduce.ps1",
    "tests/test_causal.py",
    "tests/test_dreamer.py",
    "tests/test_swarm.py",
    "tests/test_verify_code.py",
    "tests/test_agi_loop.py",
    "tests/test_arc_data.py",
    "tests/test_arc_dsl.py",
    "tests/test_harness.py",
]

RESULT_KEYS = ["suite", "status", "summary", "solved", "scored", "invalid",
               "pass_rate", "dataset", "backend", "git", "timestamp", "python",
               "platform", "tasks"]


class Report:
    def __init__(self) -> None:
        self.failures: list[str] = []
        self.passes = 0

    def check(self, name: str, condition: bool, detail: str = "") -> bool:
        if condition:
            self.passes += 1
            print(f"PASS  {name}")
            return True
        self.failures.append(f"{name}: {detail}" if detail else name)
        print(f"FAIL  {name}" + (f" - {detail}" if detail else ""))
        return False

    def finish(self) -> int:
        print()
        if self.failures:
            print(f"{len(self.failures)} failure(s), {self.passes} check(s) passed")
            for failure in self.failures:
                print(f"  - {failure}")
            return 1
        print(f"all {self.passes} checks passed")
        return 0


def check_files(report: Report) -> None:
    for name in REQUIRED_FILES:
        report.check(f"file exists: {name}", (ROOT / name).is_file())


def check_dataset(report: Report) -> None:
    for name in ("eval/data/arc_agi1_evaluation_seed0.json",
                 "eval/data/arc_agi1_training_seed0.json"):
        path = ROOT / name
        if not path.is_file():
            continue
        try:
            tasks = load_arc_subset(path)
        except Exception as exc:                     # noqa: BLE001 - reported
            report.check(f"dataset loads: {name}", False, str(exc))
            continue
        report.check(f"dataset loads with hash check: {name}", len(tasks) == 20,
                     f"expected 20 tasks, got {len(tasks)}")


def check_results_file(report: Report, name: str) -> dict | None:
    path = ROOT / name
    if not path.is_file():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        report.check(f"results parse: {name}", False, str(exc))
        return None
    report.check(f"results parse: {name}", True)
    report.check(f"results keys: {name}",
                 all(key in payload for key in RESULT_KEYS),
                 f"missing {[k for k in RESULT_KEYS if k not in payload]}")

    status = payload.get("status")
    if status == "measured":
        report.check(f"measured has a number: {name}",
                     payload.get("pass_rate") is not None
                     and isinstance(payload.get("solved"), int)
                     and payload.get("scored", 0) > 0)
        rows = payload.get("tasks", [])
        report.check(f"task rows match the denominator: {name}",
                     len(rows) == payload.get("scored", 0) + payload.get("invalid", 0))
        report.check(f"task rows carry the required fields: {name}",
                     all({"task_id", "success", "calls", "human_baseline"} <= set(row)
                         for row in rows))
        report.check(f"measured run records git: {name}",
                     bool(payload.get("git")) and len(str(payload["git"])) >= 7)
        report.check(f"measured run records a UTC timestamp: {name}",
                     str(payload.get("timestamp", "")).endswith("Z"))
        report.check(f"measured run records backend identity: {name}",
                     isinstance(payload.get("backend"), dict)
                     and bool(payload["backend"].get("label")))
    elif status == "not_run":
        report.check(f"not_run has no metric: {name}",
                     payload.get("pass_rate") is None and payload.get("solved") is None,
                     "a not_run result must not carry a score")
        report.check(f"not_run states a reason: {name}", bool(payload.get("reason")))
    else:
        report.check(f"status is known: {name}", False, str(status))
    return payload


def check_claims(report: Report) -> None:
    path = ROOT / "reproduce/CLAIMS.md"
    if not path.is_file():
        return
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        match = re.match(r"^\|\s*(C\d+)\s*\|(.+?)\|(.+?)\|(.+?)\|\s*$", line)
        if match:
            rows.append((match.group(1), match.group(2).strip(),
                         match.group(3).strip(), match.group(4).strip()))
    report.check("claims table has rows", len(rows) >= 10, f"found {len(rows)}")
    report.check("claims table has unsupported rows",
                 any(status == "UNSUPPORTED" for _, _, status, _ in rows))

    for claim_id, text, status, evidence in rows:
        if status == "SUPPORTED":
            names = [part.strip().strip("`") for part in evidence.split(",")]
            report.check(f"{claim_id} has evidence files", all(names),
                         "no file named")
            for name in names:
                report.check(f"{claim_id} evidence exists: {name}",
                             (ROOT / name).exists(), "missing")
            numeric = re.search(r"(\d+)\s+of\s+(\d+)", text)
            if numeric:
                for name in names:
                    candidate = ROOT / name
                    if candidate.suffix != ".json":
                        continue
                    try:
                        payload = json.loads(candidate.read_text(encoding="utf-8"))
                    except json.JSONDecodeError:
                        continue
                    solved, total = int(numeric.group(1)), int(numeric.group(2))
                    report.check(f"{claim_id} matches {name}",
                                 payload.get("solved") == solved
                                 and payload.get("scored") == total,
                                 f"claim {solved}/{total}, file "
                                 f"{payload.get('solved')}/{payload.get('scored')}")
        elif status == "UNSUPPORTED":
            report.check(f"{claim_id} carries no evidence", evidence.strip() in {"-", ""},
                         evidence)
        else:
            report.check(f"{claim_id} status is known", False, status)


def text_files() -> list[Path]:
    files = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        if path == ZIP_PATH:
            continue
        if path.suffix.lower() in TEXT_SUFFIXES or path.name in {".gitignore", "pytest.ini"}:
            files.append(path)
    return sorted(files)


def check_english(report: Report) -> None:
    files = text_files()
    offenders = []
    for path in files:
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for match in ARABIC.finditer(text):
            offenders.append(f"{path.relative_to(ROOT)}: U+{ord(match.group()):04X}")
            break
    report.check(f"English-only across {len(files)} text files",
                 not offenders, "; ".join(offenders[:5]))


def check_prompts(report: Report) -> None:
    path = ROOT / "PROMPTS.md"
    if not path.is_file():
        return
    text = path.read_text(encoding="utf-8")
    phases = [f"PHASE {number}" for number in range(1, 8)]
    report.check("PROMPTS.md covers all seven phases",
                 all(phase in text for phase in phases),
                 f"missing {[p for p in phases if p not in text]}")


def check_zip(report: Report) -> None:
    if not ZIP_PATH.exists():
        print("SKIP  release archive not built yet")
        return
    size = ZIP_PATH.stat().st_size
    report.check("archive is under 5 MB", size < MAX_ZIP_BYTES,
                 f"{size} bytes")
    with zipfile.ZipFile(ZIP_PATH) as bundle:
        names = bundle.namelist()
    joined = "\n".join(names)
    required = ["PROMPTS.md", "README.md", "test_agi.py", "core/gate.py",
                "core/causal_memory_v2.py", "core/dreamer.py", "core/swarm.py",
                "core/agi_loop.py", "eval/harness.py", "eval/results.json",
                "reproduce/reproduce.sh"]
    missing = [name for name in required if not any(n.endswith(name) for n in names)]
    report.check("archive contains the seven phases and core/eval", not missing,
                 f"missing {missing}")
    report.check("archive has one top-level directory", all(n.startswith("AGI_PROJECT/")
                                                           for n in names),
                 joined[:200])


def main() -> int:
    report = Report()
    print(f"verifying {ROOT}\n")
    check_files(report)
    check_dataset(report)
    for name in ("eval/results.json", "eval/results_training.json",
                 "eval/results_swebench.json"):
        check_results_file(report, name)
    check_claims(report)
    check_prompts(report)
    check_english(report)
    check_zip(report)
    return report.finish()


if __name__ == "__main__":
    raise SystemExit(main())
