# Claims and evidence

Every sentence this project says about itself appears below with one of two statuses.

- `SUPPORTED` - the evidence column names a file in this repository, and
  `python reproduce/check.py` verifies that the file exists and, where the claim is
  numeric, that the number in the file matches the claim.
- `UNSUPPORTED` - the project does not have the evidence, so it does not make the
  claim. These rows are kept deliberately: deleting them would hide what is missing.

| ID | Claim | Status | Evidence |
|---|---|---|---|
| C1 | ARC-AGI-1 evaluation subset: 0 of 20 tasks solved, seed 0; the result file records the producing commit, timestamp and backend | SUPPORTED | eval/results.json |
| C2 | ARC-AGI-1 training subset: 2 of 20 tasks solved, seed 0; the result file records the producing commit, timestamp and backend | SUPPORTED | eval/results_training.json |
| C3 | SWE-bench Lite was not run, because neither the dataset nor a sandbox ships here | SUPPORTED | eval/results_swebench.json |
| C4 | The 20 evaluation tasks are the real public ARC-AGI-1 evaluation tasks, licence Apache-2.0, selected with seed 0 | SUPPORTED | eval/data/PROVENANCE.md, eval/data/arc_agi1_evaluation_seed0.json |
| C5 | Every measured run records the git commit, the UTC timestamp and the backend identity | SUPPORTED | eval/results.json, eval/results_training.json |
| C6 | The evaluation backend is a deterministic program-synthesis DSL, not a neural model and not trained | SUPPORTED | eval/arc_dsl.py |
| C7 | The gate never accepts a candidate that loses a previously passing check | SUPPORTED | core/gate.py, tests/test_agi_loop.py |
| C8 | A missing dataset, weight file or sandbox produces `not_run` with null metrics, never a zero | SUPPORTED | eval/harness.py, tests/test_harness.py |
| C9 | The integrated loop accepts at most what the gate accepts, and logs every step | SUPPORTED | core/agi_loop.py, tests/test_agi_loop.py |
| C10 | The project text is English-only: zero characters in the Arabic Unicode block U+0600..U+06FF | SUPPORTED | reproduce/check.py |
| C11 | The test suite that backs the claims above is present and green | SUPPORTED | tests/ |
| C12 | The system is AGI under the definition in README section 1 | UNSUPPORTED | - |
| C13 | The system generalises to unseen task families | UNSUPPORTED | - |
| C14 | The system solves SWE-bench Lite tasks | UNSUPPORTED | - |
| C15 | The dreamer proves an action safe | UNSUPPORTED | - |
| C16 | The causal memory estimates unbiased treatment effects | UNSUPPORTED | - |

## Why the unsupported rows matter

`C12` is the hypothesis the repository exists to test, and the measured result does not
support it: 0/20 on the evaluation subset. `C13` fails for the same reason and because
the DSL cannot express counting, comparison or rule composition. `C14` is absent rather
than failed: no dataset, no container, so the harness records `not_run`. `C15` is a
rule table, not a proof, and the README says so. `C16` is an observational difference in
means with a shrinkage term; it is useful and it is not causal identification.

A reviewer who wants a stronger claim should ask for a larger run, a neural backend with
published weights, or a private holdout - in that order. Each is a new measurement, not
an edit to this table.
