#!/usr/bin/env sh
# Reproduce the NAWAH-AGI measurement from a clean checkout.
# POSIX twin: reproduce/reproduce.ps1 (Windows PowerShell).
set -eu
cd "$(dirname "$0")/.."

echo "== 1/4 dependencies =="
python -m pip install -r requirements.txt

echo "== 2/4 ARC-AGI-1 evaluation, 20 tasks, seed 0 =="
python eval/harness.py --suite arc --n 20

echo "== 3/4 layer smoke test =="
python test_agi.py

echo "== 4/4 artefact and claim check =="
python reproduce/check.py
