# Reproduce the NAWAH-AGI measurement from a clean checkout.
# POSIX twin: reproduce/reproduce.sh
# Native commands report failure through $LASTEXITCODE, so the global error
# preference stays at Continue: pip writes warnings to stderr and still exits 0.
$ErrorActionPreference = "Continue"
Set-Location (Join-Path $PSScriptRoot "..")

Write-Host "== 1/4 dependencies =="
python -m pip install --disable-pip-version-check --no-input -r requirements.txt
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "== 2/4 ARC-AGI-1 evaluation, 20 tasks, seed 0 =="
python eval/harness.py --suite arc --n 20
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "== 3/4 layer smoke test =="
python test_agi.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Host "== 4/4 artefact and claim check =="
python reproduce/check.py
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
