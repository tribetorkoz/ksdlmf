# NAWAH-AGI Seven-Phase Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Execute the seven phases in `PROMPTS.md` so that every acceptance criterion is verified by a command, and no capability number is produced without a real measurement.

**Architecture:** Four layers (causal memory, dreamer, stigmergic swarm, gate) orchestrated by `core/agi_loop.py`. The evaluation harness drives that loop against the real ARC-AGI-1 dataset with a deterministic program-synthesis backend; a scripted backend can only ever produce `engineering_only` artefacts.

**Tech Stack:** Python 3.12 standard library, `pytest` for tests, `zipfile` for the release archive. No network at runtime, no API keys, CPU only.

**Spec:** `PROMPTS.md` (this plan implements it; the spec is the source of truth for acceptance).

## Execution outcome

All seven phases were executed and verified by command. The checkboxes below are the
original plan and are left as written; the authoritative record of what was built and
how it was proved is `PHASES.md`, and the claim-by-claim evidence is
`reproduce/CLAIMS.md`.

Deviations from the draft, all deliberate:

- The claims table lives at `reproduce/CLAIMS.md`, inside the phase-6 scope, not at
  `verification/CLAIMS.md`.
- Phase 5 froze two subsets - `eval/data/arc_agi1_evaluation_seed0.json` (primary,
  comparable to the 66% human figure) and `eval/data/arc_agi1_training_seed0.json`
  (secondary, explicitly not comparable) - instead of one mixed subset.
- The English-only check is `scripts/check_english.py`, which prints a count and an
  exit code, rather than a bare `grep`.
- This host has no `bash`, so `reproduce/reproduce.ps1` is the executed reproduction
  path; `reproduce/reproduce.sh` is the POSIX twin with the same commands.
- Measured outcomes: 0/20 on the ARC-AGI-1 evaluation subset, 2/20 on the training
  subset, SWE-bench Lite `not_run`, 73 tests passing.

## Global Constraints

- CPU only, 8 GB RAM target, no API keys, no network calls inside `core/` or `eval/`.
- Every changed file must be inside the phase `SCOPE`; `core/gate.py` is never modified.
- Missing values stay `None`. A run that did not happen is `not_run`, never `0`.
- `measurement_class` is `engineering_only` whenever a `ScriptedBackend` produced the output.
- No new third-party runtime dependencies. `pytest` is a dev dependency only.
- All project files are English-only (0 characters in `U+0600..U+06FF`).
- Windows is a supported host: no `signal.SIGALRM`, no POSIX-only paths.

## Review Focus

- A user passes an empty or single-pair ARC task: the harness must record `invalid_task`, not crash or score it.
- A skill's tests hang: `verify_code` must return `timeout`, not freeze the process.
- A swarm workdir contains unrelated JSON: `Swarm` must not delete files it did not create.
- A prevented relation matches the query: retrieval must inhibit it, not rank it first.
- A backend is missing weights: the harness must emit `not_run` with a reason, never estimate.

---

### Task 0: Repository baseline

**Files:** create `.gitignore`, `requirements.txt`, `core/__init__.py`, `pytest.ini`

**Interfaces:**
- Produces: importable package `core` with `__init__.py`; `pytest` discovers `tests/`.

- [ ] **Step 1:** `git init`, write `.gitignore` (`.venv/`, `__pycache__/`, `*.pyc`, `eval/.cache/`, `*.gguf`).
- [ ] **Step 2:** `requirements.txt` = `pytest>=8`.
- [ ] **Step 3:** `pytest.ini` = `testpaths = tests`, `addopts = -q`.
- [ ] **Step 4:** Verify: `python -c "import core"` exits 0.

---

### Task 1: Causal memory with intervention scoring (Phase 1)

**Files:**
- Modify: `core/causal_memory_v2.py`
- Test: `tests/test_causal.py`

**Interfaces:**
- Produces:
  - `CausalMemory(content, cause_of, caused_by, relation, timestamp, mem_id, weight, trials, successes)`
  - `CausalMemoryStore(path).add(content, cause_of="", caused_by="", relation="caused") -> tuple[bool, str]`
  - `.retrieve_causal(query, k=3, backend=None) -> list[CausalMemory]`
  - `.intervention_score(query, candidate) -> float`
  - `.intervention_effect(mem_id) -> float | None`
  - `.record_outcome(retrieved_ids, success) -> None`
  - `.update_on_feedback(mem_id, success) -> float | None`
  - `.stats() -> dict`

**Tests (must fail first):** `test_causal_retrieval`, `test_prevented_inhibition`, `test_update_weight`, `test_no_duplicate`, `test_persistence`, plus `test_effect_uses_logged_outcomes`.

- [ ] **Step 1:** Write the six tests in `tests/test_causal.py`.
- [ ] **Step 2:** Run `python -m pytest tests/test_causal.py -q`; expect failures (`trials` unknown, `intervention_effect` missing).
- [ ] **Step 3:** Implement: causal graph (`CausalEdge`), Laplace-smoothed reliability, polarity for `caused`/`enabled`/`prevented`, and `intervention_effect` = difference in mean success between retrievals that included the memory and those that did not, shrunk by `n/(n+4)`.
- [ ] **Step 4:** Persist weights/trials with an atomic rewrite; keep JSONL append for new memories.
- [ ] **Step 5:** Verify: `python -m pytest tests/test_causal.py -q` → 6 passed; `python core/causal_memory_v2.py` → prints `Phase 1 works`.
- [ ] **Step 6:** Commit.

---

### Task 2: Dreamer consequence simulator (Phase 2)

**Files:**
- Modify: `core/dreamer.py`
- Test: `tests/test_dreamer.py`

**Interfaces:**
- Produces: `Dreamer(backend=None, seed=0).dream(state, action, n=5) -> list[str]` (distinct, `<100` chars, deterministic); `.filter_safe(state, actions, n=3) -> list[str]`; `.assess(state, action, n=3) -> dict` with `failure_ratio`, `safe`, `dreams`.

**Tests:** distinct-count, length bound, determinism, unsafe rejection (2/3 failure keywords), safe retention, state-grounded consequence (`remove import` while another module imports it must mention `NameError`).

- [ ] **Step 1:** Write `tests/test_dreamer.py`.
- [ ] **Step 2:** Run it; expect failure (templated strings, no state grounding).
- [ ] **Step 3:** Implement a rule table of action → effects (failure flag) plus state facts (symbol defined, symbol referenced elsewhere), deduplicated and ordered by (rule priority, seed permutation).
- [ ] **Step 4:** Verify: `python -m pytest tests/test_dreamer.py -q` → pass; `python core/dreamer.py` → prints distinct dreams and a filtered unsafe action.
- [ ] **Step 5:** Commit.

---

### Task 3: Stigmergic swarm (Phase 3)

**Files:**
- Modify: `core/swarm.py`
- Test: `tests/test_swarm.py`

**Interfaces:**
- Produces: `Swarm(workdir="swarm_board", run=None)`; `.leave_trace(agent, key, data) -> Path` writing `workdir/<key>.json`; `.read_traces(key_prefix="") -> list[dict]` sorted by `(tick, agent, key)`; `.run_team(task, agents) -> list[dict]`; `.clear() -> int`.

**Tests:** trace file exists at `workdir/key.json`; sorted order; critic sees explorer trace; `stop=True` halts; foreign JSON preserved; keys sanitized (no path traversal).

- [ ] **Step 1:** Write `tests/test_swarm.py`.
- [ ] **Step 2:** Run; expect failure (init deletes foreign files; keys with `/` escape; no tick).
- [ ] **Step 3:** Implement ownership manifest `_manifest.json`, atomic writes, tick counter, deterministic key sanitisation.
- [ ] **Step 4:** Verify: `python -m pytest tests/test_swarm.py -q` → pass; `python core/swarm.py` → 3 traces, critic sees explorer.
- [ ] **Step 5:** Commit.

---

### Task 4: Portable code verification (shared by Phases 4–5)

**Files:**
- Modify: `core/skills.py`
- Test: `tests/test_verify_code.py`

**Interfaces:**
- Produces: `verify_code(code, tests, seconds=5) -> {"ok": bool, "reason": str, "passed": int, "total": int}`; `verify_tests(code, tests, seconds=5) -> dict[str, bool]` (per-test ids `t0..tn`).

**Tests:** passing code; failing assertion; hang → `timeout`; per-test map shape. Must pass on Windows (`signal.SIGALRM` absent).

- [ ] **Step 1:** Write `tests/test_verify_code.py`, including an `while True: pass` test.
- [ ] **Step 2:** Run; expect `AttributeError: module 'signal' has no attribute 'SIGALRM'`.
- [ ] **Step 3:** Implement subprocess isolation with `timeout=seconds`; child prints a single JSON line; parent parses; `verify_tests` reuses the child in per-test mode.
- [ ] **Step 4:** Verify: `python -m pytest tests/test_verify_code.py -q` → pass.
- [ ] **Step 5:** Commit.

---

### Task 5: Integrated loop (Phase 4)

**Files:**
- Create: `core/agi_loop.py`
- Modify: `core/transfer.py` (import shim only)
- Test: `tests/test_agi_loop.py`

**Interfaces:**
- Consumes: `gate.acceptable`, `CausalMemoryStore.retrieve_causal`, `Dreamer.filter_safe`, `Swarm.run_team`, `verify_tests`, `ResourceLog`.
- Produces: `AGILoop(task, backend, workdir, ...).run() -> {"best_candidate": str|None, "audit_log": list[dict], "accepted_count": int, "measurement_class": str}`; `Task(task_id, family, description, tests)`.

**Tests:** demo yields 1 accepted of 3 candidates; gate is consulted (a candidate that breaks a passing test is never accepted); `resources.jsonl` receives one row per candidate; scripted run is `engineering_only`.

- [ ] **Step 1:** Write `tests/test_agi_loop.py`.
- [ ] **Step 2:** Run; expect `ModuleNotFoundError: core.agi_loop`.
- [ ] **Step 3:** Implement the six-step pipeline; log every step; never bypass `acceptable`.
- [ ] **Step 4:** Verify: `python -m pytest tests/test_agi_loop.py -q` → pass; `python core/agi_loop.py` → `task=1 candidates=3 accepted=1`.
- [ ] **Step 5:** Commit.

---

### Task 6: Real ARC-AGI-1 data (Phase 5, data half)

**Files:**
- Create: `eval/__init__.py`, `eval/arc_data.py`, `eval/data/arc_agi1_subset.json`, `eval/data/PROVENANCE.md`
- Script: `eval/fetch_arc.py` (one-time download, checksum-pinned)

**Interfaces:**
- Produces: `load_arc_subset(path) -> list[ArcTask]`; `ArcTask(task_id, train, test)`; `verify_arc_dataset(subset) -> dict`; `sha256_file(path)`.

- [ ] **Step 1:** Write `eval/fetch_arc.py` that downloads `data/evaluation/*.json` from `fchollet/ARC`, selects `n` tasks by seeded sample of sorted ids, and writes the subset with per-file SHA256, source URL, licence note.
- [ ] **Step 2:** Run `python eval/fetch_arc.py --n 20 --seed 0`; record the manifest.
- [ ] **Step 3:** Verify: `python -c "from eval.arc_data import load_arc_subset; print(len(load_arc_subset('eval/data/arc_agi1_subset.json')))"` → 20.
- [ ] **Step 4:** Commit dataset + provenance (real files, real hashes, no invented tasks).

---

### Task 7: Deterministic DSL solver backend (Phase 5, solver half)

**Files:**
- Create: `eval/arc_dsl.py`
- Test: `tests/test_arc_dsl.py`

**Interfaces:**
- Produces: `ArcDSLBackend(seed=0)` with `.is_real = True`, `.identity() -> dict`, `.complete(prompt, context=None) -> {"code": str|None, "candidates": [...], "tokens_in": None, "tokens_out": None}`; `programs_for(train_pairs) -> list[Program]`; `Program(name, source, complexity)`.

**Tests:** geometric family solves a rotation task; colour-map family solves a recolour task; identity is not accepted when train pairs disagree; test pair is never used to choose a program; output is a `def solve(g)` string that executes.

- [ ] **Step 1:** Write `tests/test_arc_dsl.py` with two hand-specified toy tasks (not presented as ARC).
- [ ] **Step 2:** Run; expect failure.
- [ ] **Step 3:** Implement families: identity, dihedral, colour map, constant output, tile, scale, crop-to-content, symmetry repair, 3×3-neighbourhood rule; rank by complexity then name; emit source.
- [ ] **Step 4:** Verify: `python -m pytest tests/test_arc_dsl.py -q` → pass.
- [ ] **Step 5:** Commit.

---

### Task 8: Evaluation harness (Phase 5)

**Files:**
- Create: `eval/harness.py`, `eval/swebench.py`
- Test: `tests/test_harness.py`

**Interfaces:**
- Produces: `run_arc(n=20, seed=0, backend=None) -> dict`; `run_swebench(path=None) -> dict`; CLI `--suite arc|swebench|all --n --seed --backend --out`.

**Tests:** deterministic across two runs (same ids, same successes); `not_run` when data absent; results contain `git`, `timestamp`, `backend`, `human_baseline`; no metric when `status != measured`.

- [ ] **Step 1:** Write `tests/test_harness.py` (temp dirs only).
- [ ] **Step 2:** Run; expect failure.
- [ ] **Step 3:** Implement: ARC tasks → `AGILoop` gate over train pairs, held-out test pair scored once; `calls` counted; report `X/20 (Y% vs human 66%)`.
- [ ] **Step 4:** Run `python eval/harness.py --suite arc --n 20`; write `eval/results.json` and `eval/RESULTS.md` from the real run.
- [ ] **Step 5:** Verify determinism: run twice, compare task id → success maps.
- [ ] **Step 6:** Commit.

---

### Task 9: Verification package (Phase 6)

**Files:**
- Create: `README.md` (rewrite), `reproduce/reproduce.sh`, `reproduce/reproduce.ps1`, `reproduce/check.py`, `verification/CLAIMS.md`
- Test: `tests/test_reproduce.py`

**Interfaces:**
- Produces: `reproduce/check.py` that verifies requires artefacts, hashes and claim/evidence pairing.

- [ ] **Step 1:** Write the definition sentence, protocol, three commands, hardware statement, and the explicit list of what is *not* claimed.
- [ ] **Step 2:** Write `reproduce.sh` (`pip install -r requirements.txt && python eval/harness.py --suite arc --n 20 && python test_agi.py`) and PowerShell twin.
- [ ] **Step 3:** `verification/CLAIMS.md`: every claim → evidence file or `UNSUPPORTED`.
- [ ] **Step 4:** Verify: `python reproduce/check.py` → 0 errors; `bash reproduce/reproduce.sh` on a POSIX shell if available, else `reproduce.ps1`.
- [ ] **Step 5:** Commit.

---

### Task 10: English-only release archive (Phase 7)

**Files:**
- Create: `scripts/make_release.py`, `scripts/check_english.py`

**Tests:** Arabic scan returns 0 matches; zip contains `PROMPTS.md`, `core/`, `eval/`, `tests/`, `README.md`; size `< 5 MB`.

- [ ] **Step 1:** Write `scripts/check_english.py` (scans `U+0600..U+06FF`).
- [ ] **Step 2:** Write `scripts/make_release.py` (excludes caches, `.git`, venv; asserts size).
- [ ] **Step 3:** Verify: `python scripts/check_english.py` → `0 matches`; `python scripts/make_release.py` → `AGI_PROJECT_EN.zip`.
- [ ] **Step 4:** Verify: `python test_agi.py` passes; full `python -m pytest -q` green.
- [ ] **Step 5:** Tag the release commit; report changed files, commands, results.

---

## Self-Review

- **Spec coverage:** Phases 1–7 each map to Tasks 1–10; PROMPTS.md acceptance items are reproduced verbatim in each task's tests or verify steps.
- **Type consistency:** `verify_tests` (per-test ids) is used by Task 5 and Task 8; `Program.source` is consumed by `ArcDSLBackend.complete`; `Task.tests` remains a list of Python statements.
- **Review Focus:** each of the five lines has an owning test (Task 4 hang, Task 3 foreign files, Task 1 prevented, Task 8 `not_run`, Task 6 `invalid_task`).
- **Proportion:** no task carries a full function body; signatures and tests carry the decisions.
