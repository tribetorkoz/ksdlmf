"""Phase 4 - the integrated control loop.

    goal -> swarm (plan) -> dreamer (filter) -> causal memory (enrich)
         -> backend (propose) -> verifier (measure) -> gate (accept)

Three properties are non-negotiable and are visible in the return value:

1.  The gate is the only way a candidate becomes the best candidate.  The loop
    calls ``gate.acceptable`` and copies its answer; it never overrides it.
2.  A candidate is measured, never assumed.  ``verify_tests`` runs the declared
    checks in a separate interpreter and returns one boolean per check.
3.  The run states what produced it.  A scripted backend yields
    ``measurement_class: engineering_only``; the loop will not label that as
    capability.

Step order is fixed and every step is written to ``resources.jsonl``.  No
model weights are read or written; only inference and bookkeeping.
"""
from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

try:                                    # package import: `import core.agi_loop`
    from .backends import ScriptedBackend
    from .causal_memory_v2 import CausalMemoryStore
    from .dreamer import Dreamer
    from .gate import acceptable
    from .resources import ResourceLog
    from .skills import verify_tests
    from .swarm import Swarm
except ImportError:                     # script import: `python core/agi_loop.py`
    from backends import ScriptedBackend
    from causal_memory_v2 import CausalMemoryStore
    from dreamer import Dreamer
    from gate import acceptable
    from resources import ResourceLog
    from skills import verify_tests
    from swarm import Swarm

FENCE = re.compile(r"```(?:python)?\s*(.*?)```", re.S)
STOPWORDS = {"a", "an", "and", "the", "with", "from", "that", "this", "for",
             "into", "over", "then", "than", "of", "in", "to", "is", "it", "on"}


@dataclass
class Task:
    task_id: str
    family: str
    description: str
    tests: list[str]
    metadata: dict = field(default_factory=dict)


def strip_code(text: str) -> str:
    """Take the first fenced python block, or the raw text if unfenced."""
    blocks = FENCE.findall(text or "")
    return (blocks[0] if blocks else (text or "")).strip()


class AGILoop:
    """Runs one task end to end and returns an auditable record."""

    def __init__(self, task: Task, backend, workdir=".", *, memory=None,
                 dreamer=None, swarm=None, max_candidates: int = 3,
                 seed: int = 0, log_path=None):
        if not task.tests:
            raise ValueError("task has no declared tests: nothing could be verified")
        self.task = task
        self.backend = backend
        self.workdir = Path(workdir)
        self.workdir.mkdir(parents=True, exist_ok=True)
        self.max_candidates = max(1, int(max_candidates))
        self.identity = backend.identity()
        self.log = ResourceLog(log_path or (self.workdir / "resources.jsonl"))
        self.memory = memory or CausalMemoryStore(self.workdir / "memory.jsonl")
        self.dreamer = dreamer or Dreamer(seed=seed)
        self.swarm = swarm or Swarm(self.workdir / "board", run=task.task_id)
        self.audit_log: list[dict] = []

    # ------------------------------------------------------------- helpers
    def _audit(self, step: str, **detail) -> None:
        self.audit_log.append({"step": step, "ts": round(time.time(), 6), **detail})

    def _record(self, *, phase: str, ok: bool, note: str = "", tokens_in=None,
                tokens_out=None, wall_s=None) -> None:
        self.log.record(phase=phase, task_id=self.task.task_id, family=self.task.family,
                        condition="scripted" if not self.identity.get("is_real") else "real",
                        ok=ok, tokens_in=tokens_in, tokens_out=tokens_out,
                        wall_s=wall_s, backend=self.identity, note=note)

    # ---------------------------------------------------------------- plan
    def _explorer(self, context: list[dict]) -> dict:
        task = self.task
        words = [w for w in re.findall(r"[a-z0-9_]+", task.description.lower())
                 if w not in STOPWORDS][:4]
        return {
            "hypothesis": f"{task.task_id}: {task.family} task, "
                          f"{len(self.task.tests)} declared checks, keywords {words}",
            # The second action is deliberately a tempting shortcut: it would
            # make the checks pass without solving anything.
            "actions": ["implement the function body", "delete the failing tests"],
        }

    def _critic(self, context: list[dict]) -> dict:
        explorer = next((t for t in context if t["agent"] == "explorer"), None)
        actions = explorer["data"].get("actions", []) if explorer else []
        risky = [a for a in actions if re.search(r"\b(delete|drop|remove|truncate)\b", a)]
        return {"review": f"{len(actions)} actions, {len(risky)} destructive",
                "risky": risky, "stop": False}

    def _fixer(self, context: list[dict]) -> dict:
        explorer = next((t for t in context if t["agent"] == "explorer"), None)
        critic = next((t for t in context if t["agent"] == "critic"), None)
        actions = explorer["data"].get("actions", []) if explorer else []
        risky = set(critic["data"].get("risky", []) if critic else [])
        return {"stop": True, "actions": [a for a in actions if a not in risky]}

    # --------------------------------------------------------------- prompt
    def _prompt(self, attempt: int, actions: list[str], hints, failure: str) -> str:
        lines = [f"Task {self.task.task_id} (family {self.task.family})",
                 self.task.description, "",
                 "Declared checks (the verifier runs these statements exactly):"]
        lines += [f"- {test}" for test in self.task.tests]
        lines += ["", "Approved actions:"] + [f"- {action}" for action in actions]
        if hints:
            lines += ["", "Relevant causal memory:"]
            lines += [f"- {memory.content}" for memory in hints]
        if failure:
            lines += ["", f"Previous attempt failed: {failure}"]
        lines += ["", f"attempt {attempt}: return only one fenced python block."]
        return "\n".join(lines)

    # ------------------------------------------------------------------ run
    def run(self) -> dict:
        started = time.time()
        self._record(phase="plan", ok=True, note="swarm assembled the plan")
        traces = self.swarm.run_team(self.task.description, {
            "explorer": lambda _text, context: self._explorer(context),
            "critic": lambda _text, context: self._critic(context),
            "fixer": lambda _text, context: self._fixer(context),
        })
        plan = traces[-1]["data"] if traces else {"actions": []}
        self._audit("plan", traces=[t["agent"] for t in traces],
                    actions=plan.get("actions", []))

        approved = self.dreamer.filter_safe(self.task.description,
                                            plan.get("actions", []))
        self._audit("dream", actions=approved,
                    filtered=[a for a in plan.get("actions", []) if a not in approved])
        self._record(phase="dream", ok=bool(approved), note=f"{len(approved)} actions approved")

        hints = self.memory.retrieve_causal(self.task.description, k=3)
        self._audit("memory", ids=[m.mem_id for m in hints],
                    contents=[m.content for m in hints])
        self._record(phase="memory", ok=True, note=f"{len(hints)} memories retrieved")

        baseline: dict[str, bool] = {}
        best_results: dict[str, bool] = {}
        best_candidate: str | None = None
        accepted_count = 0
        failure = ""
        candidates = 0

        for attempt in range(1, self.max_candidates + 1):
            prompt = self._prompt(attempt, approved, hints, failure)
            started_call = time.time()
            context = self.task.metadata.get("context")
            if context is not None and getattr(self.backend, "supports_context", False):
                out = self.backend.complete(prompt, context=context) or {}
            else:
                out = self.backend.complete(prompt) or {}
            wall_s = time.time() - started_call
            code = strip_code(out.get("code", ""))
            candidates += 1
            self._audit("propose", attempt=attempt, code_chars=len(code))
            self._record(phase="propose", ok=bool(code), wall_s=wall_s,
                         tokens_in=out.get("tokens_in"), tokens_out=out.get("tokens_out"),
                         note=f"attempt {attempt}")

            results = (verify_tests(code, self.task.tests) if code
                       else {f"t{index}": False for index in range(len(self.task.tests))})
            passed = sum(1 for value in results.values() if value)
            accepted = acceptable(results, best_results, baseline)
            self._audit("gate", attempt=attempt, passed=passed, total=len(results),
                        accepted=accepted)
            self._record(phase="verify", ok=passed == len(results),
                         note=f"attempt {attempt}: {passed}/{len(results)} checks")

            self.memory.record_outcome([m.mem_id for m in hints], passed == len(results))

            if accepted:
                best_candidate, best_results = code, dict(results)
                accepted_count += 1
            else:
                failed = sorted(key for key, value in results.items() if not value)
                failure = f"checks {', '.join(failed) or 'none'} did not pass"

        return {
            "task_id": self.task.task_id,
            "family": self.task.family,
            "best_candidate": best_candidate,
            "audit_log": self.audit_log,
            "accepted_count": accepted_count,
            "candidates": candidates,
            "checks": best_results,
            "measurement_class": "real" if self.identity.get("is_real") else "engineering_only",
            "backend": self.identity,
            "wall_s": round(time.time() - started, 6),
        }


BROKEN = "def add(a, b):\n    return a - b"
GOOD = "def add(a, b):\n    return a + b"
REGRESSING = "def add(a, b):\n    return a + b if a >= 0 else 0"


def demo() -> dict:
    """One task, three candidates, one accepted. Prints the acceptance line."""
    import tempfile

    task = Task(task_id="add_two", family="arithmetic",
                description="Implement add(a, b) returning the sum of two integers",
                tests=["assert add(2, 3) == 5", "assert add(-1, 1) == 0"])
    backend = ScriptedBackend({"attempt 1": BROKEN, "attempt 2": GOOD,
                               "attempt 3": REGRESSING})
    root = Path(tempfile.mkdtemp(prefix="agi_loop_demo_"))
    result = AGILoop(task, backend, root).run()

    print(f"task=1 candidates={result['candidates']} accepted={result['accepted_count']}")
    print(f"measurement_class={result['measurement_class']}")
    print(f"best_candidate:\n{result['best_candidate']}")
    assert result["accepted_count"] == 1, "the gate accepted the wrong number of candidates"
    assert result["best_candidate"].strip() == GOOD
    return {"tasks": 1, "candidates": result["candidates"],
            "accepted": result["accepted_count"]}


if __name__ == "__main__":
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    report = demo()
    print(json.dumps(report))
    print("Phase 4 works")
