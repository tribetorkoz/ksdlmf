"""Level-3 apparatus: does a skill learned on one task family transfer to another?

Protocol
--------
build     : solve tasks from family A; every solved task may be admitted to the
            skill library only if its own tests pass (no-regression gate).
freeze    : the library is frozen; nothing new is admitted during evaluation.
transfer  : solve tasks from family B (a family never used for building) twice,
            once with retrieval off and once with retrieval on, on the same tasks.
report    : paired counts per family and condition, plus token and wall-clock
            observations. A capability report is refused for a scripted backend.

This is an apparatus with falsifiable outcomes, not a demonstration of general
intelligence. With no weights on the host, only apparatus tests can run.
"""
from __future__ import annotations

import json, re, time
from dataclasses import dataclass, field, asdict
from pathlib import Path

try:                                    # package import
    from .gate import best_of
    from .resources import ResourceLog
    from .skills import Skill, SkillStore, verify_code
except ImportError:                     # script import
    from gate import best_of
    from resources import ResourceLog
    from skills import Skill, SkillStore, verify_code

FENCE = re.compile(r"```(?:python)?\s*(.*?)```", re.S)


@dataclass
class Task:
    task_id: str
    family: str
    description: str
    tests: list[str]
    public: dict[str, bool] = field(default_factory=dict)   # optional visible tests


def strip_code(text: str) -> str:
    m = FENCE.findall(text or "")
    return (m[0] if m else (text or "")).strip()


def build_prompt(task: Task, skills: list[Skill]) -> str:
    head = f"Task {task.task_id} (family {task.family})\n{task.description}\n"
    if not skills:
        return head + "\nReturn only one fenced python block defining the function."
    hints = "\n".join(f"- {s.name}{s.signature}: {s.description}" for s in skills)
    return (head + "\nExecutable skills already verified in this library:\n" + hints +
            "\n\nReuse a skill if it applies; otherwise write your own."
            "\nReturn only one fenced python block.")


def _solve(backend, task: Task, skills: list[Skill]) -> dict:
    prompt = build_prompt(task, skills)
    t0 = time.time()
    out = backend.complete(prompt)
    out.setdefault("wall_s", time.time() - t0)
    out["code"] = strip_code(out.get("code", ""))
    out["verification"] = verify_code(out["code"], task.tests) if out["code"] else \
        {"ok": False, "reason": "empty completion", "passed": 0, "total": len(task.tests)}
    return out


def run_phase(backend, tasks: list[Task], store: SkillStore, log: ResourceLog,
              *, phase: str, condition: str, admit: bool) -> list[dict]:
    results = []
    for task in tasks:
        skills = [] if condition == "retrieval_off" else store.retrieve(task.description, k=3)
        out = _solve(backend, task, skills)
        v = out["verification"]
        admitted, msg = (False, "not applicable")
        if admit and v["ok"]:
            skill = Skill(name=task.task_id.replace("/", "_"), signature="()",
                          description=task.description, code=out["code"], tests=task.tests,
                          provenance={"phase": phase, "family": task.family,
                                      "condition": condition, "backend": backend.identity()})
            admitted, msg = store.add(skill, v)
        log.record(phase=phase, task_id=task.task_id, family=task.family, condition=condition,
                   ok=v["ok"], tokens_in=out.get("tokens_in"), tokens_out=out.get("tokens_out"),
                   wall_s=out.get("wall_s"), cached=out.get("cached"),
                   backend=backend.identity(), note=msg if admit else v.get("reason", ""))
        results.append({"task": task.task_id, "family": task.family, "condition": condition,
                        "ok": v["ok"], "admitted": admitted, "reason": v["reason"],
                        "retrieved": [s.skill_id for s in skills]})
    return results


def paired(a: list[dict], b: list[dict]) -> dict:
    ka = {r["task"]: r["ok"] for r in a}
    kb = {r["task"]: r["ok"] for r in b}
    keys = sorted(set(ka) & set(kb))
    only_b = [k for k in keys if kb[k] and not ka[k]]
    only_a = [k for k in keys if ka[k] and not kb[k]]
    return {"n": len(keys), "both": sum(ka[k] and kb[k] for k in keys),
            "neither": sum(not ka[k] and not kb[k] for k in keys),
            "only_second": len(only_b), "only_first": len(only_a),
            "gain_tasks": only_b, "loss_tasks": only_a}


def capability_report(backend, summary: dict, results: dict, path: str | Path) -> Path:
    """Refuse to publish inference numbers that came from a scripted backend."""
    path = Path(path)
    ident = backend.identity()
    if not ident.get("is_real"):
        raise PermissionError("scripted backend: capability numbers are not produced. "
                              "Write an engineering-only artefact instead.")
    payload = {"measurement_class": "real", "backend": ident, "summary": summary,
               "results": results, "note": "no weight updates; fixed model"}
    path.write_text(json.dumps(payload, indent=2))
    return path


def engineering_artefact(summary: dict, results: dict, path: str | Path) -> Path:
    path = Path(path)
    payload = {"measurement_class": "engineering_only",
               "warning": "Produced with a scripted test double. NOT model performance, "
                          "NOT evidence about capability, transfer or intelligence.",
               "summary": summary, "results": results}
    path.write_text(json.dumps(payload, indent=2))
    return path


def run_study(backend, build_tasks, transfer_tasks, root: str | Path) -> dict:
    root = Path(root); root.mkdir(parents=True, exist_ok=True)
    store = SkillStore(root / "skills.json")
    log = ResourceLog(root / "resources.jsonl")
    build = run_phase(backend, build_tasks, store, log, phase="build",
                      condition="retrieval_off", admit=True)
    frozen = store.stats()
    off = run_phase(backend, transfer_tasks, store, log, phase="transfer",
                    condition="retrieval_off", admit=False)
    on = run_phase(backend, transfer_tasks, store, log, phase="transfer",
                   condition="retrieval_on", admit=False)
    summary = {"library_frozen": frozen, "paired_transfer": paired(off, on),
               "resources": log.summarise()}
    return {"summary": summary, "results": {"build": build, "off": off, "on": on}}
