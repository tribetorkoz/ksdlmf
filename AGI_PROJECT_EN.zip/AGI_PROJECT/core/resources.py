"""Resource logging: wall time, tokens when the backend reports them, provenance.

Historical NAWAH runs lacked these fields. Nothing here is ever estimated: a
missing value stays ``None`` and the summary reports how many values were
actually observed.
"""
from __future__ import annotations

import json, time, platform, sys, hashlib
from pathlib import Path
from statistics import mean


class ResourceLog:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def record(self, *, phase: str, task_id: str, family: str, condition: str,
               ok: bool, tokens_in=None, tokens_out=None, wall_s=None, cached=None,
               backend: dict | None = None, note: str = "") -> None:
        row = {"ts": time.time(), "phase": phase, "task": task_id, "family": family,
               "condition": condition, "ok": bool(ok), "tokens_in": tokens_in,
               "tokens_out": tokens_out, "wall_s": wall_s, "cached": cached,
               "backend": backend or {}, "note": note}
        with self.path.open("a") as f:
            f.write(json.dumps(row) + "\n")

    def rows(self) -> list[dict]:
        if not self.path.exists():
            return []
        return [json.loads(l) for l in self.path.read_text().splitlines() if l.strip()]

    def summarise(self) -> dict:
        rows = self.rows()
        real = [r for r in rows if (r.get("backend") or {}).get("is_real")]
        groups: dict[tuple, list[dict]] = {}
        for r in rows:
            groups.setdefault((r["phase"], r["family"], r["condition"]), []).append(r)
        per_group = []
        for (phase, family, cond), rs in sorted(groups.items()):
            wins = sum(1 for r in rs if r["ok"])
            tok = [r["tokens_in"] + r["tokens_out"] for r in rs
                   if r["tokens_in"] is not None and r["tokens_out"] is not None]
            wall = [r["wall_s"] for r in rs if r["wall_s"] is not None]
            per_group.append({
                "phase": phase, "family": family, "condition": cond,
                "n": len(rs), "solved": wins, "rate": wins / len(rs) if rs else None,
                "mean_tokens": mean(tok) if tok else None, "tokens_observed": len(tok),
                "mean_wall_s": mean(wall) if wall else None, "wall_observed": len(wall),
            })
        return {"measurement_class": "real" if real else "engineering_only",
                "rows": len(rows), "real_rows": len(real),
                "environment": {"python": sys.version.split()[0], "platform": platform.platform()},
                "groups": per_group}
