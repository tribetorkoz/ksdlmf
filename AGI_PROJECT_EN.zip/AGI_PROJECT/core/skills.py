"""Skill library for the level-3 experiment.

A skill is stored only after its own tests pass under the same no-regression
gate used by v6. Nothing here trains weights; the library is the only place
where experience accumulates.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict, field
from pathlib import Path
import json, re, math, hashlib, os, subprocess, sys

TOKEN = re.compile(r"[a-z0-9_]+")

# The child runs the candidate code and its tests in a fresh interpreter.  It
# exists because signal.SIGALRM does not exist on Windows, and because a
# candidate that segfaults should not take the parent process with it.
_MARKER = "__SKILL_RESULT__"
_CHILD = """
import json, sys
payload = json.loads(sys.stdin.read())
namespace = {"__name__": "skill_under_test"}
def emit(result):
    sys.stdout.write("__SKILL_RESULT__" + json.dumps(result) + "\\n")
try:
    exec(compile(payload["code"], "<skill>", "exec"), namespace)
except BaseException as error:
    emit({"ok": False, "reason": type(error).__name__ + ": " + str(error),
          "passed": 0, "total": len(payload["tests"]), "per_test": {}})
    raise SystemExit(0)
per_test, reason = {}, "ok"
for index, test in enumerate(payload["tests"]):
    key = "t%d" % index
    try:
        exec(compile(test, "<test:" + key + ">", "exec"), namespace)
        per_test[key] = True
    except BaseException as error:
        per_test[key] = False
        reason = type(error).__name__ + ": " + str(error)
        break
passed = sum(1 for value in per_test.values() if value)
emit({"ok": passed == len(payload["tests"]) and len(per_test) == len(payload["tests"]),
      "reason": reason if passed != len(payload["tests"]) else "ok",
      "passed": passed, "total": len(payload["tests"]), "per_test": per_test})
"""


def _run_in_child(code: str, tests: list[str], seconds: int) -> dict:
    payload = json.dumps({"code": code, "tests": list(tests)})
    try:
        proc = subprocess.run(
            [sys.executable, "-X", "utf8", "-c", _CHILD],
            input=payload, capture_output=True, text=True, encoding="utf-8",
            timeout=max(1, int(seconds)),
        )
    except subprocess.TimeoutExpired:
        return {"ok": False, "reason": "timeout", "passed": 0,
                "total": len(tests), "per_test": {}}
    for line in reversed((proc.stdout or "").splitlines()):
        if line.startswith(_MARKER):
            try:
                return json.loads(line[len(_MARKER):])
            except json.JSONDecodeError:
                break
    detail = [line for line in (proc.stderr or "").strip().splitlines() if line.strip()]
    reason = detail[-1] if detail else f"child exited {proc.returncode} without a result"
    return {"ok": False, "reason": reason, "passed": 0,
            "total": len(tests), "per_test": {}}


def verify_code(code: str, tests: list[str], seconds: int = 5) -> dict:
    """Execute `code` then each test string. Declared engineering check."""
    if not tests:
        return {"ok": False, "reason": "no tests declared", "passed": 0, "total": 0}
    result = _run_in_child(code, tests, seconds)
    return {key: result.get(key, 0) for key in ("ok", "reason", "passed", "total")}


def verify_tests(code: str, tests: list[str], seconds: int = 5) -> dict[str, bool]:
    """Per-test pass map keyed ``t0..tn``; a test that never ran counts as failed."""
    if not tests:
        return {}
    result = _run_in_child(code, tests, seconds)
    per_test = result.get("per_test") or {}
    return {f"t{index}": bool(per_test.get(f"t{index}", False))
            for index in range(len(tests))}


@dataclass
class Skill:
    name: str
    signature: str
    description: str
    code: str
    tests: list[str]
    provenance: dict = field(default_factory=dict)
    skill_id: str = ""

    def __post_init__(self):
        if not self.skill_id:
            key = (self.name + "|" + self.signature + "|" + self.description + "|" + self.code).encode()
            self.skill_id = "sk_" + hashlib.sha256(key).hexdigest()[:16]


class SkillStore:
    """Append-only JSON store with deterministic TF-IDF retrieval."""

    def __init__(self, path: str | os.PathLike):
        self.path = Path(path)
        self.skills: list[Skill] = []
        if self.path.exists():
            for d in json.loads(self.path.read_text()):
                self.skills.append(Skill(**d))

    # ---------------------------------------------------------------- writing
    def add(self, skill: Skill, verification: dict | None = None) -> tuple[bool, str]:
        """Admission rule: the skill's own tests must all pass."""
        v = verification if verification is not None else verify_code(skill.code, skill.tests)
        if not v["ok"]:
            return False, f"rejected: {v['reason']} ({v['passed']}/{v['total']})"
        if any(s.skill_id == skill.skill_id for s in self.skills):
            return False, "rejected: duplicate"
        self.skills.append(skill)
        self._flush()
        return True, "admitted"

    def _flush(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps([asdict(s) for s in self.skills], indent=2))
        tmp.replace(self.path)

    # ---------------------------------------------------------------- reading
    def _docs(self):
        return [f"{s.name} {s.signature} {s.description}" for s in self.skills]

    def retrieve(self, query: str, k: int = 3) -> list[Skill]:
        if not self.skills or k <= 0:
            return []
        docs = [TOKEN.findall(d.lower()) for d in self._docs()]
        q = TOKEN.findall(query.lower())
        vocab = sorted({t for d in docs for t in d} | set(q))
        df = {t: sum(1 for d in docs if t in d) for t in vocab}
        n = len(docs)
        idf = {t: math.log((n + 1) / (df[t] + 1)) + 1 for t in vocab}

        def vec(tokens):
            tf = {}
            for t in tokens:
                tf[t] = tf.get(t, 0) + 1
            v = {t: (1 + math.log(c)) * idf[t] for t, c in tf.items() if t in idf}
            norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
            return {t: x / norm for t, x in v.items()}

        qv = vec(q)
        scored = []
        for s, d in zip(self.skills, docs):
            dv = vec(d)
            score = sum(w * dv.get(t, 0.0) for t, w in qv.items())
            if score > 0:
                scored.append((score, s.skill_id, s))
        scored.sort(key=lambda x: (-x[0], x[1]))
        return [s for _, _, s in scored[:k]]

    def stats(self) -> dict:
        return {"skills": len(self.skills),
                "ids": [s.skill_id for s in self.skills],
                "sha256": hashlib.sha256(self.path.read_bytes()).hexdigest() if self.path.exists() else None}
