"""Phase 1 - causal memory that selects by intervention, not by keyword overlap.

Three ideas, in order of importance:

1.  A memory may exist only if it states a cause, an effect, or both.  Text
    without a causal link is not stored, so the store cannot degrade into a
    similarity index.
2.  Retrieval scores a candidate by the causal path between the question and
    the memory: the question usually names either the effect (``cause_of``) or
    the cause (``caused_by``).  Keyword overlap is a weak last resort and can
    never outrank a causal match.
3.  Once the system has acted, ``record_outcome`` logs which memories were
    retrieved and whether the attempt succeeded.  ``intervention_effect`` then
    estimates E[success | memory retrieved] - E[success | memory absent] from
    that log, and retrieval uses the estimate to re-rank.  This is an
    observational estimator: it assumes the retrieval policy did not
    systematically prefer memories for easier tasks.  The assumption is
    stated, not hidden, and the estimate is shrunk toward zero while the
    evidence is thin.

Relations: ``caused`` (polarity +1), ``enabled`` (+0.8), ``prevented`` (-1).
A prevented memory can only inhibit: it is scored negative and therefore
never returned as an explanation.

No network, no API keys, CPU only.  Deterministic for a fixed store.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import time
from dataclasses import dataclass, field
from pathlib import Path

RELATIONS = {"caused": 1.0, "enabled": 0.8, "prevented": -1.0}

STOPWORDS = {
    "a", "an", "and", "are", "as", "at", "be", "because", "but", "by", "for",
    "from", "has", "have", "i", "if", "in", "is", "it", "its", "my", "not",
    "of", "on", "or", "that", "the", "their", "then", "there", "these",
    "this", "to", "was", "were", "when", "which", "with",
}

TOKEN = re.compile(r"[a-z0-9]+")


def tokens(text: str) -> list[str]:
    """Lower-case word tokens with a minimal plural fold (``errors`` -> ``error``)."""
    out = []
    for raw in TOKEN.findall((text or "").lower()):
        if len(raw) > 3 and raw.endswith("s") and not raw.endswith("ss"):
            raw = raw[:-1]
        out.append(raw)
    return out


def _phrase_match(needle: str, haystack: str) -> float:
    """1.0 for a contiguous phrase, 0.5-0.8 for full token coverage, else 0."""
    want = tokens(needle)
    have = tokens(haystack)
    if not want or not have:
        return 0.0
    span = len(want)
    for start in range(len(have) - span + 1):
        if have[start:start + span] == want:
            return 1.0
    covered = sum(1 for token in want if token in have) / len(want)
    if covered == 1.0:
        return 0.8
    return 0.5 * covered if covered >= 0.5 else 0.0


def _content_overlap(text_a: str, text_b: str) -> float:
    a = {t for t in tokens(text_a) if t not in STOPWORDS}
    b = {t for t in tokens(text_b) if t not in STOPWORDS}
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


@dataclass
class CausalEdge:
    from_id: str
    to_id: str
    relation: str
    weight: float = 1.0


@dataclass
class CausalMemory:
    content: str
    cause_of: str = ""
    caused_by: str = ""
    relation: str = "caused"
    timestamp: float = field(default_factory=time.time)
    mem_id: str = ""
    weight: float = 1.0
    trials: int = 0
    successes: int = 0

    def __post_init__(self):
        if self.relation not in RELATIONS:
            raise ValueError(f"unknown relation: {self.relation!r}")
        if not self.mem_id:
            key = f"{self.content}|{self.cause_of}|{self.caused_by}".encode()
            self.mem_id = "cm_" + hashlib.sha256(key).hexdigest()[:12]

    @property
    def polarity(self) -> float:
        return RELATIONS[self.relation]

    def to_record(self) -> dict:
        return {"record": "memory", **{k: getattr(self, k)
                                       for k in CausalMemory.__dataclass_fields__}}


class CausalMemoryStore:
    """Append-once, rewrite-on-update causal store with an intervention log."""

    def __init__(self, path: str | Path = "agi_memory.jsonl"):
        self.path = Path(path)
        self.mems: list[CausalMemory] = []
        self.edges: list[CausalEdge] = []
        self.outcomes: list[dict] = []
        self._inhibited = 0
        if self.path.exists():
            self._load()

    # ------------------------------------------------------------------ io
    def _load(self) -> None:
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if row.get("record") == "outcome":
                self.outcomes.append(row)
                continue
            if "content" not in row:
                continue
            try:
                memory = CausalMemory(**{k: v for k, v in row.items()
                                         if k in CausalMemory.__dataclass_fields__})
            except (TypeError, ValueError):
                continue
            self._merge(memory)
        self._inhibited = sum(1 for m in self.mems if m.polarity < 0)

    def _merge(self, memory: CausalMemory) -> None:
        """Last record wins, so a replayed log reproduces the final state."""
        for index, existing in enumerate(self.mems):
            if existing.mem_id == memory.mem_id:
                self.mems[index] = memory
                return
        self.mems.append(memory)

    def _flush(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        lines = [json.dumps(m.to_record(), ensure_ascii=False) for m in self.mems]
        lines += [json.dumps(row, ensure_ascii=False) for row in self.outcomes]
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
        tmp.replace(self.path)

    # --------------------------------------------------------------- write
    def add(self, content: str, cause_of: str = "", caused_by: str = "",
            relation: str = "caused") -> tuple[bool, str]:
        if relation not in RELATIONS:
            raise ValueError(f"unknown relation: {relation!r}")
        if not content or len(content.strip()) < 5:
            return False, "too short"
        if not cause_of and not caused_by:
            return False, "no causal link: state a cause or an effect"
        memory = CausalMemory(content=content, cause_of=cause_of,
                              caused_by=caused_by, relation=relation)
        if any(m.mem_id == memory.mem_id for m in self.mems):
            return False, "duplicate"
        self.mems.append(memory)
        self._link(memory)
        self._flush()
        if memory.polarity < 0:
            self._inhibited += 1
        return True, memory.mem_id

    def _link(self, memory: CausalMemory) -> None:
        """Link causes to effects when one memory's text names the other's cause."""
        if not memory.caused_by:
            return
        for other in self.mems:
            if other.mem_id == memory.mem_id:
                continue
            if other.cause_of and _phrase_match(other.cause_of, memory.caused_by) >= 0.8:
                self.edges.append(CausalEdge(other.mem_id, memory.mem_id,
                                             memory.relation, memory.weight))

    def record_outcome(self, retrieved_ids, success: bool) -> None:
        """Log the retrieval decision and its outcome for effect estimation."""
        self.outcomes.append({"record": "outcome",
                              "retrieved": list(retrieved_ids),
                              "ok": bool(success),
                              "ts": time.time()})
        self._flush()

    def update_on_feedback(self, mem_id: str, success: bool) -> float | None:
        """Credit assignment for one memory (Hebbian weight, bounded 0.1-2.0)."""
        for memory in self.mems:
            if memory.mem_id == mem_id:
                memory.trials += 1
                memory.successes += int(bool(success))
                memory.weight = (min(2.0, memory.weight + 0.2) if success
                                 else max(0.1, memory.weight - 0.3))
                self._flush()
                return memory.weight
        return None

    # ---------------------------------------------------------------- read
    def intervention_effect(self, mem_id: str) -> float | None:
        """Observed success difference with and without this memory, shrunk."""
        with_mem = [row for row in self.outcomes if mem_id in row.get("retrieved", [])]
        without = [row for row in self.outcomes if mem_id not in row.get("retrieved", [])]
        if not with_mem or not without:
            return None
        rate_with = sum(1 for row in with_mem if row.get("ok")) / len(with_mem)
        rate_without = sum(1 for row in without if row.get("ok")) / len(without)
        shrink = len(with_mem) / (len(with_mem) + 4)
        return (rate_with - rate_without) * shrink

    def _reliability(self, memory: CausalMemory) -> float:
        """Laplace-smoothed success rate in [0, 1], centred at 1.0 multiplier."""
        return 0.5 + (memory.successes + 1) / (memory.trials + 2)

    def intervention_score(self, query: str, candidate: CausalMemory) -> float:
        """Score by causal effect on the question, not by shared words.

        affinity  : 3.0 if the question names the effect, 2.0 if it names the cause
        polarity  : relations that prevented the effect score below zero
        reliability: observed success rate of this memory
        effect    : logged difference in success with/without the memory
        """
        effect_match = _phrase_match(candidate.cause_of, query)
        cause_match = _phrase_match(candidate.caused_by, query)
        affinity = 3.0 * effect_match + 2.0 * cause_match
        if affinity == 0.0:
            affinity = 0.5 * _content_overlap(candidate.content, query)
        if affinity == 0.0:
            return 0.0

        effect = self.intervention_effect(candidate.mem_id)
        effect_multiplier = 1.0 if effect is None else max(0.5, min(1.5, 1.0 + 0.5 * effect))

        score = (affinity * candidate.polarity * self._reliability(candidate)
                 * max(0.1, min(2.0, candidate.weight)) * effect_multiplier)
        return score

    def retrieve_causal(self, query: str, k: int = 3, backend=None) -> list[CausalMemory]:
        """Return the k memories with a positive causal intervention score.

        ``backend`` is accepted for API compatibility and is deliberately not
        used: a language model's yes/no is not a causal effect estimate.
        """
        scored = [(self.intervention_score(query, memory), memory) for memory in self.mems]
        scored.sort(key=lambda pair: (-pair[0], -pair[1].weight, pair[1].mem_id))
        return [memory for score, memory in scored[:max(0, k)] if score > 0.5]

    def stats(self) -> dict:
        payload = self.path.read_bytes() if self.path.exists() else b""
        return {
            "memories": len(self.mems),
            "edges": len(self.edges),
            "outcome_rows": len(self.outcomes),
            "inhibited": self._inhibited,
            "relations": {relation: sum(1 for m in self.mems if m.relation == relation)
                          for relation in sorted(RELATIONS)},
            "sha256": hashlib.sha256(payload).hexdigest() if payload else None,
        }


def _demo() -> None:
    import tempfile

    path = Path(tempfile.gettempdir()) / "test_causal_v2.jsonl"
    path.unlink(missing_ok=True)
    store = CausalMemoryStore(str(path))
    store.add("Forgetting import math causes NameError",
              cause_of="NameError", caused_by="forgetting import math")
    store.add("Infinite loop without break causes hang",
              cause_of="hang", caused_by="loop")
    store.add("Random info about weather", cause_of="rain", caused_by="cloud")

    query = "I have NameError in code"
    found = store.retrieve_causal(query, k=2)
    print(f"Query: {query}")
    print(f"Causal retrieval: {[m.content for m in found]}")
    assert found and "import math" in found[0].content, "causal retrieval failed"
    assert all("weather" not in m.content for m in found), "keyword memory leaked in"

    ok, prevented_id = store.add("A try/except prevented the NameError",
                                 cause_of="NameError", caused_by="try/except",
                                 relation="prevented")
    assert ok
    prevented = next(m for m in store.mems if m.mem_id == prevented_id)
    assert store.intervention_score(query, prevented) < 0, "prevention not inhibited"
    print("Prevented relation inhibited:", round(store.intervention_score(query, prevented), 3))
    print("Phase 1 works")


if __name__ == "__main__":
    _demo()
