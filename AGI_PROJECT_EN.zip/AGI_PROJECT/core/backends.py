"""Model backends.

Two rules are enforced here on purpose:

1.  A scripted backend can never produce capability numbers.  It exists only to
    test the apparatus, and any output it triggers is written to a file whose
    name and payload say ``engineering_only``.
2.  The real backend refuses to run if the weights file is absent.  No result
    is estimated, imputed or pretended.
"""
from __future__ import annotations

import hashlib, os, platform, sys, time
from pathlib import Path


class BackendError(RuntimeError):
    pass


class ScriptedBackend:
    """Deterministic responses for apparatus tests. Not a language model."""
    is_real = False
    label = "scripted"

    def __init__(self, responses: dict[str, str]):
        self.responses = dict(responses)
        self.calls = 0

    def identity(self) -> dict:
        return {"label": self.label, "is_real": False,
                "weights_sha256": None, "note": "engineering test double, not inference"}

    def complete(self, prompt: str) -> dict:
        self.calls += 1
        for key, code in self.responses.items():
            if key in prompt:
                return {"code": code, "tokens_in": len(prompt.split()),
                        "tokens_out": len(code.split()), "cached": False}
        return {"code": "", "tokens_in": len(prompt.split()), "tokens_out": 0, "cached": False}


class LlamaCppBackend:
    """Fixed local model, temperature 0, no weight updates."""
    is_real = True
    label = "llama_cpp"

    def __init__(self, model_path: str | os.PathLike, max_tokens: int = 512,
                 context: int = 2048, threads: int = 2):
        self.model_path = Path(model_path)
        if not self.model_path.exists():
            raise BackendError(
                f"weights not found: {self.model_path}. This apparatus will not fabricate a run.")
        try:
            from llama_cpp import Llama  # noqa: F401
        except ImportError as e:                    # pragma: no cover - optional dep
            raise BackendError("llama-cpp-python is not installed in this environment") from e
        from llama_cpp import Llama
        self.max_tokens, self.calls = max_tokens, 0
        self._llm = Llama(model_path=str(self.model_path), n_ctx=context, n_threads=threads,
                          temperature=0.0, top_p=1.0, verbose=False)
        self._sha = hashlib.sha256(self.model_path.read_bytes()).hexdigest()

    def identity(self) -> dict:
        return {"label": self.label, "is_real": True, "weights_sha256": self._sha,
                "model_file": self.model_path.name, "max_tokens": self.max_tokens,
                "python": sys.version.split()[0], "platform": platform.platform()}

    def complete(self, prompt: str) -> dict:        # pragma: no cover - needs weights
        t0 = time.time()
        out = self._llm(prompt, max_tokens=self.max_tokens, temperature=0.0, top_p=1.0)
        self.calls += 1
        text = out["choices"][0]["text"]
        usage = out.get("usage", {})
        return {"code": text, "tokens_in": usage.get("prompt_tokens"),
                "tokens_out": usage.get("completion_tokens"),
                "wall_s": time.time() - t0, "cached": False}
