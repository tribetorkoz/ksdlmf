"""Phase 3 - stigmergic coordination: agents talk through files, never chat.

The environment is the only channel.  An agent leaves one JSON trace per step;
every later agent reads every trace written before it.  Nothing is passed in
memory, so a run can be inspected, replayed and audited after the fact.

Two safety rules, learned the hard way:

* A workdir may contain files the swarm did not create.  Ownership is recorded
  in ``_manifest.json`` and only those files are recycled on start.
* A key is user input.  ``../../evil`` must land inside the workdir, never
  above it.

No network, no threads.  Writes are atomic (temp file then replace).
"""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path

MANIFEST = "_manifest.json"
KEY_SAFE = re.compile(r"[^A-Za-z0-9_.-]+")


def safe_key(key: str) -> str:
    """Reduce a free-form key to a single filename component."""
    cleaned = KEY_SAFE.sub("_", str(key)).strip("._")
    return cleaned[:80] or "trace"


class Swarm:
    """A blackboard on disk: traces in, traces out, no messages."""

    def __init__(self, workdir: str | os.PathLike = "swarm_board", run: str | None = None):
        self.board = Path(workdir)
        self.board.mkdir(parents=True, exist_ok=True)
        self.run = run or "run"
        self.tick = 0
        self._files: set[str] = set()
        self._recycle_owned()

    # ------------------------------------------------------------ ownership
    def _manifest_path(self) -> Path:
        return self.board / MANIFEST

    def _owned(self) -> list[str]:
        path = self._manifest_path()
        if not path.exists():
            return []
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return []
        return [name for name in payload.get("files", []) if isinstance(name, str)]

    def _write_manifest(self) -> None:
        names = sorted(name for name in self._files
                       if (self.board / name).is_file())
        self._files = set(names)
        tmp = self._manifest_path().with_suffix(".tmp")
        tmp.write_text(json.dumps({"files": names}), encoding="utf-8")
        tmp.replace(self._manifest_path())

    def _recycle_owned(self) -> None:
        for name in self._owned():
            if Path(name).name != name:          # never trust a manifest that escapes
                continue
            target = self.board / name
            if target.is_file():
                target.unlink()
        self._files = set()
        self._write_manifest()

    # ---------------------------------------------------------------- write
    def leave_trace(self, agent: str, key: str, data: dict) -> Path:
        """Write one trace to ``workdir/<key>.json`` and return its path."""
        if not isinstance(data, dict):
            raise TypeError("trace data must be a dict")
        name = safe_key(key)
        payload = {
            "run": self.run,
            "tick": self.tick,
            "agent": str(agent),
            "key": name,
            "time": time.time(),
            "data": data,
        }
        path = self.board / f"{name}.json"
        tmp = path.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)
        self._files.add(path.name)
        self.tick += 1
        self._write_manifest()
        return path

    # ----------------------------------------------------------------- read
    def read_traces(self, key_prefix: str = "") -> list[dict]:
        """Every trace, sorted by (tick, agent, key).  Foreign JSON is skipped."""
        traces = []
        for name in sorted(self._files):
            path = self.board / name
            if not path.is_file():
                continue
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
            if not isinstance(payload, dict) or "agent" not in payload:
                continue
            if key_prefix and not str(payload.get("key", "")).startswith(key_prefix):
                continue
            traces.append(payload)
        traces.sort(key=lambda t: (t.get("tick", 0), t.get("agent", ""), t.get("key", "")))
        return traces

    def clear(self) -> int:
        """Remove the traces this swarm owns; return how many were removed."""
        removed = 0
        for name in sorted(self._files):
            target = self.board / name
            if target.is_file():
                target.unlink()
                removed += 1
        self._files = set()
        self.tick = 0
        self._write_manifest()
        return removed

    # ----------------------------------------------------------------- team
    def run_team(self, task: str, agents: dict) -> list[dict]:
        """Run agents in order; each sees every trace left before it.

        An agent returns a dict.  ``stop: True`` ends the run immediately.
        """
        prefix = safe_key(task[:20] or "task")
        for name, func in agents.items():
            context = self.read_traces()
            result = func(task, context)
            if not isinstance(result, dict):
                raise TypeError(f"agent {name!r} returned {type(result).__name__}, expected dict")
            self.leave_trace(name, f"{prefix}_{name}", result)
            if result.get("stop"):
                break
        return self.read_traces(f"{prefix}_")


def _demo() -> None:
    import tempfile

    board = Path(tempfile.gettempdir()) / "swarm_demo_board"
    swarm = Swarm(str(board), run="demo")
    seen = {}

    def explorer(task, context):
        seen["explorer"] = len(context)
        return {"idea": "try method A"}

    def critic(task, context):
        seen["critic"] = [t["agent"] for t in context]
        return {"critique": "A has a risk", "stop": False}

    def fixer(task, context):
        seen["fixer"] = [t["agent"] for t in context]
        return {"fix": "use B instead of A", "stop": True}

    traces = swarm.run_team("fix the function", {"explorer": explorer,
                                                 "critic": critic, "fixer": fixer})
    print("Traces:", [t["agent"] for t in traces])
    print("Critic saw:", seen["critic"])
    assert len(traces) == 3
    assert seen["critic"] == ["explorer"]
    assert seen["fixer"] == ["explorer", "critic"]
    print("Phase 3 works")


if __name__ == "__main__":
    _demo()
