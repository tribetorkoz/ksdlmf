"""Phase 2 - a small consequence simulator, not a random sentence generator.

The dreamer answers one question: *if this action is taken in this state, what
follows?*  It answers from three sources, in priority order:

1.  State facts.  The state text is split into segments; an action that removes
    or renames a symbol is checked against the segments that still reference it.
    Those references are the most specific prediction available.
2.  An action rule table.  Each verb family carries the consequences observed
    for it, each tagged as a failure or not.
3.  An explicit "no rule matched" record.  Unmodelled actions are reported as
    unmodelled, never as safe.  ``filter_safe`` keeps them because the
    acceptance rule is keyword-based, and the assessment says ``confidence:
    low`` so a caller can refuse to rely on it.

This is a qualitative model.  It predicts consequences, it does not prove
safety, and it cannot see a consequence that is absent from its rule table.
No training, no network, no GPU.
"""
from __future__ import annotations

import random
import re
from dataclasses import dataclass, field

FAILURE_PATTERN = re.compile(
    r"\b(error|errors|fail|fails|failed|failing|break|breaks|broke|broken|"
    r"crash|crashes|crashed|exception|exceptions|corrupt|corrupted|"
    r"lost|hang|hangs|hung|data loss)\b")

MAX_DREAM_CHARS = 99

TOKEN = re.compile(r"[a-z0-9_]+")
FILE = re.compile(r"[\w./-]+\.py")
VERBS = {"delete", "remove", "drop", "truncate", "wipe", "install", "upgrade",
         "rename", "move", "refactor", "overwrite", "write", "save", "run",
         "execute", "deploy", "add", "create", "test", "lint", "check", "read",
         "import", "the", "a", "an", "of", "in", "to", "and", "it", "this"}


def _tokens(text: str) -> list[str]:
    out = []
    for raw in TOKEN.findall((text or "").lower()):
        if len(raw) > 3 and raw.endswith("s") and not raw.endswith("ss"):
            raw = raw[:-1]
        out.append(raw)
    return out


def _clip(text: str) -> str:
    text = " ".join(text.split())
    return text if len(text) < MAX_DREAM_CHARS else text[:MAX_DREAM_CHARS - 3].rstrip() + "..."


def _is_failure(text: str) -> bool:
    """Word-boundary scan: ``unchanged`` must not match ``hang``."""
    return FAILURE_PATTERN.search(text.lower()) is not None


@dataclass
class Consequence:
    text: str
    failure: bool
    source: str          # state | rule | unmodelled
    priority: int = 0


@dataclass
class Rule:
    name: str
    pattern: str
    consequences: list[tuple[str, bool]] = field(default_factory=list)

    def matches(self, action: str) -> bool:
        return re.search(self.pattern, action.lower()) is not None


RULES: list[Rule] = [
    Rule("destructive", r"\b(delete|remove|drop|truncate|wipe|rm)\b", [
        ("Callers of the removed object raise an error on the next run", True),
        ("Tests that reference it fail until every call site is updated", True),
        ("Anything that referenced it breaks with no fallback path", True),
        ("After the error, the run stops early and the report is incomplete", True),
    ]),
    Rule("non_terminating", r"\b(infinite loop|while true|no break|loop without)\b", [
        ("The loop never terminates: the run hangs and must be killed", True),
        ("A watchdog may fail the job once the timeout expires", True),
        ("CPU stays pinned, so other work breaks its deadline", True),
    ]),
    Rule("dependency", r"\b(install|pip|upgrade|dependency|requirement)\b", [
        ("The install fails offline: no package index is reachable", True),
        ("A version conflict breaks the existing import path", True),
        ("The wheel is missing for this platform, so the build errors", True),
    ]),
    Rule("rename", r"\b(rename|move|refactor)\b", [
        ("Import sites keep the old name and raise an ImportError", True),
        ("The suite fails until every call site is updated", True),
        ("External callers break silently because their contract is unchecked", True),
    ]),
    Rule("edit", r"\b(edit|implement|draft|patch)\b", [
        ("The edit stays local to the working copy; the repository is unchanged", False),
        ("Review can reject the draft before it is applied", False),
        ("No state changes until the result is verified", False),
    ]),
    # A read-only verb outranks "write" and "run": "write a unit test" and
    # "run the linter" change no state.  The cost of the shortcut is that
    # "overwrite the test file" is also treated as read-only.
    Rule("read_only", r"\b(test\w*|lint\w*|check\w*|read\w*|inspect\w*|measure\w*)\b", [
        ("Read-only: no state changes; the run is repeatable", False),
        ("The check reports defects before they ship", False),
        ("Output is advisory; the system state is unchanged", False),
    ]),
    Rule("overwrite", r"\b(overwrite|save|replace)\b", [
        ("Writing without a backup may corrupt the previous version", True),
        ("A partial write leaves the file unreadable for later reads", True),
        ("Nothing fails if the target is new, so risk hides as data loss", True),
    ]),
    Rule("execute", r"\b(run|execute|deploy)\b", [
        ("The command may fail if its inputs changed since the last run", True),
        ("A crash leaves partial output behind, so reruns need care", True),
        ("Exit code zero does not prove the output is correct", False),
    ]),
]

UNMODELLED = [
    "No rule matched; the effects of this action are not modelled",
    "The state may change in ways this rule table does not cover",
    "Predictions are absent here, which is not the same as safe",
    "Record the missing rule before acting on this action",
]


class Dreamer:
    """Simulates consequences of an action before it is executed."""

    def __init__(self, backend=None, seed: int = 0):
        self.backend = backend          # reserved; the rule table runs offline
        self.seed = seed
        self.dreams: list[str] = []

    # ------------------------------------------------------------ reasoning
    def _import_edges(self, state: str) -> dict[str, list[str]]:
        """Parse ``a.py imports b`` statements into a dependency graph."""
        edges: dict[str, list[str]] = {}
        pattern = re.compile(r"([\w./-]+\.py)\s+imports?\s+([\w.,\s]+)")
        for match in pattern.finditer(state or ""):
            source = match.group(1)
            targets = [name.strip() for name in re.split(r"[,\s]+", match.group(2))
                       if name.strip()]
            edges.setdefault(source, []).extend(targets)
        return edges

    def _dependents(self, module: str, edges: dict[str, list[str]], depth: int = 2) -> list[str]:
        """Modules that load ``module`` directly or one hop later."""
        found: list[str] = []
        frontier = {module.removesuffix(".py")}
        for _ in range(depth):
            discovered = set()
            for candidate, targets in edges.items():
                if candidate in found:
                    continue
                if {t.removesuffix(".py") for t in targets} & frontier:
                    found.append(candidate)
                    discovered.add(candidate.removesuffix(".py"))
            frontier |= discovered
        return found

    def _state_consequences(self, state: str, action: str) -> list[Consequence]:
        targets = [t for t in _tokens(action) if t not in VERBS]
        if not targets or not state:
            return []
        segments = [s.strip() for s in re.split(r"[;\n]|\.\s+", state) if s.strip()]
        definition = next((s for s in segments
                           if all(t in _tokens(s) for t in targets)), None)
        if definition is None:
            return []
        files = FILE.findall(definition)
        if not files:
            return []
        module = files[0]
        found = [Consequence(
            f"{dependent} raises NameError: it imports {module}, which no longer loads",
            True, "state", priority=0)
            for dependent in self._dependents(module, self._import_edges(state))]

        for segment in segments:
            if segment == definition:
                continue
            if not set(targets) & set(_tokens(segment)):
                continue
            direct = FILE.findall(segment)
            who = direct[0] if direct else "The dependent module"
            found.append(Consequence(
                f"{who} raises NameError: it imports a name that no longer exists",
                True, "state", priority=1))
        return found

    def _rule_consequences(self, action: str) -> tuple[list[Consequence], bool]:
        for rule in RULES:
            if rule.matches(action):
                items = [Consequence(text, failure, "rule", priority=10 + index)
                         for index, (text, failure) in enumerate(rule.consequences)]
                return items, True
        return [], False

    def _unmodelled(self, action: str) -> list[Consequence]:
        short = action.strip()[:40] or "the action"
        items = [Consequence(text, False, "unmodelled", priority=50 + index)
                 for index, text in enumerate(UNMODELLED)]
        items.insert(0, Consequence(f"Unmodelled action: {short}", False, "unmodelled",
                                   priority=49))
        return items

    def _collect(self, state: str, action: str) -> tuple[list[Consequence], bool]:
        matched = False
        items = self._state_consequences(state, action)
        rule_items, matched = self._rule_consequences(action)
        if matched:
            items.extend(rule_items)
        else:
            items.extend(self._unmodelled(action))
        seen, unique = set(), []
        for item in sorted(items, key=lambda c: c.priority):
            clipped = _clip(item.text)
            if clipped in seen:
                continue
            seen.add(clipped)
            unique.append(Consequence(clipped, item.failure or _is_failure(clipped),
                                      item.source, item.priority))
        return unique, matched

    # ---------------------------------------------------------------- public
    def _select(self, state: str, action: str, n: int) -> tuple[list[Consequence], bool]:
        if n <= 0:
            raise ValueError("n must be positive")
        consequences, matched = self._collect(state, action)
        selected = consequences[:n]
        rng = random.Random(f"{self.seed}:{state}:{action}")
        rng.shuffle(selected)
        seen = {item.text for item in selected}
        while len(selected) < n:
            short = action.strip()[:50] or "the action"
            text = _clip(f"Unmodelled: {short} may have effects beyond this table")
            if text in seen:
                text = _clip(f"Unmodelled: consequence {len(selected) + 1} is unknown")
            seen.add(text)
            selected.append(Consequence(text, False, "unmodelled", priority=99))
        return selected, matched

    def dream(self, state: str, action: str, n: int = 5) -> list[str]:
        """Return ``n`` distinct, deterministic consequence strings (<100 chars)."""
        selected, _ = self._select(state, action, n)
        dreams = [item.text for item in selected]
        self.dreams.extend(dreams)
        return dreams

    def assess(self, state: str, action: str, n: int = 3) -> dict:
        selected, matched = self._select(state, action, n)
        flagged = sum(1 for item in selected if item.failure)
        return {
            "action": action,
            "dreams": [item.text for item in selected],
            "flagged": flagged,
            "failure_ratio": flagged / len(selected),
            "safe": flagged * 3 < len(selected) * 2,
            "confidence": "medium" if matched else "low",
            "sources": sorted({item.source for item in selected}),
        }

    def filter_safe(self, state: str, actions: list[str], n: int = 3) -> list[str]:
        """Keep actions whose dreams do not fail in two of three futures."""
        return [action for action in actions if self.assess(state, action, n)["safe"]]


def _demo() -> None:
    state = ("a.py imports math; b.py imports a; "
             "api.py queries the users table on every request")
    dreamer = Dreamer(seed=0)

    print("State:", state)
    print("Action: remove import math")
    for index, dream in enumerate(dreamer.dream(state, "remove import math", n=3), 1):
        print(f"  dream {index}: {dream}")

    actions = ["delete the users table", "run the linter", "write a unit test"]
    kept = dreamer.filter_safe(state, actions, n=3)
    print("Actions:", actions)
    print("Kept:", kept)
    assert "delete the users table" not in kept
    assert "run the linter" in kept and "write a unit test" in kept

    unique = dreamer.dream(state, "delete the users table", n=5)
    assert len(set(unique)) == 5 and all(len(d) < 100 for d in unique)
    assert any("b.py" in d for d in dreamer.dream(state, "remove import math", n=3))
    print("Phase 2 works")


if __name__ == "__main__":
    _demo()
