"""The v6 no-observed-regression gate, isolated so new experiments reuse it.

P(results) is the set of test identifiers that passed. Acceptance requires
that every identifier passing for the baseline or the best candidate still
passes, and that the pass count strictly increases.
"""
from __future__ import annotations


def pass_ids(results: dict[str, bool]) -> set[str]:
    return {k for k, v in results.items() if v}


def acceptable(candidate: dict[str, bool], best: dict[str, bool], baseline: dict[str, bool]) -> bool:
    p_cand, p_best, p_base = pass_ids(candidate), pass_ids(best), pass_ids(baseline)
    return (p_best | p_base) <= p_cand and len(p_cand) > len(p_best)


def best_of(candidates: list[dict[str, bool]], baseline: dict[str, bool]) -> tuple[dict[str, bool], int]:
    """Greedy acceptance chain; returns the kept result set and the number of acceptances."""
    best, accepted = dict(baseline), 0
    for cand in candidates:
        if acceptable(cand, best, baseline):
            best, accepted = dict(cand), accepted + 1
    return best, accepted
