"""
Layer 2 (Legacy): Simple causal memory - stores law not text
Each memory = (state, action, cause, next_state, confidence)
Deprecated: Use causal_memory_v2.py for real causal intervention
"""
from __future__ import annotations
from dataclasses import dataclass, field
import hashlib, json, time
from pathlib import Path

@dataclass
class SimpleCausalMemory:
    state: str
    action: str
    cause: str
    next_state: str
    weight: float = 1.0
    timestamp: float = field(default_factory=time.time)
    mem_id: str = ""

    def __post_init__(self):
        if not self.mem_id:
            key = f"{self.state}|{self.action}|{self.cause}".encode()
            self.mem_id = "cm_" + hashlib.sha256(key).hexdigest()[:10]

class SimpleCausalGraph:
    """Simple causal graph - selects by cause, not similarity"""
    def __init__(self, path="causal_memory.jsonl"):
        self.path = Path(path)
        self.mems: list[SimpleCausalMemory] = []
        if self.path.exists():
            for line in self.path.read_text().splitlines():
                if line.strip():
                    self.mems.append(SimpleCausalMemory(**json.loads(line)))

    def add(self, mem: SimpleCausalMemory):
        if not mem.cause or not mem.action:
            return False, "rejected: no cause"
        if any(m.mem_id == mem.mem_id for m in self.mems):
            return False, "duplicate"
        self.mems.append(mem)
        with self.path.open("a") as f:
            f.write(json.dumps(mem.__dict__) + "\n")
        return True, "admitted"

    def retrieve_causal(self, current_state: str, current_goal: str, k=3):
        scored = []
        for m in self.mems:
            score = 0
            if m.state.lower() in current_state.lower() or current_state.lower() in m.state.lower():
                score += 1
            if m.cause.lower() in current_goal.lower() or current_goal.lower() in m.cause.lower():
                score += 2
            score *= m.weight
            scored.append((score, m))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [m for s, m in scored[:k] if s > 0]
