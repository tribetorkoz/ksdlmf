# PROMPTS FOR CODING AGENT - NAWAH-AGI PROJECT
# 7 Phases - Precise English Prompts for Autonomous Implementation
# Based on 2026 Best Practices: Spec-Driven, Scope-Limited, Verifiable

---

## GLOBAL SYSTEM PROMPT (Use for every agent)

```
ROLE: You are a senior AI systems engineer specializing in agentic architectures, causal reasoning, and verification systems. You work on production-quality Python code.

PRINCIPLES:
- Write spec before code. No file is edited without a clear acceptance criterion.
- Scope is sacred. Never edit files outside SCOPE.
- Every change must be verifiable by a test or command.
- Never fabricate metrics. Missing values stay None.
- Preserve existing behavior unless explicitly asked otherwise.

OUTPUT FORMAT: After each task, list CHANGED files, verification command, and result.
```

---

## PHASE 1: Causal Memory (Core Upgrade)

```
GOAL: Replace keyword-based retrieval with causal intervention scoring in core/causal_memory_v2.py

SCOPE:
- Allowed: core/causal_memory_v2.py only
- Do not touch: core/gate.py, core/swarm.py, core/dreamer.py

CONTEXT:
- Read core/causal_memory_v2.py (current 154-line lightweight version)
- Read paper: causal-memory-intervention GitHub (Saksham4796) - 3-response intervention scoring
- Read AMA-Agent paper - causality graph construction

CONTRAINTS:
- Must run on 8GB RAM, CPU only, no API keys, no network calls
- Must support caused/enabled/prevented relations

ACCEPTANCE:
1. python3 core/causal_memory_v2.py -> must print "Phase 1 works" and pass assertion that causal retrieval returns cause-related memory, not random
2. python3 -m pytest tests/test_causal.py (you must create it) -> 5/5 pass: test_causal_retrieval, test_prevented_inhibition, test_update_weight, test_no_duplicate, test_persistence
3. git diff --name-only shows only core/causal_memory_v2.py and tests/test_causal.py

DELIVERABLE: Improved causal_memory_v2.py with intervention_score() that scores by causal effect, not keyword overlap, plus 5 tests.
```

---

## PHASE 2: Dreamer (World Model Simulation)

```
GOAL: Implement lightweight world-model simulator in core/dreamer.py that can filter unsafe actions before execution

SCOPE:
- Allowed: core/dreamer.py only
- Do not touch: core/gate.py, core/causal_memory_v2.py

CONTEXT:
- Read core/dreamer.py (current stub that returns dummy scenarios)
- Research: LeWorldModel (15M JEPA) principle - predict in latent space, discard unpredictable details
- Constraint: Must work on CPU, no GPU, no training

ACCEPTANCE:
1. Dreamer().dream(state, action, n=5) returns 5 distinct scenario strings, each <100 chars
2. Dreamer().filter_safe(state, actions) rejects actions where 2/3 dreams contain failure keywords (error/fail/break)
3. python3 core/dreamer.py -> must pass: safe actions kept, unsafe filtered, distinct dreams
4. No new dependencies (only stdlib + optional backend)

DELIVERABLE: dreamer.py with dream() and filter_safe() that actually simulates consequences.
```

---

## PHASE 3: Swarm (Stigmergic Collaboration)

```
GOAL: Implement file-based swarm coordination in core/swarm.py using stigmergy (blackboard), not chat

SCOPE:
- Allowed: core/swarm.py only
- Do not touch: other core files

CONTEXT:
- Read core/swarm.py (current 3-agent stub)
- Research: MIT SwarmWorld 2026 - 95% coordination via environment, not messaging
- Pattern: Blackboard - agents leave JSON traces, next agent reads all traces

ACCEPTANCE:
1. Swarm(workdir).leave_trace(agent, key, data) creates workdir/key.json
2. Swarm().read_traces() returns all traces sorted
3. Swarm().run_team(task, {explorer: func, critic: func, fixer: func}) runs 3 agents sequentially, each sees previous traces, stops on stop=True
4. python3 core/swarm.py -> 3 traces created, critic sees explorer's trace
5. No inter-agent chat, only file I/O

DELIVERABLE: swarm.py with persistent blackboard coordination.
```

---

## PHASE 4: Integration Loop (AGI Core)

```
GOAL: Create core/agi_loop.py that orchestrates all 4 layers: swarm -> dreamer -> causal_memory -> gate

SCOPE:
- Allowed: core/agi_loop.py (new file) + minimal edits to core/__init__.py if needed
- Do not touch: existing core files logic

CONTEXT:
- Read core/gate.py (acceptable function), core/causal_memory_v2.py (retrieve_causal), core/dreamer.py (filter_safe), core/swarm.py (run_team)
- Architecture: Goal -> Swarm (plan) -> Dreamer (simulate) -> CausalMemory (enrich) -> Backend (propose) -> Gate (verify)

ACCEPTANCE:
1. AGILoop(task, backend, workdir).run() executes full cycle and returns {best_candidate, audit_log, accepted_count}
2. Uses gate.acceptable() to decide acceptance - never bypasses it
3. Logs every step to resources.jsonl via ResourceLog
4. python3 core/agi_loop.py -> demo run with ScriptedBackend passes: 1 task, 3 candidates, 1 accepted
5. No weight updates, only inference

DELIVERABLE: agi_loop.py - the integrated AGI layer (code only, not model).
```

---

## PHASE 5: Evaluation Harness (ARC-AGI + SWE-bench Lite)

```
GOAL: Build eval/harness.py that tests AGI loop on 20 ARC-AGI-1 + 10 SWE-bench Lite tasks

SCOPE:
- Allowed: eval/ directory (new)
- Do not touch: core/

CONTEXT:
- Read core/agi_loop.py
- Datasets: public ARC-AGI-1 (1000 tasks, human 66% avg) - use 20-sample subset; SWE-bench Lite (300 tasks)
- Must be reproducible: fixed seed, no API, local Qwen 1.5B Q4

ACCEPTANCE:
1. python eval/harness.py --suite arc --n 20 -> outputs eval/results.json with {task_id, success, calls, human_baseline}
2. Success metric: pass rate on ARC-AGI-1 subset; report as "X/20 (Y% vs human 66%)"
3. No invented metrics - if task fails, record fail
4. Results are deterministic with same seed

DELIVERABLE: eval harness that can prove/disprove AGI claim on public benchmarks.
```

---

## PHASE 6: Independent Verification

```
GOAL: Prepare verification package for third-party reproduction

SCOPE:
- Allowed: README.md, reproduce/ directory
- Do not touch: core/

CONTEXT:
- Read all core/ and eval/ files
- Standard: Microsoft-OpenAI 2025 agreement - independent expert panel must verify AGI

ACCEPTANCE:
1. README.md contains: definition of your AGI (one sentence), evaluation protocol, how to reproduce (3 commands)
2. reproduce.sh exists and runs: pip install -r requirements.txt && python eval/harness.py --suite arc --n 20
3. All results include git hash, timestamp, and backend identity
4. No claims without evidence file

DELIVERABLE: Verification-ready package.
```

---

## PHASE 7: Final Integration & ZIP

```
GOAL: Integrate all phases, ensure English-only, no Arabic, and create final ZIP

SCOPE:
- All files in AGI_PROJECT/

CONTEXT:
- Review every file for Arabic characters - must be 0
- Ensure PROMPTS.md covers all phases
- Create AGI_PROJECT_EN.zip

ACCEPTANCE:
1. grep -r "[\\u0600-\\u06FF]" AGI_PROJECT/ -> 0 matches
2. zip -r AGI_PROJECT_EN.zip AGI_PROJECT/ -> creates zip < 5MB
3. unzip -l AGI_PROJECT_EN.zip shows all 7 phases + core + eval + PROMPTS.md
4. Final test: python3 AGI_PROJECT/test_agi.py still passes

DELIVERABLE: AGI_PROJECT_EN.zip - complete English project ready to give to any coding agent.
```

---

## HOW TO USE THESE PROMPTS

1. Give the Global System Prompt once to your coding agent (Claude Code, Cursor, etc.)
2. Feed Phase 1 prompt, wait for completion and verification, then Phase 2, etc.
3. Never skip verification step - each phase must pass its ACCEPTANCE before next
4. Final Phase 7 creates the ZIP you requested

