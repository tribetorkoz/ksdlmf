# Seven phases: deliverable, proof, command

`PROMPTS.md` is the specification. This file maps each phase to the code that
implements it, the evidence file that proves it ran, and the command a reviewer can
execute to see the proof again.

| Phase | Deliverable | Proof | Command |
|---|---|---|---|
| 1. Causal memory | `core/causal_memory_v2.py` | `tests/test_causal.py`, demo output | `python -m pytest tests/test_causal.py -q` and `python core/causal_memory_v2.py` |
| 2. Dreamer | `core/dreamer.py` | `tests/test_dreamer.py`, demo output | `python -m pytest tests/test_dreamer.py -q` and `python core/dreamer.py` |
| 3. Stigmergic swarm | `core/swarm.py` | `tests/test_swarm.py`, demo output | `python -m pytest tests/test_swarm.py -q` and `python core/swarm.py` |
| 4. Integration loop | `core/agi_loop.py` | `tests/test_agi_loop.py`, `resources.jsonl` written per run | `python -m pytest tests/test_agi_loop.py -q` and `python core/agi_loop.py` |
| 5. Evaluation | `eval/harness.py`, `eval/arc_data.py`, `eval/arc_dsl.py`, `eval/data/` | `eval/results.json`, `eval/results_training.json`, `eval/results_swebench.json`, `eval/RESULTS.md` | `python eval/harness.py --suite arc --n 20` |
| 6. Verification | `README.md`, `reproduce/` | `reproduce/CLAIMS.md`, `reproduce/check.py` | `python reproduce/check.py` |
| 7. Integration and archive | `scripts/`, `AGI_PROJECT_EN.zip` | `scripts/check_english.py` output, `scripts/make_release.py` output | `python scripts/check_english.py` and `python scripts/make_release.py` |

## What each phase proved

1. **Causal memory**: a memory must state a cause or an effect; retrieval scores the
   causal path first and keyword overlap last; a `prevented` relation scores negative
   and is never returned; feedback moves a bounded weight and survives a reload.
2. **Dreamer**: consequences come from state facts (an import graph built from the
   state text) and a verb rule table; five distinct futures under 100 characters;
   an action whose futures fail in two of three cases is filtered before it is taken.
3. **Swarm**: traces are files, ownership is recorded in `_manifest.json`, foreign
   files are never deleted, keys cannot escape the work directory, and each agent
   receives every trace written before it.
4. **Loop**: plan, dream, memory, propose, verify, gate - in that order, every step in
   `audit_log` and `resources.jsonl`; the gate is consulted, never bypassed; a scripted
   run is labelled `engineering_only`.
5. **Evaluation**: twenty real ARC-AGI-1 evaluation tasks, hashed; a deterministic DSL
   backend; 0/20 measured; twenty real training tasks, 2/20 measured; SWE-bench Lite
   recorded as `not_run` because the dataset and the sandbox are absent.
6. **Verification**: every number carries git, timestamp and backend identity; every
   claim maps to an evidence file or is marked `UNSUPPORTED`; the artefact checker
   verifies the mapping mechanically.
7. **Archive**: zero Arabic-block characters, a release ZIP under 5 MB, and a smoke
   test that asserts rather than advertises.
