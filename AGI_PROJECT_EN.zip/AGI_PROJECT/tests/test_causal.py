"""Phase 1 acceptance tests: causal retrieval beats keyword overlap."""
from __future__ import annotations

import json

import pytest

from core.causal_memory_v2 import CausalMemory, CausalMemoryStore


def make_store(tmp_path) -> CausalMemoryStore:
    return CausalMemoryStore(str(tmp_path / "memory.jsonl"))


def test_causal_retrieval(tmp_path):
    store = make_store(tmp_path)
    store.add("Forgetting import math causes NameError",
              cause_of="NameError", caused_by="forgetting import math")
    store.add("Random info about weather",
              cause_of="rain", caused_by="cloud")

    result = store.retrieve_causal("I have a NameError in my code", k=1)

    assert result, "causal retrieval returned nothing"
    assert "import math" in result[0].content
    assert "weather" not in result[0].content


def test_prevented_inhibition(tmp_path):
    store = make_store(tmp_path)
    ok, mem_id = store.add("A try/except block prevented the NameError",
                           cause_of="NameError", caused_by="try/except",
                           relation="prevented")
    assert ok

    memory = store.mems[0]
    assert store.intervention_score("I have a NameError", memory) < 0
    assert all(m.relation != "prevented"
               for m in store.retrieve_causal("I have a NameError", k=3))
    assert store.stats()["inhibited"] >= 1


def test_update_weight(tmp_path):
    store = make_store(tmp_path)
    ok, mem_id = store.add("Missing break causes an infinite loop",
                           cause_of="hang", caused_by="missing break")
    assert ok
    before = store.mems[0].weight

    after_success = store.update_on_feedback(mem_id, True)
    assert after_success > before

    after_failure = store.update_on_feedback(mem_id, False)
    assert after_failure < after_success

    memory = store.mems[0]
    assert (memory.trials, memory.successes) == (2, 1)


def test_no_duplicate(tmp_path):
    store = make_store(tmp_path)
    first = store.add("A race condition causes corrupted output",
                      cause_of="corrupted output", caused_by="race condition")
    second = store.add("A race condition causes corrupted output",
                       cause_of="corrupted output", caused_by="race condition")

    assert first[0] is True
    assert second[0] is False
    assert "duplicate" in second[1]
    assert len(store.mems) == 1


def test_persistence(tmp_path):
    path = tmp_path / "memory.jsonl"
    store = CausalMemoryStore(str(path))
    ok, mem_id = store.add("Removing the lock enabled a data race",
                           cause_of="data race", caused_by="removing the lock")
    assert ok
    store.update_on_feedback(mem_id, True)
    store.record_outcome([mem_id], True)

    reloaded = CausalMemoryStore(str(path))

    assert len(reloaded.mems) == 1
    assert reloaded.mems[0].trials == 1
    assert reloaded.mems[0].successes == 1
    assert reloaded.mems[0].weight > 1.0
    assert reloaded.stats()["outcome_rows"] == 1

    payload = [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
    assert payload and all("mem_id" in row for row in payload if "content" in row)


def test_effect_uses_logged_outcomes(tmp_path):
    store = make_store(tmp_path)
    ok_a, mem_a = store.add("A stale cache causes a wrong total",
                            cause_of="wrong total", caused_by="stale cache")
    ok_b, mem_b = store.add("A missing index causes a slow query",
                            cause_of="slow query", caused_by="missing index")
    assert ok_a and ok_b

    for _ in range(3):
        store.record_outcome([mem_a], True)
    for _ in range(2):
        store.record_outcome([mem_b], False)

    assert store.intervention_effect(mem_a) > 0
    assert store.intervention_effect(mem_b) < 0


def test_memory_requires_a_causal_link(tmp_path):
    store = make_store(tmp_path)
    ok, reason = store.add("Some fact with no cause and no effect")

    assert ok is False
    assert "causal" in reason.lower()
    assert store.mems == []


def test_unknown_relation_is_rejected(tmp_path):
    store = make_store(tmp_path)
    with pytest.raises(ValueError):
        store.add("A causes B", cause_of="B", caused_by="A", relation="correlates")


def test_retrieval_is_deterministic(tmp_path):
    store = make_store(tmp_path)
    store.add("A missing import causes ImportError", cause_of="ImportError", caused_by="missing import")
    store.add("An empty list causes IndexError", cause_of="IndexError", caused_by="empty list")

    first = [m.mem_id for m in store.retrieve_causal("ImportError", k=2)]
    second = [m.mem_id for m in store.retrieve_causal("ImportError", k=2)]

    assert first == second
