"""Phase 3 acceptance tests: coordination through the environment, not chat."""
from __future__ import annotations

import json

from core.swarm import Swarm


def test_leave_trace_creates_a_named_file(tmp_path):
    swarm = Swarm(str(tmp_path))
    path = swarm.leave_trace("explorer", "step1", {"idea": "method A"})

    assert path == tmp_path / "step1.json"
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["agent"] == "explorer"
    assert payload["data"]["idea"] == "method A"
    assert payload["tick"] == 0


def test_read_traces_returns_all_traces_sorted(tmp_path):
    swarm = Swarm(str(tmp_path))
    swarm.leave_trace("zeta", "b_trace", {"n": 2})
    swarm.leave_trace("alpha", "a_trace", {"n": 1})

    traces = swarm.read_traces()

    # Order is chronological, then agent, then key: the record of what happened.
    assert [(t["tick"], t["agent"], t["key"]) for t in traces] == [
        (0, "zeta", "b_trace"),
        (1, "alpha", "a_trace"),
    ]
    assert traces == sorted(traces, key=lambda t: (t["tick"], t["agent"], t["key"]))


def test_run_team_leaves_three_traces_and_each_agent_sees_the_previous(tmp_path):
    swarm = Swarm(str(tmp_path))
    seen: dict[str, list[dict]] = {}

    def explorer(task, context):
        seen["explorer"] = list(context)
        return {"idea": "call the parser first"}

    def critic(task, context):
        seen["critic"] = list(context)
        return {"critique": "parser has no fixture", "stop": False}

    def fixer(task, context):
        seen["fixer"] = list(context)
        return {"fix": "add the fixture", "stop": True}

    traces = swarm.run_team("repair the parser", {"explorer": explorer,
                                                  "critic": critic, "fixer": fixer})

    assert [t["agent"] for t in traces] == ["explorer", "critic", "fixer"]
    assert seen["explorer"] == []
    assert len(seen["critic"]) == 1 and seen["critic"][0]["agent"] == "explorer"
    assert len(seen["fixer"]) == 2


def test_stop_halts_the_team(tmp_path):
    swarm = Swarm(str(tmp_path))
    calls = []

    def explorer(task, context):
        calls.append("explorer")
        return {"idea": "x"}

    def critic(task, context):
        calls.append("critic")
        return {"stop": True}

    def fixer(task, context):
        calls.append("fixer")
        return {}

    traces = swarm.run_team("t", {"explorer": explorer, "critic": critic, "fixer": fixer})

    assert calls == ["explorer", "critic"]
    assert len(traces) == 2


def test_foreign_json_files_are_never_deleted(tmp_path):
    notes = tmp_path / "notes.json"
    notes.write_text('{"keep": true}', encoding="utf-8")

    first = Swarm(str(tmp_path))
    first.leave_trace("explorer", "a_trace", {"x": 1})
    assert notes.exists()

    second = Swarm(str(tmp_path))
    assert notes.exists(), "a foreign file was deleted"
    assert not (tmp_path / "a_trace.json").exists(), "own traces were not recycled"
    assert second.read_traces() == []


def test_keys_cannot_escape_the_workdir(tmp_path):
    swarm = Swarm(str(tmp_path))
    path = swarm.leave_trace("explorer", "../../evil", {"x": 1})

    assert path.parent == tmp_path
    assert path.exists()


def test_clear_counts_removed_traces(tmp_path):
    swarm = Swarm(str(tmp_path))
    swarm.leave_trace("a", "one", {"x": 1})
    swarm.leave_trace("b", "two", {"x": 2})

    assert swarm.clear() == 2
    assert swarm.read_traces() == []
