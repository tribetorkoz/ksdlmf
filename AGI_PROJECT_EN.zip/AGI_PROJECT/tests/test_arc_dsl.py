"""ARC DSL solver tests.

The toy tasks below are hand-written for the test suite. They are not ARC
tasks, they are not counted anywhere, and they exist only to pin each family
of the DSL. The real measurement lives in `eval/harness.py`.
"""
from __future__ import annotations

import pytest

from eval.arc_dsl import ArcDSLBackend, apply_source, matches


def run(source: str, grid):
    return apply_source(source, grid)


def test_rotation_family_solves_a_quarter_turn():
    train = [{"input": [[1, 2], [3, 4]], "output": [[3, 1], [4, 2]]}]

    source = ArcDSLBackend().best_source(train)

    assert source is not None
    assert run(source, [[5, 6], [7, 8]]) == [[7, 5], [8, 6]]


def test_dihedral_family_has_eight_distinct_outputs():
    train = [{"input": [[1, 2], [3, 4]], "output": [[4, 2], [3, 1]]}]

    source = ArcDSLBackend().best_source(train)

    assert source is not None
    assert run(source, [[1, 2], [3, 4]]) == [[4, 2], [3, 1]]


def test_colour_map_family_is_learned_from_the_pairs():
    train = [{"input": [[1, 2], [2, 1]], "output": [[3, 4], [4, 3]]}]

    source = ArcDSLBackend().best_source(train)

    assert source is not None
    assert run(source, [[2, 2], [1, 1]]) == [[4, 4], [3, 3]]


def test_constant_output_family():
    train = [{"input": [[1, 2]], "output": [[7, 8]]},
             {"input": [[3]], "output": [[7, 8]]}]

    source = ArcDSLBackend().best_source(train)

    assert source is not None
    assert run(source, [[9, 9, 9]]) == [[7, 8]]


def test_crop_to_content_family():
    train = [{"input": [[0, 0, 0], [0, 5, 5], [0, 5, 0]],
              "output": [[5, 5], [5, 0]]}]

    source = ArcDSLBackend().best_source(train)

    assert source is not None
    assert run(source, [[0, 0], [0, 5]]) == [[5]]


def test_tiling_family():
    train = [{"input": [[1, 2]], "output": [[1, 2, 1, 2], [1, 2, 1, 2]]}]

    source = ArcDSLBackend().best_source(train)

    assert source is not None
    assert run(source, [[3]]) == [[3, 3], [3, 3]]


def test_scaling_family():
    train = [{"input": [[1, 2], [3, 4]],
              "output": [[1, 1, 2, 2], [1, 1, 2, 2], [3, 3, 4, 4], [3, 3, 4, 4]]}]

    source = ArcDSLBackend().best_source(train)

    assert source is not None
    assert run(source, [[4, 5], [6, 7]]) == [
        [4, 4, 5, 5], [4, 4, 5, 5], [6, 6, 7, 7], [6, 6, 7, 7]]


def test_symmetry_repair_family():
    train = [{"input": [[1, 2, 0, 1], [3, 3, 3, 3]],
              "output": [[1, 2, 2, 1], [3, 3, 3, 3]]}]

    programs = ArcDSLBackend().programs_for(train)

    names = [program.name for program in programs]
    assert "symmetry_repair" in names
    repair = next(program for program in programs if program.name == "symmetry_repair")
    assert run(repair.source, train[0]["input"]) == train[0]["output"]


def test_identity_is_not_returned_when_the_pairs_change():
    train = [{"input": [[1]], "output": [[2]]}]
    names = [program.name for program in ArcDSLBackend().programs_for(train)]

    assert "identity" not in names


def test_invalid_task_returns_no_source():
    backend = ArcDSLBackend()

    assert backend.best_source([]) is None
    assert backend.best_source([{"input": [], "output": []}]) is None
    assert backend.best_source([{"input": [[1, 2], [3]], "output": [[1]]}]) is None
    assert backend.best_source([{"input": [[1]], "output": [[True]]}]) is None


def test_complete_returns_one_program_per_attempt():
    backend = ArcDSLBackend()
    context = {"train": [{"input": [[1, 2], [3, 4]], "output": [[3, 1], [4, 2]]}]}

    first = backend.complete("attempt 1", context)
    second = backend.complete("attempt 2", context)

    assert "def solve(g)" in first["code"]
    assert second["code"] == "" or second["code"] != first["code"]


def test_complete_without_context_is_empty_not_invented():
    result = ArcDSLBackend().complete("attempt 1", None)

    assert result["code"] == ""


def test_generated_source_is_executable_and_pure():
    train = [{"input": [[1, 0], [0, 1]], "output": [[2, 0], [0, 2]]}]
    source = ArcDSLBackend().best_source(train)

    assert source is not None
    assert matches(source, train)
    namespace: dict = {}
    exec(compile(source, "<program>", "exec"), namespace)
    assert callable(namespace["solve"])


def test_identity_is_ranked_before_more_complex_families():
    train = [{"input": [[1, 2], [3, 4]], "output": [[1, 2], [3, 4]]}]

    programs = ArcDSLBackend().programs_for(train)

    assert programs[0].name == "identity"
    assert programs[0].complexity <= programs[-1].complexity


def test_backend_identity_is_honest_about_what_it_is():
    identity = ArcDSLBackend().identity()

    assert identity["is_real"] is True
    assert identity["label"] == "arc_dsl_v1"
    assert identity["weights_sha256"] is None
    assert "program synthesis" in identity["note"]
