"""Phase 2 acceptance tests: the dreamer predicts consequences before acting."""
from __future__ import annotations

import pytest

from core.dreamer import Dreamer

STATE = "a.py imports math; b.py imports a; the users table is queried by api.py"


def test_dream_returns_five_distinct_short_scenarios():
    dreams = Dreamer(seed=0).dream(STATE, "remove import math", n=5)

    assert len(dreams) == 5
    assert len(set(dreams)) == 5, "scenarios repeat"
    assert all(isinstance(d, str) and len(d) < 100 for d in dreams)


def test_dream_is_deterministic_per_seed():
    first = Dreamer(seed=7).dream(STATE, "delete the users table", n=4)
    second = Dreamer(seed=7).dream(STATE, "delete the users table", n=4)
    other = Dreamer(seed=8).dream(STATE, "delete the users table", n=4)

    assert first == second
    assert sorted(first) == sorted(other), "seed must change order, not content"


def test_dream_grounds_the_consequence_in_the_state():
    dreams = Dreamer(seed=0).dream("a.py imports math; b.py imports a", "remove import math", n=3)

    assert any("b.py" in d for d in dreams)
    assert any("NameError" in d or "ImportError" in d for d in dreams)


def test_filter_safe_rejects_an_action_whose_dreams_fail():
    dreamer = Dreamer(seed=0)
    kept = dreamer.filter_safe(
        STATE,
        ["delete the users table", "run the linter", "write a unit test"],
        n=3,
    )

    assert "delete the users table" not in kept
    assert kept == ["run the linter", "write a unit test"]


def test_filter_safe_uses_a_two_of_three_rule():
    dreamer = Dreamer(seed=0)
    assessment = dreamer.assess(STATE, "delete the users table", n=3)

    assert assessment["failure_ratio"] >= 2 / 3
    assert assessment["safe"] is False
    assert len(assessment["dreams"]) == 3


def test_unknown_action_is_kept_but_low_confidence():
    dreamer = Dreamer(seed=0)
    assessment = dreamer.assess(STATE, "ponder the orb", n=3)

    assert assessment["safe"] is True
    assert assessment["confidence"] == "low"
    assert len(set(assessment["dreams"])) == 3


def test_no_backend_needed_and_no_network():
    dreamer = Dreamer()
    assert dreamer.dream("state", "write a test", n=2)
    with pytest.raises(ValueError):
        dreamer.dream("state", "write a test", n=0)
