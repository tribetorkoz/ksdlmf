"""Phase 5 acceptance tests: a harness that measures or says it did not."""
from __future__ import annotations

import json
import re
from pathlib import Path

from eval.arc_data import ArcTask, load_arc_subset
from eval.arc_dsl import ArcDSLBackend
from eval.harness import evaluate_arc, run_arc, run_swebench

BUNDLED = Path("eval/data/arc_agi1_evaluation_seed0.json")


def test_arc_run_is_measured_with_the_real_baseline(tmp_path):
    result = run_arc(n=2, seed=0, out=tmp_path / "results.json")

    assert result["status"] == "measured"
    assert result["suite"] == "arc"
    assert result["human_baseline"] == 0.66
    assert result["dataset"]["tasks_available"] == 20
    assert len(result["tasks"]) == 2


def test_two_runs_with_the_same_seed_agree(tmp_path):
    first = run_arc(n=3, seed=0, out=tmp_path / "a.json")
    second = run_arc(n=3, seed=0, out=tmp_path / "b.json")

    first_map = [(t["task_id"], t["success"]) for t in first["tasks"]]
    second_map = [(t["task_id"], t["success"]) for t in second["tasks"]]
    assert first_map == second_map


def test_missing_dataset_is_not_run_not_a_zero_score(tmp_path):
    result = run_arc(data=tmp_path / "absent.json", out=tmp_path / "out.json")

    assert result["status"] == "not_run"
    assert result["pass_rate"] is None
    assert result["solved"] is None
    assert "fetch_arc" in result["reason"]


def test_result_carries_git_timestamp_and_backend(tmp_path):
    result = run_arc(n=1, seed=0, out=tmp_path / "out.json")

    assert result["timestamp"].endswith("Z")
    assert result["backend"]["label"] == "arc_dsl_v1"
    assert result["git"] is None or len(result["git"]) >= 7
    assert result["python"]


def test_summary_line_uses_the_required_shape(tmp_path):
    result = run_arc(n=2, seed=0, out=tmp_path / "out.json")

    assert re.fullmatch(r"\d+/\d+ \(\d+% vs human 66%\)", result["summary"])


def test_invalid_tasks_are_recorded_and_excluded_from_the_denominator(tmp_path):
    real = load_arc_subset(BUNDLED)[0]
    broken = ArcTask(task_id="broken", train=[], test=[{"input": [[0]]}])

    result = evaluate_arc([broken, real], backend=ArcDSLBackend(),
                          out=tmp_path / "out.json")

    assert result["status"] == "measured"
    assert result["tasks"][0]["status"] == "invalid"
    assert result["tasks"][0]["success"] is False
    assert result["scored"] == 1
    assert result["invalid"] == 1


def test_results_file_is_written_and_matches_the_return_value(tmp_path):
    path = tmp_path / "out.json"
    result = run_arc(n=2, seed=0, out=path)

    assert path.exists()
    assert json.loads(path.read_text(encoding="utf-8"))["summary"] == result["summary"]


def test_swebench_without_a_dataset_is_not_run(tmp_path):
    result = run_swebench(path=tmp_path / "absent.jsonl")

    assert result["status"] == "not_run"
    assert result["pass_rate"] is None
    assert "dataset" in result["reason"].lower()


def test_swebench_without_a_sandbox_refuses_to_score(tmp_path):
    dataset = tmp_path / "lite.jsonl"
    dataset.write_text(json.dumps({"instance_id": "demo__demo-1",
                                   "problem_statement": "fix it"}) + "\n",
                       encoding="utf-8")

    result = run_swebench(path=dataset)

    assert result["status"] == "not_run"
    assert "sandbox" in result["reason"].lower()


def test_index_written_for_every_measured_run(tmp_path):
    index = tmp_path / "RESULTS.md"
    run_arc(n=1, seed=0, out=tmp_path / "out.json", index=index)

    assert index.exists()
    text = index.read_text(encoding="utf-8")
    assert "ARC-AGI-1" in text
    assert "vs human 66%" in text


def test_library_defaults_write_nothing(tmp_path, monkeypatch):
    """A library call with no out or index must not overwrite a recorded result.

    Regression: the defaults used to point at eval/results*.json, so running the
    test suite replaced the real SWE-bench record with a test artefact.
    """
    monkeypatch.chdir(tmp_path)

    measured = run_arc(n=1, seed=0)
    not_run = run_swebench(path=tmp_path / "absent.jsonl")

    assert measured["status"] == "measured"
    assert not_run["status"] == "not_run"
    assert list(tmp_path.iterdir()) == []
