"""Portable code verification: no SIGALRM, no frozen process on Windows."""
from __future__ import annotations

import time

from core.skills import verify_code, verify_tests


def test_passing_code_is_reported_as_passing():
    result = verify_code("def add(a, b):\n    return a + b",
                         ["assert add(2, 3) == 5"])

    assert result["ok"] is True
    assert (result["passed"], result["total"]) == (1, 1)
    assert result["reason"] == "ok"


def test_failing_assertion_is_reported_with_its_type():
    result = verify_code("def add(a, b):\n    return a - b",
                         ["assert add(2, 3) == 5"])

    assert result["ok"] is False
    assert result["passed"] == 0
    assert "AssertionError" in result["reason"]


def test_syntax_error_is_reported_not_raised():
    result = verify_code("def add(a, b):", ["assert True"])

    assert result["ok"] is False
    # An unterminated block surfaces as IndentationError, a SyntaxError subclass.
    assert result["reason"].startswith(("SyntaxError", "IndentationError"))


def test_hanging_test_times_out_without_freezing_the_process():
    started = time.time()
    result = verify_code("value = 1", ["while True:\n    pass"], seconds=1)
    elapsed = time.time() - started

    assert result["ok"] is False
    assert result["reason"] == "timeout"
    assert elapsed < 10, "the timeout did not actually bound the run"


def test_empty_test_list_is_rejected():
    result = verify_code("x = 1", [])

    assert result["ok"] is False
    assert "no tests" in result["reason"]


def test_verify_tests_returns_a_per_test_map():
    mapping = verify_tests("def inc(x):\n    return x + 1",
                           ["assert inc(1) == 2", "assert inc(1) == 3"])

    assert mapping == {"t0": True, "t1": False}


def test_verify_tests_marks_every_test_when_all_pass():
    mapping = verify_tests("def inc(x):\n    return x + 1",
                           ["assert inc(1) == 2", "assert inc(2) == 3"])

    assert mapping == {"t0": True, "t1": True}
