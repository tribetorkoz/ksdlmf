"""ARC-AGI-1 subset: load, validate, and prove the bytes did not change."""
from __future__ import annotations

import json
import hashlib
from pathlib import Path

import pytest

from eval.arc_data import (ArcTask, load_arc_subset, sha256_file,
                           validate_task, verify_arc_dataset)

SUBSET = Path("eval/data/arc_agi1_evaluation_seed0.json")


def test_the_bundled_subset_holds_twenty_real_tasks():
    tasks = load_arc_subset(SUBSET)

    assert len(tasks) == 20
    assert len({task.task_id for task in tasks}) == 20
    assert all(task.train for task in tasks)
    assert all(task.test for task in tasks)


def test_every_task_hash_matches_its_payload():
    manifest = json.loads(SUBSET.read_text(encoding="utf-8"))
    tasks = load_arc_subset(SUBSET)

    assert [task.task_id for task in tasks] == [row["task_id"] for row in manifest["tasks"]]
    assert all(task.sha256 == row["sha256"] for task, row in zip(tasks, manifest["tasks"]))
    assert manifest["human_baseline"] == 0.66
    assert manifest["license"] == "Apache-2.0"


def test_dataset_verification_reports_valid_tasks():
    tasks = load_arc_subset(SUBSET)
    report = verify_arc_dataset(tasks)

    assert report["ok"] is True
    assert report["valid"] == 20
    assert report["invalid"] == []


def test_an_empty_task_is_invalid_not_fatal():
    broken = ArcTask(task_id="empty", train=[], test=[{"input": [[0]]}], sha256="")
    report = verify_arc_dataset([broken])

    assert report["ok"] is False
    assert report["invalid"] == ["empty"]
    assert report["valid"] == 0


def test_an_out_of_range_colour_is_invalid():
    broken = ArcTask(task_id="colour", train=[{"input": [[11]], "output": [[1]]}],
                     test=[{"input": [[1]]}], sha256="")
    problems = validate_task(broken)

    assert any("colour" in problem for problem in problems)


def test_a_ragged_grid_is_invalid():
    broken = ArcTask(task_id="ragged", train=[{"input": [[1, 2], [3]], "output": [[1]]}],
                     test=[{"input": [[1]]}], sha256="")
    problems = validate_task(broken)

    assert any("ragged" in problem for problem in problems)


def test_a_tampered_file_is_refused(tmp_path):
    manifest = json.loads(SUBSET.read_text(encoding="utf-8"))
    manifest["tasks"][0]["train"][0]["output"][0][0] = 9
    tampered = tmp_path / "tampered.json"
    tampered.write_text(json.dumps(manifest), encoding="utf-8")

    with pytest.raises(ValueError, match="sha256"):
        load_arc_subset(tampered)


def test_missing_file_says_so(tmp_path):
    with pytest.raises(FileNotFoundError) as error:
        load_arc_subset(tmp_path / "absent.json")

    assert "fetch_arc" in str(error.value)


def test_sha256_file_is_stable(tmp_path):
    path = tmp_path / "payload.bin"
    path.write_bytes(b"nawah")

    assert sha256_file(path) == hashlib.sha256(b"nawah").hexdigest()
