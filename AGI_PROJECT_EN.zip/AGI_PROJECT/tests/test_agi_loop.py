"""Phase 4 acceptance tests: the integrated loop, gated at every acceptance."""
from __future__ import annotations

from pathlib import Path

from core.agi_loop import AGILoop, Task, demo
from core.backends import ScriptedBackend
from core.causal_memory_v2 import CausalMemoryStore
from core.resources import ResourceLog

GOOD = "def add(a, b):\n    return a + b"
REGRESSING = "def add(a, b):\n    return a + b if a >= 0 else 0"
BROKEN = "def add(a, b):\n    return a - b"

TASK = Task(task_id="add_two", family="arithmetic",
            description="Implement add(a, b) returning the sum of two integers",
            tests=["assert add(2, 3) == 5", "assert add(-1, 1) == 0"])


def make_loop(tmp_path, responses, **kwargs) -> AGILoop:
    backend = ScriptedBackend(responses)
    return AGILoop(TASK, backend, tmp_path, **kwargs)


def test_demo_accepts_exactly_one_of_three_candidates(tmp_path):
    result = make_loop(tmp_path, {
        "attempt 1": BROKEN,
        "attempt 2": GOOD,
        "attempt 3": REGRESSING,
    }).run()

    assert result["accepted_count"] == 1
    assert result["best_candidate"].strip() == GOOD
    assert result["measurement_class"] == "engineering_only"
    assert result["task_id"] == "add_two"


def test_the_gate_never_accepts_a_regression(tmp_path):
    result = make_loop(tmp_path, {
        "attempt 1": GOOD,
        "attempt 2": REGRESSING,
    }).run()

    assert result["accepted_count"] == 1
    assert result["best_candidate"].strip() == GOOD
    rejected = [step for step in result["audit_log"] if step["step"] == "gate"]
    assert any(step["accepted"] is False for step in rejected)


def test_every_step_reaches_the_resource_log(tmp_path):
    loop = make_loop(tmp_path, {"attempt 1": BROKEN, "attempt 2": GOOD})
    loop.run()

    rows = ResourceLog(Path(tmp_path) / "resources.jsonl").rows()
    phases = {row["phase"] for row in rows}

    assert {"plan", "dream", "memory", "propose", "verify"} <= phases
    assert all(row["backend"]["label"] == "scripted" for row in rows)


def test_an_empty_completion_is_rejected_not_accepted(tmp_path):
    result = make_loop(tmp_path, {}).run()

    assert result["accepted_count"] == 0
    assert result["best_candidate"] is None


def test_retrieved_memory_reaches_the_prompt(tmp_path):
    store = CausalMemoryStore(str(Path(tmp_path) / "memory.jsonl"))
    store.add("A missing return causes a NoneType error",
              cause_of="NoneType error", caused_by="missing return")

    class Recording(ScriptedBackend):
        def __init__(self):
            super().__init__({"attempt 1": GOOD})
            self.prompts: list[str] = []

        def complete(self, prompt: str) -> dict:
            self.prompts.append(prompt)
            return super().complete(prompt)

    backend = Recording()
    task = Task(task_id="none_error", family="debug",
                description="Fix the NoneType error in the total function",
                tests=["assert total([1, 2]) == 3"])
    AGILoop(task, backend, tmp_path, memory=store).run()

    assert backend.prompts
    assert "missing return" in backend.prompts[0]


def test_the_plan_cannot_include_deleting_the_tests(tmp_path):
    result = make_loop(tmp_path, {"attempt 1": GOOD}).run()

    dream_steps = [step for step in result["audit_log"] if step["step"] == "dream"]
    assert dream_steps, "the dreamer was never consulted"
    approved = dream_steps[0]["actions"]
    assert not any("delete" in action for action in approved)
    assert any("implement" in action for action in approved)


def test_task_without_tests_is_refused(tmp_path):
    empty = Task(task_id="empty", family="none", description="no checks", tests=[])

    try:
        AGILoop(empty, ScriptedBackend({}), tmp_path).run()
    except ValueError as error:
        assert "tests" in str(error)
    else:                                  # pragma: no cover - the failure path
        raise AssertionError("a task with no checks was accepted")


def test_demo_function_reports_one_task_three_candidates_one_accepted():
    report = demo()

    assert report == {"tasks": 1, "candidates": 3, "accepted": 1}
