# NAWAH-AGI

An apparatus for testing a claim about general intelligence, plus the measurement it
actually produced. The claim is **not** supported by the measurement, and this
document says so before it says anything else.

- Full test suite: **73 passed** in about 10 seconds (`python -m pytest`).
- ARC-AGI-1 evaluation subset: **0/20 (0% vs human 66%)**, measured.
- ARC-AGI-1 training subset: **2/20 (10%)**, measured, not comparable to the human baseline.
- SWE-bench Lite: **not run** - no dataset and no container sandbox in this repository.

## 1. The definition under test (one sentence)

> A system is AGI if it can acquire any new skill from three examples while guaranteeing
> that behaviour which already passed never regresses.

That sentence is the hypothesis. The repository implements the machinery needed to
falsify it on public benchmarks: a causal memory, a consequence simulator, a
stigmergic swarm, a no-regression gate, an integration loop, and an evaluation harness
that refuses to report a number it did not measure.

## 2. What was measured

| Benchmark | Split | Tasks | Result | Human baseline | Status | Evidence |
|---|---|---|---|---|---|---|
| ARC-AGI-1 | `evaluation` (public), seed 0 | 20 | **0/20 (0%)** | 66% | measured | `eval/results.json` |
| ARC-AGI-1 | `training` (public), seed 0 | 20 | **2/20 (10%)** | not comparable | measured | `eval/results_training.json` |
| SWE-bench Lite | - | 0 | - | none claimed | `not_run` | `eval/results_swebench.json` |

Provenance of the numbers above:

| Field | Value |
|---|---|
| Code commit that produced them | the `git` field inside each result file (full 40-character hash) |
| Timestamp | the `timestamp` field inside each result file (UTC, `Z` suffix) |
| Backend identity | `arc_dsl_v1`, `is_real: true`, `weights_sha256: null` |
| Dataset | ARC-AGI-1, Apache-2.0, `https://github.com/fchollet/ARC` |
| Dataset integrity | SHA-256 per task, verified on every load |
| Selection rule | `random.Random(seed).sample(sorted(task_ids), n)`, seed 0 |

The commit is recorded by the harness at run time rather than pinned in this table,
so a reviewer who re-runs the harness gets a hash for their own checkout instead of
a stale one. `reproduce/check.py` verifies that both files carry a hash, a UTC
timestamp and a backend identity.

The evaluation split is the public ARC-AGI-1 evaluation set, the split on which the
66% human figure is quoted. The training split is easier; its 10% is reported for
diagnosis only and must not be compared with 66%.

## 3. What the system actually is

```
goal -> swarm (plan) -> dreamer (filter) -> causal memory (enrich)
     -> backend (propose code) -> verifier (measure) -> gate (accept)
```

| Layer | File | What it does | What it is not |
|---|---|---|---|
| Gate | `core/gate.py` | Accepts a candidate only if it keeps every passing check and adds at least one | Not a proof of correctness |
| Causal memory | `core/causal_memory_v2.py` | Scores memories by causal path and by logged intervention effect | Not a knowledge graph learned from text |
| Dreamer | `core/dreamer.py` | Predicts consequences from state facts and a verb rule table | Not a world model |
| Swarm | `core/swarm.py` | Agents coordinate only through JSON traces on disk | Not concurrent, not networked |
| Loop | `core/agi_loop.py` | Runs the five steps above and logs each one | Not a trained model |
| Verifier | `core/skills.py` | Runs candidate code and its checks in a separate interpreter with a timeout | Not a sandbox against hostile code |
| Harness | `eval/harness.py` | Measures or reports `not_run`; never estimates | Not a leaderboard submission |
| Solver | `eval/arc_dsl.py` | Deterministic program synthesis over a fixed grid DSL | Not a language model |

The evaluation backend is **not** Qwen or any other neural model. It is a
deterministic DSL search: eight dihedral transforms, a learned colour map,
dihedral-plus-colour compositions, constant output, crop-to-content, integer tiling,
integer scaling, mirror-symmetry repair, and a 3x3 neighbourhood rule. A program is
kept only if it reproduces every training pair exactly. The reported pass rate is a
floor for this DSL, not a ceiling for the architecture.

## 4. Evaluation protocol

1. Freeze the data. `eval/fetch_arc.py` downloads ARC-AGI-1 once, samples tasks with a
   published seed, and records a SHA-256 per task. No evaluation code touches the
   network.
2. Validate. Each task is checked for non-empty rectangular grids, integer colours
   0-9, non-empty train and test lists. An invalid task is recorded as `invalid` and
   excluded from the denominator; it is never repaired or scored.
3. Isolate the holdout. The solver receives `train` pairs only. The `test` outputs are
   read once, at scoring time, after the gate has accepted a program.
4. Run the real loop. For each task the training pairs become executable checks; the
   backend proposes one program per attempt (three attempts); the verifier runs the
   checks in a subprocess; the gate decides acceptance.
5. Score. The accepted program is executed on every test input. A task counts as
   solved only if every test output matches exactly.
6. Record. Every run writes `status` (`measured`, `partial`, or `not_run`), counts,
   the task-level rows, the git commit, the UTC timestamp, the backend identity and
   the dataset hash.
7. Refuse. If a dataset, a weight file or a sandbox is missing, `pass_rate` and
   `solved` stay `null` and the summary says `not run`. A missing run is never a zero.

Determinism: the DSL search is deterministic, the task sample is seeded, and two
consecutive runs with seed 0 produced an identical `task_id -> (success, calls)` map.

## 5. Reproduce (three commands)

```bash
python -m pip install -r requirements.txt
python eval/harness.py --suite arc --n 20
python test_agi.py
```

Expected: the harness prints `arc (evaluation): measured - 0/20 (0% vs human 66%)`,
writes `eval/results.json`, and appends one row to `eval/RESULTS.md`; `test_agi.py`
prints its layer checks and exits 0.

Optional, in order of usefulness:

```bash
python -m pytest                      # 73 tests
python eval/harness.py --suite arc --split training --n 20 --out eval/results_training.json
python eval/harness.py --suite swebench   # prints not_run and explains why
python core/agi_loop.py               # task=1 candidates=3 accepted=1
python reproduce/check.py             # verifies every artefact and claim
```

`reproduce/reproduce.sh` (POSIX) and `reproduce/reproduce.ps1` (Windows) run the same
three commands non-interactively.

## 6. Hardware and runtime

| Item | Value |
|---|---|
| CPU | Any x86-64 or ARM64 CPU; no GPU used or required |
| RAM | Under 1 GB peak observed; 8 GB target |
| Network | Not used by `core/`, `eval/` or the tests; used once by `eval/fetch_arc.py` |
| Python | 3.12.10 verified; standard library only at runtime |
| OS | Windows 11 verified; POSIX supported (`signal` is not used) |
| ARC evaluation | 1.7 s wall for 20 tasks |
| Test suite | 9.7 s wall for 73 tests |

## 7. Evidence files

| File | What it lets a reviewer check |
|---|---|
| `eval/results.json` | 20 evaluation-task rows: id, success, calls, baseline, git, timestamp, backend |
| `eval/results_training.json` | The same for the training split, labelled not comparable |
| `eval/results_swebench.json` | A `not_run` record with the reason, not a score |
| `eval/RESULTS.md` | Append-only index of measured runs, one section per run |
| `eval/data/*.json` | The frozen tasks, with per-task SHA-256 |
| `eval/data/PROVENANCE.md` | Licence, split, selection rule, integrity check, rationale |
| `reproduce/CLAIMS.md` | Every claim mapped to an evidence file, or marked `UNSUPPORTED` |
| `reproduce/check.py` | Machine check of the artefacts, hashes and claim table |
| `docs/superpowers/plans/2026-10-22-nawah-agi-7-phases.md` | The plan that was executed |

## 8. What is not claimed

- Not AGI, and not evidence of AGI. The headline result is 0/20 on the evaluation split.
- Not a language model, not trained, no weights, no GPU, no tokens.
- Not state of the art on ARC-AGI-1 or on any other benchmark.
- No SWE-bench Lite score. The harness will only run it with a real JSONL file and a
  real sandbox command; neither ships here.
- No private holdout. The ARC evaluation split is public, so the measurement is a
  holdout with respect to this solver, not a blind one.
- No claim that the dreamer is safe. It is a verb rule table: an action outside its
  table is reported as unmodelled, and the filter keeps it while marking confidence low.
- No claim that the causal effect estimator is unbiased. It is a difference in mean
  success with and without a memory, shrunk towards zero while evidence is thin, and
  it assumes the retrieval policy did not favour easy tasks.

## 9. Known limitations

1. The DSL solves easy transformation tasks and nothing that requires counting,
   comparing, sorting, or composing two learned rules. 0/20 is the honest floor.
2. Twenty tasks is small. A larger run is one command, but it is a different
   measurement and must be recorded as such:
   `python eval/fetch_arc.py --n 200 --out eval/data/arc_agi1_200.json`.
3. The gate enforces monotone progress on a fixed check set. It cannot detect a check
   that is wrong or missing.
4. The verifier runs candidate code in a child interpreter with a timeout. That limits
   hangs and crashes; it is not a security boundary for hostile code.
5. The swarm owns one board at a time; a second instance on the same directory recycles
   the first one's traces (by design, recorded in `_manifest.json`).
6. The dreamer reasons over text with regular expressions. It is useful for refusing
   the obvious destructive shortcut and useless for anything it has no rule for.

## 10. Layout

```
PROMPTS.md                      the seven-phase specification
README.md                       this file
test_agi.py                     layer smoke test, asserts instead of claiming
core/gate.py                    no-regression gate (never modified)
core/causal_memory_v2.py        causal memory with intervention scoring
core/dreamer.py                 consequence simulator
core/swarm.py                   stigmergic blackboard
core/skills.py                  subprocess verifier and skill store
core/agi_loop.py                integrated loop
core/backends.py                scripted and llama.cpp backends
eval/fetch_arc.py               one-time ARC-AGI-1 download
eval/arc_data.py                hash-verified loader and validator
eval/arc_dsl.py                 deterministic DSL solver backend
eval/harness.py                 the evaluation harness
eval/data/                      frozen ARC-AGI-1 subsets and provenance
eval/results*.json              measured results (or not_run records)
reproduce/                      reproduction scripts, claim table, artefact check
tests/                          73 tests
docs/superpowers/plans/         the executed plan
```

## 11. Licence and provenance

Project code: no open-source licence is included in this archive. The files are
provided for verification and review; redistribution requires the owner's permission.
ARC-AGI-1 data: Apache-2.0, Copyright Francois Chollet and the ARC Prize Foundation,
downloaded from `https://github.com/fchollet/ARC` and redistributed here unmodified in
substance, with per-task hashes recorded in `eval/data/PROVENANCE.md`.
